import { ReferenceNumberRestrictionDirective } from './reference-number-restriction.directive';
import { TestBed } from '@angular/core/testing';

describe('ReferenceNumberRestrictionDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReferenceNumberRestrictionDirective]
    });
  });
  // it('should create an instance', () => {
  //   const directive = new ReferenceNumberRestrictionDirective();
  //   expect(directive).toBeTruthy();
  // });
});
