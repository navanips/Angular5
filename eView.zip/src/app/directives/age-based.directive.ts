import { Directive, ElementRef, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appAgeBased]'
})
export class AgeBasedDirective {

  regexStr = '^[0-9.]*$';
  constructor(private _el: ElementRef, private ngControl: NgControl) { }
 
   @HostListener('blur', ['$event']) onblur(event) {
     let finalValue = (this.ngControl.control.value)?this.ngControl.control.value.trim():this.ngControl.control.value;
     finalValue = this.fixPosStr(finalValue);
     this.ngControl.control.setValue(finalValue,{ emitEvent: false});
   }
 
   @HostListener('input',['$event']) onInput(event){
    this._el.nativeElement.value = this._el.nativeElement.value.replace(/[^0-9.]/g, '').trim();
    this.ngControl.control.setValue(this._el.nativeElement.value,{ emitEvent: false});
   }

   @HostListener('paste', ['$event']) blockPaste(event) {
    if(navigator.appVersion.toString().indexOf('Chrome') == -1) {
       this.validateFieldsIE(event); 
     } else {
       this.validateFields(event); 
     }   
   }

   fixPosStr(val) {
    if (val && val != '') {
      let value = val.replace(/(,)/g, '')
      value = Number(value).toFixed(2);
      // let amount = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
      if ((value == NaN) || (value == 'nan') || (value == 'NaN')) {
        return '';
      }
      else return value;
    }
  }

   validateFields(event: ClipboardEvent) {
     event.preventDefault();
     let pasteData = event.clipboardData.getData('text/plain').replace(/[^0-9.]/g, '');
     pasteData = pasteData.slice(0,3);
     document.execCommand('insertHTML', false, pasteData.trim());
   }
 
   validateFieldsIE(event) {    
     setTimeout(() => {
       this._el.nativeElement.value = this._el.nativeElement.value.replace(/[^0-9.]/g, '').trim();
       this._el.nativeElement.value = this._el.nativeElement.value.slice(0,3);
       this.ngControl.control.setValue(this._el.nativeElement.value,{ emitEvent: false});
       event.preventDefault();      
     }, 100)
   }
}
