import { Directive,ElementRef,HostListener,Input } from '@angular/core';
import {NgControl} from '@angular/forms';

@Directive({
  selector: '[appOnlyNumbersAllowed]'
})
export class OnlyNumbersAllowedDirective {

  regexStr = '^[0-9 ]*$';
  constructor(private _el: ElementRef, private ngControl: NgControl) {  
  }

  @HostListener('keypress', ['$event']) onKeyPress(event) {
   if (event.keyCode === 13) {
    return;  // let enter it happen
   }
    return new RegExp(this.regexStr).test(event.key);
  }

  @HostListener('input',['$event']) onInput(event){
    this._el.nativeElement.value = this._el.nativeElement.value.replace(/[^0-9]/g, '');
    this.ngControl.control.setValue(this._el.nativeElement.value,{ emitEvent: false});
  }

  @HostListener('blur', ['$event']) onblur(event) {
    const finalValue = (this.ngControl.control.value)?this.ngControl.control.value.trim():this.ngControl.control.value;
    this.ngControl.control.setValue(finalValue,{ emitEvent: false});
  }

  @HostListener('paste', ['$event']) blockPaste(event) {
    if(navigator.appVersion.toString().indexOf('Chrome') == -1) {
      this.validateFieldsIE(event); 
    } else {
      this.validateFields(event); 
    }   
  }

  validateFields(event: ClipboardEvent) {
    event.preventDefault();
    const pasteData = event.clipboardData.getData('text/plain').replace(/[^0-9]/g, '');
    document.execCommand('insertHTML', false, pasteData.trim());
  }

  validateFieldsIE(event) {    
    setTimeout(() => {
      this._el.nativeElement.value = this._el.nativeElement.value.replace(/[^0-9]/g, '').trim();
      this.ngControl.control.setValue(this._el.nativeElement.value,{ emitEvent: false});
      event.preventDefault();      
    }, 100)
  }

}
