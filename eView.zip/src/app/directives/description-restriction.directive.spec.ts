import { DescriptionRestrictionDirective } from './description-restriction.directive';
import { TestBed } from '@angular/core/testing';

describe('DescriptionRestrictionDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DescriptionRestrictionDirective]
    });
  });   
  // it('should create an instance', () => {
  //   const directive = new DescriptionRestrictionDirective();
  //   expect(directive).toBeTruthy();
  // });
});
