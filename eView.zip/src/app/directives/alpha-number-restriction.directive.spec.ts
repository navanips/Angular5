import { AlphaNumberRestrictionDirective } from './alpha-number-restriction.directive';
import { TestBed } from '@angular/core/testing';

describe('AlphaNumberRestrictionDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AlphaNumberRestrictionDirective]
    });
  });  
  // it('should create an instance', () => {
  //   const directive = new AlphaNumberRestrictionDirective();
  //   expect(directive).toBeTruthy();
  // });
});
