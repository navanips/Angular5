import { NumberDotDirective } from './number-dot.directive';
import { TestBed } from '@angular/core/testing';

describe('NumberDotDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NumberDotDirective]
    });
  });  
  // it('should create an instance', () => {
  //   const directive = new NumberDotDirective();
  //   expect(directive).toBeTruthy();
  // });
});
