import { TestBed } from '@angular/core/testing';
import { AgeBasedDirective } from './age-based.directive';

describe('AgeBasedDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AgeBasedDirective]
    });
  });
  // it('should create an instance', () => {
  //   const directive: AgeBasedDirective = TestBed.get(AgeBasedDirective);
  //   expect(directive).toBeTruthy();
  // });
});