import { OnlyNumbersAllowedDirective } from './only-numbers-allowed.directive';
import { TestBed } from '@angular/core/testing';

describe('OnlyNumbersAllowedDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OnlyNumbersAllowedDirective]
    });
  });
  // it('should create an instance', () => {
  //   const directive = new OnlyNumbersAllowedDirective();
  //   expect(directive).toBeTruthy();
  // });
});
