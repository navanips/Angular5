import { Directive,ElementRef,HostListener,Input } from '@angular/core';
import {NgControl} from '@angular/forms';

@Directive({
  selector: '[appSuburbRestriction]'
})
export class SuburbRestrictionDirective {

  regexStr = "^[A-Za-z-.' ]*$";
  constructor(private _el: ElementRef, private ngControl: NgControl) {  
  }

  @HostListener('keypress', ['$event']) onKeyPress(event) {
    return new RegExp(this.regexStr).test(event.key);
  }

  @HostListener('input',['$event']) onInput(event){
    this._el.nativeElement.value = this._el.nativeElement.value.replace(/[^A-Za-z-.' ]/g, '');
    this.ngControl.control.setValue(this._el.nativeElement.value,{ emitEvent: false});
  }
  
  @HostListener('blur', ['$event']) onblur(event) {
    const finalValue = (this.ngControl.control.value)?this.ngControl.control.value.trim():this.ngControl.control.value;
    this.ngControl.control.setValue(finalValue,{ emitEvent: false});
  }

  @HostListener('paste', ['$event']) blockPaste(event) {
    if(navigator.appVersion.toString().indexOf('Chrome') == -1) {
      this.validateFieldsIE(event); 
    } else {
      this.validateFields(event); 
    }   
  }

  validateFields(event: ClipboardEvent) {
    event.preventDefault();
    const pasteData = event.clipboardData.getData('text/plain').replace(/[^A-Za-z-.' ]/g, '');
    document.execCommand('insertHTML', false, pasteData.trim());
  }

  validateFieldsIE(event) {    
    setTimeout(() => {
      this._el.nativeElement.value = this._el.nativeElement.value.replace(/[^A-Za-z-.' ]/g, '').trim();
      this.ngControl.control.setValue(this._el.nativeElement.value,{ emitEvent: false});
      event.preventDefault();      
    }, 100)
  }

}
