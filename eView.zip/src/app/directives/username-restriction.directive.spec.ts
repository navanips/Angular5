import { UsernameRestrictionDirective } from './username-restriction.directive';
import { TestBed } from '@angular/core/testing';

describe('UsernameRestrictionDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UsernameRestrictionDirective]
    });
  });  
  // it('should create an instance', () => {
  //   const directive = new UsernameRestrictionDirective();
  //   expect(directive).toBeTruthy();
  // });
});
