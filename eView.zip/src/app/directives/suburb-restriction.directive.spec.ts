import { SuburbRestrictionDirective } from './suburb-restriction.directive';
import { TestBed } from '@angular/core/testing';

describe('SuburbRestrictionDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SuburbRestrictionDirective]
    });
  });
  // it('should create an instance', () => {
  //   const directive = new SuburbRestrictionDirective();
  //   expect(directive).toBeTruthy();
  // });
});
