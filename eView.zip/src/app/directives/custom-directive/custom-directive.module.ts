import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsernameRestrictionDirective } from '../username-restriction.directive';
import { AlphaNumberRestrictionDirective } from '../alpha-number-restriction.directive';
import { NameRestrictionDirective } from '../name-restriction.directive';
import { OnlyNumbersAllowedDirective } from '../only-numbers-allowed.directive';
import { SuburbRestrictionDirective } from '../suburb-restriction.directive';
import { DescriptionRestrictionDirective } from '../description-restriction.directive';
import { ReferenceNumberRestrictionDirective } from '../reference-number-restriction.directive';
import { AgeBasedDirective } from '../age-based.directive';
import { NumberDotDirective } from '../number-dot.directive';

@NgModule({
  declarations: [DescriptionRestrictionDirective, SuburbRestrictionDirective, UsernameRestrictionDirective, AlphaNumberRestrictionDirective, NameRestrictionDirective, OnlyNumbersAllowedDirective, ReferenceNumberRestrictionDirective, AgeBasedDirective, NumberDotDirective],
  imports: [
    CommonModule
  ],
  exports: [DescriptionRestrictionDirective, SuburbRestrictionDirective, UsernameRestrictionDirective, AlphaNumberRestrictionDirective, NameRestrictionDirective, OnlyNumbersAllowedDirective, ReferenceNumberRestrictionDirective, AgeBasedDirective, NumberDotDirective]
})
export class CustomDirectiveModule { }