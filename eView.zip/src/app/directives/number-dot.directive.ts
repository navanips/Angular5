import { Directive, ElementRef, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appNumberDot]'
})
export class NumberDotDirective {

  regexStr = '^[0-9.]*$';
  constructor(private _el: ElementRef, private ngControl: NgControl) { }

  @HostListener('blur', ['$event']) onblur(event) {
    let finalValue = (this.ngControl.control.value)?this.ngControl.control.value.trim():this.ngControl.control.value;
    this.ngControl.control.setValue(finalValue,{ emitEvent: false});
  }

  @HostListener('input',['$event']) onInput(event){ 
  if (event.data && event.data.charCodeAt() === 46 && event.target.value.split('.').length > 2) {
    this._el.nativeElement.value = this._el.nativeElement.value.replace(/\.+$/,"");
  }    
   this._el.nativeElement.value = this._el.nativeElement.value.replace(/[^0-9.]/g, '').trim();
   this.ngControl.control.setValue(this._el.nativeElement.value,{ emitEvent: false});
  }

  @HostListener('paste', ['$event']) blockPaste(event) {
   if(navigator.appVersion.toString().indexOf('Chrome') == -1) {
      this.validateFieldsIE(event); 
    } else {
      this.validateFields(event); 
    }   
  }

  validateFields(event: ClipboardEvent) {
    event.preventDefault();
    const pasteData = event.clipboardData.getData('text/plain').replace(/[^0-9.]/g, '');
    document.execCommand('insertHTML', false, pasteData.trim());
  }

  validateFieldsIE(event) {    
    setTimeout(() => {
      this._el.nativeElement.value = this._el.nativeElement.value.replace(/[^0-9.]/g, '').trim();
      this.ngControl.control.setValue(this._el.nativeElement.value,{ emitEvent: false});
      event.preventDefault();      
    }, 100)
  }
  
}
