import { NameRestrictionDirective } from './name-restriction.directive';
import { TestBed } from '@angular/core/testing';

describe('NameRestrictionDirective', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NameRestrictionDirective]
    });
  });
  // it('should create an instance', () => {
  //   const directive = new NameRestrictionDirective();
  //   expect(directive).toBeTruthy();
  // });
});
