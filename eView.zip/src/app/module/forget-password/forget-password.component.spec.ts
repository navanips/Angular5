import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { ForgetPasswordComponent } from './forget-password.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfiguration } from '../../app-configuration';
import { DebugElement } from '@angular/core';
import { AlertModule } from 'ngx-bootstrap';

describe('ForgetPasswordComponent', () => {
  let component: ForgetPasswordComponent;
  let fixture: ComponentFixture<ForgetPasswordComponent>;
  let de: DebugElement;
  let el:HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgetPasswordComponent ],
      imports: [
        FormsModule,
        BrowserModule,
        ReactiveFormsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        AlertModule
      ],
      providers: [AppConfiguration]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgetPasswordComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('form'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set submitted to true',async(() =>{
    component.onSubmit();
    expect(component.submitted).toBeTruthy();
  }));

  it('should call the onsubmit method',async(() => {
    fixture.detectChanges();
    spyOn(component,'onSubmit');
    el = fixture.debugElement.query(By.css('#submitBtn')).nativeElement;
    el.click();
    expect(component.onSubmit).toHaveBeenCalledTimes(1);
  }));

  it('form should be invalid',(() => {
    component.forgetPasswordForm.controls['userName'].setValue('');
    component.forgetPasswordForm.controls['emailId'].setValue('');
    expect(component.forgetPasswordForm.valid).toBeFalsy();
  }));

  it('form should be valid',(() => {
    component.forgetPasswordForm.controls['userName'].setValue('internal');
    component.forgetPasswordForm.controls['emailId'].setValue('test@test.com');
    expect(component.forgetPasswordForm.valid).toBeTruthy();
  }));

});
