import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../service/user/user.service';
import { AppConfiguration } from '../../app-configuration';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import * as $ from 'jquery';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {

  forgetPasswordForm: FormGroup;
  submitted = false;
  loggedInfo : any;
  resultData: any;
  responseMsg : String;
  responseClass : String;
  appExternalURLS : any;
  public alerts: any[] = [];
  afterSubmit = false;
  
  constructor(private conf:AppConfiguration, private router:Router,private UserService:UserService, private titleService: Title) {
    this.appExternalURLS = conf.externalURLS;
    let submitObj = 'username=&password=&client_id=metau&scope=read&grant_type=client_credentials';
    this.titleService.setTitle("Forgot password | eView - MetLife"); 
      this.UserService.generateTokenForForgotPassword(submitObj).subscribe();
  }

  ngOnInit() {
    this.forgetPasswordForm = new FormGroup({
      userName: new FormControl('',[Validators.required]),
      emailId: new FormControl('',[Validators.required,Validators.pattern(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)]),
    });
    this.focusByDefault();
  }

  focusByDefault(){
    $(document).ready(function(){
      setTimeout(() => {
        $('#username').focus();
      },100);
    });
  }

  checkErr(event) {
    if(this.forgetPasswordForm.invalid) {
      this.alerts = [];
    }
  }

  get f() { return this.forgetPasswordForm.controls; }
  
  onSubmit() {
    this.submitted = true;

    if (this.forgetPasswordForm.valid) {
      let dataObj = '/'+this.forgetPasswordForm.value.userName+'/'+this.forgetPasswordForm.value.emailId+'/forgot';
      
      this.UserService.resetPassword(dataObj).subscribe(data => {
        this.resultData = data;
        if(this.resultData.response == 'Success')
        {
          this.forgetPasswordForm.reset();
          this.submitted = false;
          /*$('#submittedModal').show();*/
          // $(".beforesubmit").hide();
          // $(".aftersubmit").show();
          this.afterSubmit = true;
        }else{
          this.alerts=[{
            "type":'danger',
            "msg":this.resultData.message,
            "timeout":30000
          }];
        }
      },
      err => {
        this.responseClass = "alert alert-danger";
        this.responseMsg = 'Service unavailable. Please contact system administrator.';
        this.alerts=[{
          "type":'danger',
          "msg": 'You have entered the incorrect user ID/ email address. Please provide the correct details. ',
          "timeout":30000
        }];
      });
    }
  }
}
