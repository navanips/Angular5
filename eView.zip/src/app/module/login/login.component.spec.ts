import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { LoginComponent } from './login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfiguration } from '../../app-configuration';
import { DebugElement } from '@angular/core';
import { DashboardComponent } from '../dashboard/dashboard.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let de: DebugElement;
  let el:HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent,DashboardComponent ],
      imports: [
        FormsModule,
        BrowserModule,
        ReactiveFormsModule,
        RouterTestingModule.withRoutes([{path:'dashboard',component:DashboardComponent}]),
        HttpClientTestingModule
      ],
      providers: [AppConfiguration]
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(LoginComponent);
      component = fixture.componentInstance;
      de = fixture.debugElement.query(By.css('form'));
      el = de.nativeElement;
      fixture.detectChanges();
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set submitted to true',async(() =>{
    component.onSubmit();
    expect(component.submitted).toBeTruthy();
  }));

  it('should call the onsubmit method',async(() => {
    fixture.detectChanges();
    spyOn(component,'onSubmit');
    el = fixture.debugElement.query(By.css('button')).nativeElement;
    el.click();
    expect(component.onSubmit).toHaveBeenCalledTimes(1);
  }));

  it('form should be invalid',(() => {
    component.loginForm.controls['userName'].setValue('');
    component.loginForm.controls['Password'].setValue('');
    expect(component.loginForm.valid).toBeFalsy();
  }));
  
  it('form should be valid',(() => {
    component.loginForm.controls['userName'].setValue('user');
    component.loginForm.controls['Password'].setValue('user$');
    expect(component.loginForm.valid).toBeTruthy();
  }));

  // it('it should have one user',(() => {
  //   expect(component.resultData.length).toEqual(1);
  // }))

});
