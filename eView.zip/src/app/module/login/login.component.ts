import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { RestApiService } from '../../service/rest-api.service';
import { UserService } from '../../service/user/user.service';
import { AppConfiguration } from '../../app-configuration';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import * as $ from 'jquery';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  secondAttempt = false;
  loggedInfo: any;
  loggedinData: any;
  userData: any;
  loginError: any;
  appExternalURLS: any;
  constructor(private conf: AppConfiguration, private api: RestApiService, private router: Router, private UserService: UserService, private titleService: Title) {
    this.appExternalURLS = conf.externalURLS;
    this.titleService.setTitle("Login | eView - MetLife");
    if (sessionStorage.getItem('userDetails')) {
      this.router.navigate(['/dashboard']);
    }
  }

  ngOnInit() {
    this.loginForm = new FormGroup({
      userName: new FormControl('', [Validators.required]),
      Password: new FormControl('', [Validators.required]),
      // rememberMe: new FormControl(false)
    });
    this.focusByDefault();
  }

  focusByDefault(){
    $(document).ready(function(){
      setTimeout(() => {
        $('#username').focus();
      },100);
    });
  }
  get f() { return this.loginForm.controls; }

  checkErr(event) {
    if(this.loginForm.controls['Password'].getError('required') || this.loginForm.controls['userName'].getError('required')) {
      this.loginError = ''
    }
  }
  
  onSubmit() {
    this.submitted = true;
    this.loginError = '';
    if (this.loginForm.valid) {
      let  submitObj  =  'username=' + this.loginForm.value.userName + '&password=' + this.loginForm.value.Password + '&client_id=metau&scope=read&grant_type=password';
      if(sessionStorage.getItem('userName') && sessionStorage.getItem('userName') == this.loginForm.value.userName) {
        this.secondAttempt = true;
      } else {
        sessionStorage.setItem('userName',this.loginForm.value.userName);
      }
      this.UserService.login(submitObj).subscribe(data => {
        this.loggedinData = data;
        if (this.loggedinData) {
          this.UserService.getUserDetails().subscribe(userData => {
            this.userData = userData;
            if (this.userData && this.userData.status === 'Active') {
              // if(this.router['currentUrlTree'].queryParams.returnUrl) {
              //   this.router.navigate([this.router['currentUrlTree'].queryParams.returnUrl]);
              // } else {
              //   this.router.navigate(['/dashboard']);
              // }
              sessionStorage.setItem('passwordExpiryPopup','yes');
              this.router.navigate(['/dashboard']);
            } else if(this.userData && this.userData.status === 'Inactive') {
              const obj = { error_description: 'Your user account has been deactivated. Please contact the system administrator to have your account activated.' };
              this.loginError = obj;
              sessionStorage.removeItem('userToken');
              sessionStorage.removeItem('userDetails');
            } else {
              const obj = { error_description: 'Your user account has been deleted. Please contact the system administrator.' };
              this.loginError = obj;
              sessionStorage.removeItem('userToken');
              sessionStorage.removeItem('userDetails');
            }
          },
          err => {
            this.loginForm.controls['Password'].setValue('');
            this.submitted = false;
            sessionStorage.removeItem('userToken');
            sessionStorage.removeItem('userDetails');
            const obj = { error_description: err.error.message };
            this.loginError = (err.error.hasOwnProperty('error_description') === true) ? err.error : obj;
          }); 
        }
      },
        err => {
          // $('#password').val('');
          this.loginForm.controls['Password'].setValue('');
          this.submitted = false;
          const obj = { error_description: 'Service unavailable. Please contact system administrator.' };
          let error_des;
          if(this.secondAttempt) {
            error_des = { error_description: 'You have entered incorrect User ID / Password. Your account may have locked. Please contact our support desk at auservices@metlife.com' }; 
            //error_des = { error_description: "Your account will be locked if your next login attempt fails. If you have forgotten your password, click on the 'Forgotten password' link below. " };
          } else {
            error_des = { error_description: 'You have entered incorrect User ID / Password. Your account may have locked. Please contact our support desk at auservices@metlife.com' };
          }
          this.loginError = (err.error.hasOwnProperty('error_description') === true) ? error_des : obj;
        });
    }
  }

}
