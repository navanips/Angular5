import { UnderwritingModule } from './underwriting.module';

describe('UnderwritingReportModule', () => {
  let underwritingModule: UnderwritingModule;

  beforeEach(() => {
    underwritingModule = new UnderwritingModule();
  });

  it('should create an instance', () => {
    expect(UnderwritingModule).toBeTruthy();
  });
});