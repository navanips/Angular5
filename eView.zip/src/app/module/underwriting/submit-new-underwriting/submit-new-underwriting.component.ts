import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { AppConfiguration } from '../../../app-configuration';
import { Router } from '@angular/router';
import { RestApiService } from '../../../service/rest-api.service';
import { FileUploader, FileItem, ParsedResponseHeaders, FileUploaderOptions, Headers } from 'ng2-file-upload';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalComponent } from '../../../layout/ngb-modal/ngb-modal.component';
import * as $ from 'jquery';
import * as moment from 'moment';
import { CustomSpinnerService } from '../../../service/spinner/custom-spinner.service';
import { FlashMessageService } from '../../../service/flash-message/flash-message.service';

@Component({
  selector: 'app-submit-new-underwriting',
  templateUrl: './submit-new-underwriting.component.html',
  styleUrls: ['./submit-new-underwriting.component.css']
})

export class SubmitNewUnderwritingComponent implements OnInit {

  @ViewChild('fileInput') fileInput: any;
  NewUnderWriting: FormGroup;
  fundDetails: any;
  categoryList: any;
  docList: any;
  ageBasedList = ['CARE'];
  submitted = false;

  insScale = false; /* show hide error messages start */
  DC_Cover = false;
  IP_Cover = false;
  TPD_Cover = false; /* show hide error messages ends */

  uploadBtnShow = [];
  progress = [];
  postdoc = [];
  fileNames = [];
  browseBtn = [];
  RefselectedDoc = [];
  selectedDoc = [];
  selectedDocId = [];
  tableData = [];
  tableDataRef = [];
  searchVal = '';
  totalCoverValue = [];
  public alerts: any[] = [];
  public format = 'dd/MM/yyyy';
  public uploader: FileUploader = new FileUploader({});
  private uploaderOptions: FileUploaderOptions = {};
  deathCoverChecked = false;
  disabilityCoverChecked = false;
  IpCoverChecked = false;
  unitShow = false;
  dis_unitShow = false;
  additionalUnitShow = false;
  dis_additionalUnitShow = false;
  public today: Date = new Date(new Date().toDateString());
  tooltips = false;
  chekErr = true;
  showHide = [];
  userDetails: any;
  tooltips1 = false;
  appformLength = 0;
  fileUploadRequest = 0;
  totalRequest = 0;
  successRequest = 0;
  uploadSummary: any = [];
  submitObj = {
    confirmHrs: false,
    gender: '',
    firstName: '',
    lastName: '',
    additionalinfo: '',
    userName: '',
    submittedEmail: '',
    submittedPhone: '',
    clientRefNumber: '',
    confirmEmailFlag: true,
    fundCode: '',
    fundName: '',
    categoryId: '',
    categoryName: '',
    title: '',
    dateOfBirth: null,
    dateJoinedCompany: null,
    dateJoinedFund: null,
    contactInfo: [{
      address1: '',
      address2: '',
      suburb: '',
      state: '',
      postcode: '',
      mobilePhone: '',
      applicantEmail: '',
      prefTime: '',
      insuranceScale: '',
      rolloverPending: ''
    }],
    coversInfo: [],
    documentInfo: [{
      documentLocation: '',
      docType: ''
    }]
  };
  waitingPeriodData: any = [{ value: '0', text: '0 Days' }, { value: '14', text: '14 Days' }, { value: '30', text: '30 Days' }, { value: '45', text: '45 Days' }, { value: '60', text: '60 Days' }, { value: '90', text: '90 Days' }, { value: '120', text: '120 Days' }, { value: '180', text: '180 Days' }];

  ExistingPeriodData: any = [{ value: '1YR', text: '1YR' }, { value: '2YR', text: '2YR' }, { value: '3YR', text: '3YR' }, { value: '4YR', text: '4YR' }, { value: '5YR', text: '5YR' }, { value: 'AGE55', text: 'AGE55' }, { value: 'AGE60', text: 'AGE60' }, { value: 'AGE65', text: 'AGE65' }];

  deathCoverInfo = {
    coverCode: 'DTH',
    totalRequestedCover: '',
    existingCoverAmount: '',
    additionalCoverAmount: '',
  };
  disabilityCoverInfo = {
    totalRequestedCover: '',
    existingCoverUnits: '',
    additionalCoverUnits: '',
    coverCode: 'TPD',
    existingCoverAmount: '',
    additionalCoverAmount: '',
    existingAgeFactor: '',
    additionalAgeFactor: ''
  };
  IpCoverInfo = {
    totalRequestedCover: '',
    coverPeriod: [{
      existingWaitingPeriod: '',
      existingBenefitPeriod: '',
      waitingPeriod: '',
      benefitPeriod: '',
    }],
    coverCode: 'IPC',
    existingCoverAmount: '',
    additionalCoverAmount: ''
  };

  DTHdup = Object.assign({}, this.deathCoverInfo);
  TPDdup = Object.assign({}, this.disabilityCoverInfo);
  IPCdup = Object.assign({}, this.IpCoverInfo);

  isDirty: boolean = false;

  @HostListener('window:beforeunload', ['$event'])
  doSomething($event) {
    if (this.isDirty) {
      $event.returnValue = 'Changes you made may not be saved.';
    }
  }

  constructor(private errorMsg: FlashMessageService, private spin: CustomSpinnerService, private conf: AppConfiguration, private router: Router, private api: RestApiService, private fb: FormBuilder, private ngbModal: NgbModal) {
    this.getFundPlan();
    this.getCategory();
    this.getDoc();
    this.uploaderOptions['url'] = this.conf.serviceBaseUrl + this.conf.URLS.fileUrl.fileUpload;
    this.uploaderOptions['method'] = 'POST';
    this.uploaderOptions['autoUpload'] = false;
    this.uploaderOptions['maxFileSize'] = 50 * 1024 * 1024;
    this.uploaderOptions['allowedMimeType'] = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'image/png', 'image/jpeg', 'image/jpg'];
    this.uploaderOptions['authToken'] = "Bearer " + sessionStorage.getItem('userToken');
    this.uploader.setOptions(this.uploaderOptions);
    this.userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
    if (this.userDetails) {
      this.submitObj.userName = this.userDetails.firstName + ' ' + this.userDetails.lastName;
      this.submitObj.submittedEmail = this.userDetails.email;
      this.submitObj.submittedPhone = this.userDetails.mobile;
    }
  }
  BooleanConverter(value: any) {
    return value;
  }
  canDeactivate(): boolean {
    if (!this.isDirty || (!sessionStorage.getItem('userToken') && !sessionStorage.getItem('userDetails'))) return true;
    else {
      let ngbModalOptions: NgbModalOptions = {
        backdrop: 'static',
        keyboard: false
      };
      const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
      let docloc = this.submitObj.documentInfo.map(value => value.documentLocation).join(',');
      m.componentInstance.Title = 'Leave site?';
      m.componentInstance.confMessage = 'Changes you made may not be saved.';
      let res = this.BooleanConverter(m.result);
      res.then((userResponse) => {
        if (userResponse === true && docloc) {
          this.delUploaded(docloc);
        }
      });
      return res;
    }
  }
  ngOnInit() {
    this.errorMsg.hideErrorMessage();
    this.NewUnderWriting = this.fb.group({
      appInfo: this.fb.group({
        refNo: new FormControl('', [Validators.required]),
        fundPlan: new FormControl('', [Validators.required]),
        appCategory: new FormControl('', [Validators.required]),
        Title: new FormControl('', [Validators.required]),
        fName: new FormControl('', [Validators.required]),
        surName: new FormControl('', [Validators.required]),
        dob: new FormControl('', [Validators.required]),
        dojFund: new FormControl(''),
        dojCompany: new FormControl(''),
      }),
      contactInfo: this.fb.group({
        address1: new FormControl('', [Validators.required]),
        address2: new FormControl(''),
        suburb: new FormControl('', [Validators.required]),
        state: new FormControl('', [Validators.required]),
        postCode: new FormControl('', [Validators.required]),
        contact: new FormControl('', [Validators.required]),
        applicantEmail: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.applicantEmail.value !== 'N/A', Validators.pattern(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)), Validators.required
        ])),
        preferedTOC: new FormControl(''),
        rolloverPending: new FormControl(''),
        insuranceScale: new FormControl('', Validators.compose([
          this.conditional(group => (this.appInfo.controls.fundPlan.value === 'MTAA' || this.appInfo.controls.fundPlan.value === 'MTAS'), Validators.required)
        ]))
      }),
      coversInfo: this.fb.group({
        deathCover: new FormControl(''),
        disabilityCover: new FormControl(''),
        incomeProtectionCover: new FormControl(''),
        copyCover: new FormControl(''),
        ExistWaitPeriod: new FormControl(''),
        ExistBenefPeriod: new FormControl(''),
        ReqWaitPeriod: new FormControl(''),
        ReqBenefPeriod: new FormControl(''),
        coverOpt: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.deathCover.value === true, Validators.required),
        ])),
        dis_coverOpt: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.disabilityCover.value === true, Validators.required),
        ])),
        Ip_coverOpt: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.incomeProtectionCover.value === true, Validators.required),
        ])),
        units: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.coverOpt.value === '2', Validators.required),
        ])),
        dis_units: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.dis_coverOpt.value === '2', Validators.required),
        ])),
        Ip_units: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.Ip_coverOpt.value === '2', Validators.required),
        ])),
        ageBased: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.coverOpt.value === '3', Validators.required),
        ])),
        additionalAgeBased: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.additionalCoverOpt.value === '3', Validators.required),
        ])),
        dis_ageBased: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.dis_coverOpt.value === '3', Validators.required),
        ])),
        dis_additionalAgeBased: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.dis_additionalCoverOpt.value === '3', Validators.required),
        ])),
        totalExistCovers: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.deathCover.value === true, Validators.required),
        ])),
        dis_totalExistCovers: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.disabilityCover.value === true, Validators.required),
        ])),
        Ip_totalExistCovers: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.incomeProtectionCover.value === true, Validators.required),
        ])),
        additionalCoverOpt: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.deathCover.value === true, Validators.required),
        ])),
        dis_additionalCoverOpt: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.disabilityCover.value === true, Validators.required),
        ])),
        Ip_additionalCoverOpt: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.incomeProtectionCover.value === true, Validators.required),
        ])),
        additionalUnits: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.additionalCoverOpt.value === '2', Validators.required),
        ])),
        dis_additionalUnits: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.dis_additionalCoverOpt.value === '2', Validators.required),
        ])),
        Ip_additionalUnits: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.Ip_additionalCoverOpt.value === '2', Validators.required),
        ])),
        totalReqCovers: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.deathCover.value === true, Validators.required),
        ])),
        dis_totalReqCovers: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.disabilityCover.value === true, Validators.required),
        ])),
        Ip_totalReqCovers: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.incomeProtectionCover.value, Validators.required),
        ])),
      }),
      documentInfo: this.fb.group({}),
      additionalinfo: this.fb.group({
        additionalInfo: new FormControl(''),
        confirmationMail: new FormControl(true),
      }),
      submittedBy: this.fb.group({
        Name: new FormControl(''),
        emailId: new FormControl('', Validators.compose([
          this.conditional(group => this.additionalinfo.controls.confirmationMail.value === true, Validators.required), Validators.pattern(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)
        ])),
        phNo: new FormControl(''),
      })
    })
    this.onChanges();
    this.uploader.onWhenAddingFileFailed = (item, filter) => {
      if (filter.name == 'fileSize') {
        this.uploadSummary = [];
        this.uploadSummary.push({
          status: 'error',
          fileName: '',
          message: 'File size exceeds the maximum of 50 MB per file.You can upload mutiple files if required.',
        });
      }
      if (filter.name == 'mimeType') {
        this.uploadSummary = [];
        this.uploadSummary.push({
          status: 'error',
          fileName: '',
          message: 'The selected file type is not a valid file type. The following file formats only are supported *.pdf, *.doc, *.docx, *.xls, *.xlsx, *.csv, *.jpg, *.jpeg, *.png',
        });
      }
    };
    var prevSelect = '';
    var thisSelect = $('#selectfundplan').val();
    var thisRef = this;
    $('#selectfundplan').change(function () {
      prevSelect = (thisSelect != '') ? thisSelect : null;
      thisSelect = ($(this).val() != '') ? $(this).val() : null;
      if (thisRef.ageBasedList.indexOf(thisSelect) > -1 || thisRef.ageBasedList.indexOf(prevSelect) > -1) {
        thisRef.coversInfo.controls['coverOpt'].reset();
        thisRef.coversInfo.controls['additionalCoverOpt'].reset();
        thisRef.coversInfo.controls['dis_coverOpt'].reset();
        thisRef.coversInfo.controls['dis_additionalCoverOpt'].reset();

        Object.keys(thisRef.deathCoverInfo).forEach((key) => {
          if (key == 'existingCoverUnits' || key == 'additionalCoverUnits' || key == 'existingAgeFactor' || key == 'additionalAgeFactor') {
            delete thisRef.deathCoverInfo[key];
          }
        });
        Object.keys(thisRef.disabilityCoverInfo).forEach((key) => {
          if (key == 'existingCoverUnits' || key == 'additionalCoverUnits' || key == 'existingAgeFactor' || key == 'additionalAgeFactor') {
            delete thisRef.disabilityCoverInfo[key];
          }
        });
      }
    });
  }

  ngAfterViewInit() {
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
    });
  }
  onChanges() {
    this.NewUnderWriting.valueChanges.subscribe(form => {
      if (this.NewUnderWriting.dirty) {
        this.isDirty = true;
      }
    });
  }
  conditional(conditional, validator) {
    return function (control) {
      if (control && control._parent) {
        if (conditional(control._parent)) {
          return validator(control);
        }
      }
    };
  }

  resetForm(val) {
    if (val == 1) {
      let docloc = this.submitObj.documentInfo.map(value => value.documentLocation).join(',');
      if (docloc) {
        this.delUploaded(docloc);
      }
    }
    this.tableData = [];
    this.tableDataRef = [];
    this.selectedDoc = [];
    this.selectedDocId = [];
    this.uploadSummary = [];
    if (this.RefselectedDoc.length == 1) {
      this.selectedDoc.push(this.RefselectedDoc[0]);
      this.selectedDocId.push(this.RefselectedDoc[0].documentTypeID)
    }
    this.searchVal = '';
    this.NewUnderWriting.reset();
    this.appformLength = 0;
    this.uploader.queue = [];
    this.postdoc = [];
    this.fileNames = [];
    this.uploadBtnShow = [];
    this.browseBtn = [];
    this.browseBtn[0] = true;
    this.deathCoverChecked = false;
    this.disabilityCoverChecked = false;
    this.IpCoverChecked = false;
    this.showHide = [];
    this.progress.fill(0);
    this.submitObj.documentInfo = [];
    this.contactInfo.patchValue({
      state: '',
      preferedTOC: '',
      insuranceScale: ''
    });
    this.submittedBy.patchValue({
      Name: this.userDetails.firstName + ' ' + this.userDetails.lastName,
      emailId: this.userDetails.email,
      phNo: this.userDetails.mobile
    });
    this.totalCoverValue = [];
    this.submitted = false;

    this.insScale = false;
    this.DC_Cover = false;
    this.IP_Cover = false;
    this.TPD_Cover = false;

    this.appInfo.patchValue({ fundPlan: '', appCategory: '', Title: '' });
    this.coversInfo.patchValue({ ExistWaitPeriod: '', ExistBenefPeriod: '', ReqWaitPeriod: '', ReqBenefPeriod: '' });
    $('#collapseThree :checkbox:enabled').prop('checked', false);
    $('#filterSearch').val('');
    this.deathCoverInfo = Object.assign({}, this.DTHdup);
    this.disabilityCoverInfo = Object.assign({}, this.TPDdup);
    this.IpCoverInfo = Object.assign({}, this.IPCdup);
    $('#checkedBoxes').prop('checked', true);
    this.submitObj.confirmHrs = false;
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
    $('#genderDiv button').removeClass('btn btn-lg btn-primary active').addClass('btn btn-lg btn-default');
    this.submitObj.gender = '';
    this.submitObj.categoryName = '';
    this.submitObj.fundName = '';
    let eventChecked = { target: { checked: true } };
    this.additionalinfo.controls['confirmationMail'].setValue(true);
    this.checkErr(eventChecked)
  }
  removeTableData(data, i) {
    let ind = this.tableDataRef.findIndex(x => x.documentTypeID == data.documentTypeID && x.Id == data.Id);
    this.tableData = this.tableData.filter(x => (x.Id != data.Id));
    this.uploader.queue.splice(ind, 1);
    this.tableDataRef = this.tableDataRef.filter(x => (x.Id != data.Id));
  }
  onFileSelected(input) {
    let fName = [];
    if (this.fileInput.nativeElement.value) {
      fName = this.fileInput.nativeElement.value.split("\\")
    }
    let appForm = this.selectedDoc.filter(x => x.documentTypeName.toLowerCase() == 'application form');
    if (this.docList.findIndex(x => x.documentTypeName.toLowerCase() == 'application form') == -1 && appForm.length == 1) {
      this.docList.unshift(appForm[0]);
    }    
    let ext = fName[fName.length - 1].split('.');
    let arrExt = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'png', 'jpg', 'jpeg']
    if(arrExt.indexOf(ext[ext.length-1].toLowerCase()) == -1) {
      //this.uploader.queue.splice(this.uploader.queue.length-1,1);
      this.selectedDoc = [];
      this.selectedDocId = [];
      this.uploadSummary = [];
      this.uploadSummary.push({
        status: 'error',
        fileName: '',
        message: 'The selected file type is not a valid file type. The following file formats only are supported *.pdf, *.doc, *.docx, *.xls, *.xlsx, *.csv, *.jpg, *.jpeg, *.png',
      });
    }    
    let validDoc = []; let inValid = [];
    for (let i = 0; i < this.selectedDoc.length; i++) {
      const fileBrowser = this.fileInput.nativeElement;
      if (i > 0) {
        this.uploader.addToQueue(fileBrowser.files);
      }
      if (this.uploader._mimeTypeFilter(input.target.files[0]) && this.uploader._fileSizeFilter(input.target.files[0])) {
        let uniqId = Math.round((Math.pow(36, 10 + 1) - Math.random() * Math.pow(36, 10))).toString(36).slice(1);
        this.uploadSummary = [];
        this.tableData.push({
          Id: uniqId,
          docType: this.selectedDoc[i].docType,
          documentTypeID: this.selectedDoc[i].documentTypeID,
          documentTypeName: this.selectedDoc[i].documentTypeName,
          fileName: fName[fName.length - 1],
          delete: (this.selectedDoc[i].delete == false) ? false : true
        });
        this.tableDataRef.push({
          Id: uniqId,
          docType: this.selectedDoc[i].docType,
          documentTypeID: this.selectedDoc[i].documentTypeID,
          documentTypeName: this.selectedDoc[i].documentTypeName,
          fileName: fName[fName.length - 1],
          delete: (this.selectedDoc[i].delete == false) ? false : true
        });
        validDoc.push(this.selectedDoc[i])
      } else {
        inValid.push(this.selectedDoc[i])
      }
    }
    // let appForm = this.selectedDoc.filter(x => x.documentTypeName.toLowerCase() == 'application form');
    // if (this.docList.findIndex(x => x.documentTypeName.toLowerCase() == 'application form') == -1 && appForm.length == 1) {
    //   this.docList.unshift(appForm[0]);
    // }
    this.selectedDoc = [];
    this.selectedDocId = [];
    this.appformLength = this.tableData.filter(x => x.documentTypeName == 'Application Form').length;
  }
  upload() {
    if (this.uploader.queue.length > 0) {
      this.spin.show();
      this.totalRequest = 0;
      this.successRequest = 0;
      this.uploadSummary = [];
      this.uploader.queue.forEach((currentItem, index) => {
        this.fileUploadRequest++;
        this.totalRequest++;
        if (this.tableDataRef.length > index) {
          currentItem.url = this.conf.serviceBaseUrl + this.conf.URLS.fileUrl.fileUpload + '?docType=' + this.tableDataRef[index].documentTypeName;
        }
      });
      this.uploader.onBuildItemForm = (item, form) => {
        form.append('Type', item.alias);
        form.append('Key', item._file);
        form.append('multipart', item.file);
      };
      let ss = this.uploader.uploadAll();
      this.uploader.onErrorItem = (item, response, status, headers) => this.onErrorItem(item, response, status, headers);
      this.uploader.onSuccessItem = (item, response, status, headers) => this.onSuccessItem(item, response, status, headers);
      this.uploader.onCompleteAll = () => {
        this.spin.hide();
        this.appformLength = this.tableData.filter(x => x.documentTypeName == 'Application Form').length;
        if (this.successRequest === this.totalRequest) {
          this.onSubmit();
        }
      };
    }
  }

  onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    let ind = this.uploader.getIndexOfItem(item);
    this.uploader.removeFromQueue(item);
    let suc = JSON.parse(response);
    this.tableData.filter(x => (x.Id == this.tableDataRef[ind].Id) ? x.delete = false : '')
    this.tableDataRef.splice(ind, 1);
    this.uploadSummary.push({
      status: 'success',
      fileName: item.file.name,
      message: 'Document uploaded successfully',
    });
    this.successRequest++;
    this.fileUploadRequest--;
    if (this.fileUploadRequest == 0) {
      this.spin.hide();
    }
    let obj = {
      documentLocation: suc.filePath,
      docType: suc.fileType
    }
    this.postdoc.push(obj);
    this.submitObj.documentInfo = this.postdoc;
  }

  onErrorItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    let ind = this.uploader.getIndexOfItem(item);
    this.uploader.removeFromQueue(item);

    this.tableData = this.tableData.filter(x => x.Id != this.tableDataRef[ind].Id);
    this.tableDataRef.splice(ind, 1);
    this.fileUploadRequest--;
    if (this.fileUploadRequest == 0) {
      this.spin.hide();
    }
    if (response) {
      let suc = JSON.parse(response);
      this.uploadSummary.push({
        status: 'error',
        fileName: item.file.name,
        message: suc.message,
      });
    }else{
      this.uploadSummary.push({
        status: 'error',
        fileName: item.file.name,
        message: 'An unexpected error has occurred. Please try again.',
      });
    }

  }

  get f() { return this.NewUnderWriting.controls; }

  get appInfo(): any { return this.NewUnderWriting.get('appInfo'); }

  get contactInfo(): any { return this.NewUnderWriting.get('contactInfo'); }

  get coversInfo(): any { return this.NewUnderWriting.get('coversInfo'); }

  get documentInfo(): any { return this.NewUnderWriting.get('documentInfo'); }

  get additionalinfo(): any { return this.NewUnderWriting.get('additionalinfo'); }

  get submittedBy(): any { return this.NewUnderWriting.get('submittedBy'); }

  removeEmptyKeys(Obj) {
    var clone = Object.assign({}, Obj);
    Object.keys(clone).forEach((key) => {
      if (clone[key] === '' || clone[key] === null || !clone[key]) {
        delete clone[key]
      }
      if (clone[key] !== '' && clone[key] !== null && clone[key] && clone[key].indexOf(',') > -1) {
        clone[key] = clone[key].replace(/(,)/g, '')
      }
    });
    if (Object.keys(clone).length > 1) { this.submitObj.coversInfo.push(clone); }
  }

  formSubmit() {
    console.log(this.submitObj)
    this.submitted = true;

    if(this.submitObj.fundCode=='MTAA' || this.submitObj.fundCode=='MTAS') { this.insScale = true; }
    if(this.deathCoverChecked) { this.DC_Cover = true; }
    if(this.IpCoverChecked) { this.IP_Cover = true; }
    if(this.disabilityCoverChecked) { this.TPD_Cover = true; }
        
    this.submitObj.dateOfBirth = (this.appInfo.value.dob) ? moment(new Date(this.appInfo.value.dob)).format('YYYY-MM-DD') : null;
    this.submitObj.dateJoinedFund = (this.appInfo.value.dojFund) ? moment(new Date(this.appInfo.value.dojFund)).format('YYYY-MM-DD') : null;
    this.submitObj.dateJoinedCompany = (this.appInfo.value.dojCompany) ? moment(new Date(this.appInfo.value.dojCompany)).format('YYYY-MM-DD') : null;

    this.submitObj.coversInfo = [];

    this.removeEmptyKeys(this.deathCoverInfo);
    this.removeEmptyKeys(this.disabilityCoverInfo);
    if (this.IpCoverChecked) {
      this.removeEmptyKeys(this.IpCoverInfo);
    }

    if (!this.appInfo.valid) { $('#collapseOne').addClass('show'); }
    if (!this.contactInfo.valid) { $('#collapseSix').addClass('show'); }
    if (this.deathCoverChecked === false && this.disabilityCoverChecked === false
      && this.IpCoverChecked === false) {
      $('#collapseTwo').addClass('show');
    }
    this.appformLength = this.tableData.filter(x => x.documentTypeName == 'Application Form').length;
    if (this.appformLength == 0) { $('#collapseThree').addClass('show'); }

    if (this.NewUnderWriting.valid && (this.deathCoverChecked === true || this.disabilityCoverChecked === true || this.IpCoverChecked === true) && this.submitObj.gender != '') {
      if (this.uploader.queue.length > 0) {
        this.upload();
      } else {
        this.onSubmit();
      }
    } else {
      setTimeout(() => {
        this.enableFocusForError();
      }, 200);
    }
  }

  onSubmit() {
    this.errorMsg.hideErrorMessage();
    this.appformLength = this.submitObj.documentInfo.filter(x => x.docType == 'Application Form').length;
    if (this.appformLength == 0) { $('#collapseThree').addClass('show'); }
    if (this.submitObj.documentInfo.length > 0 && this.submitObj.documentInfo[0].documentLocation != '' && this.appformLength > 0) {
      let CheckObj = {
        firstName: this.submitObj.firstName,
        surName: this.submitObj.lastName,
        dateOfBirth: this.submitObj.dateOfBirth,
        applicationType: "NewUW"
      }

      this.api.checkLodgement(this.conf.URLS.commonUrl.lodgementcheck, CheckObj).subscribe(result => {

        if (result == 'false' || result == false) {
          this.actualSubmit();
        } else {

          let ngbModalOptions: NgbModalOptions = {
            backdrop: 'static',
            keyboard: false
          };
          const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
          m.componentInstance.Title = 'Confirmation!';
          m.componentInstance.confMessage = 'An application with the same First Name, Surname and DOB has been previously submitted within the last 72 hours, are you sure you want to submit?';
          let res = this.BooleanConverter(m.result);
          res.then((userResponse) => {
            if (userResponse == true) {
              this.submitObj.confirmHrs = true;
              this.actualSubmit();
            }
          });

        }
      }, err => {
        this.errorMsg.showErrorMessage();
      })
    } else {
      setTimeout(() => {
        this.enableFocusForError();
      }, 200);
    }

  }

  enableFocusForError() {
    var firstErrorElement = $('.error_div div.text-danger').eq(0);
    var claimTypeError = $('.claimTypeError');
    var fileUploadError = $('.fileUploadError');
    if (firstErrorElement.length) {
      var select = $('.error_div div.text-danger').eq(0).parent('.error_div').find('select');
      var input = $('.error_div div.text-danger').eq(0).parent('.error_div').find('input');
      var button = $('.error_div div.text-danger').eq(0).parent('.error_div').find('button');
      if (select.length > 0) {
        $('.error_div div.text-danger').eq(0).parent('.error_div').find('select').focus();
      }
      if (input.length > 0) {
        if (input.length > 1) {
          $('.error_div div.text-danger').eq(0).parent('.error_div').find('input')[0].focus();
        } else {
          $('.error_div div.text-danger').eq(0).parent('.error_div').find('input').focus();
        }
      }
      if (button.length > 0) {
        $('.error_div div.text-danger').eq(0).parent('.error_div').find('button').eq(0).focus();
      }
    } else if (claimTypeError.length == 1) {
      $('.claim-info').eq(0).find('input').focus();
    } else if (fileUploadError.length == 1) {
      $('#filterSearch').focus();
    }
  }

  actualSubmit() {
    this.errorMsg.hideErrorMessage();
    this.api.add(this.conf.URLS.underwriting.addUnderwriting, this.submitObj).subscribe(result => {
      if (result) {
        this.isDirty = false;
        this.resetForm(2);
        $('#submittedModal').show();
      } else {
        this.errorMsg.showErrorMessage();
      }
    },
      err => {
        this.errorMsg.showErrorMessage();
      })
  }

  getFundPlan() {
    this.api.get(this.conf.URLS.commonUrl.fundList).subscribe(result => {
      this.fundDetails = result;
    });
  }
  getCategory() {
    this.api.get(this.conf.URLS.commonUrl.categoryList).subscribe(result => {
      this.categoryList = result;
    });
  }
  getDoc() {
    this.api.get(this.conf.URLS.commonUrl.documentList).subscribe(result => {
      this.docList = result;
      this.selectedDoc = this.docList.filter(x => x.documentTypeName.toLowerCase() == 'application form');
      this.RefselectedDoc = this.docList.filter(x => x.documentTypeName.toLowerCase() == 'application form');
      this.selectedDocId.push(this.selectedDoc[0].documentTypeID);
      this.docList = this.docList.filter(x => x.documentTypeName.toLowerCase() != 'application form');
    });
  }
  delUploaded(docloc) {
    this.api.add(this.conf.URLS.fileUrl.deleteFile + '?filepath=' + docloc, '').subscribe(data => {
      return true;
    });
  }
  changeClass($event, id) {
    if (id === 'maleBtn') {
      this.submitObj.gender = 'Male';
    } else if (id === 'femaleBtn') { this.submitObj.gender = 'Female'; }
    else { this.submitObj.gender = 'Other'; }
    $('#genderDiv button').removeClass('btn btn-lg btn-primary active').addClass('btn btn-lg btn-default');
    document.getElementById(id).className = 'btn btn-lg btn-primary active';

  }
  setCustomError(arr) {
    arr.forEach(data => {
      this.coversInfo.controls[data].setErrors(null);
      this.coversInfo.controls[data].reset();
    })
  }
  CoverChecked(event, val) {
    if (val === 'death') {
      this.deathCoverChecked = event.target.checked;
      if (event.target.checked === false) {
        const arr1 = ['coverOpt', 'units', 'additionalUnits', 'totalExistCovers', 'totalReqCovers', 'additionalCoverOpt'];
        this.setCustomError(arr1);
        this.deathCoverInfo = this.DTHdup;
        this.showHide['unitShow'] = false;
        this.showHide['ageBasedShow'] = false;
        this.showHide['additionalUnitShow'] = false;
        this.showHide['additionalAgeBasedShow'] = false;
        this.totalCoverValue[1] = [];
      }
    }
    if (val === 'disability') {
      this.disabilityCoverChecked = event.target.checked;
      if (event.target.checked === false) {
        const arr1 = ['dis_coverOpt', 'dis_units', 'dis_additionalUnits', 'dis_totalExistCovers', 'dis_totalReqCovers', 'dis_additionalCoverOpt'];
        this.setCustomError(arr1);
        this.disabilityCoverInfo = this.TPDdup;
        this.showHide['dis_unitShow'] = false;
        this.showHide['dis_ageBasedShow'] = false;
        this.showHide['dis_additionalUnitShow'] = false;
        this.showHide['dis_additionalAgeBasedShow'] = false;
        this.totalCoverValue[2] = [];
      }
    }
    if (val === 'income') {
      this.IpCoverChecked = event.target.checked;
      if (event.target.checked === false) {
        const arr1 = ['Ip_coverOpt', 'Ip_units', 'Ip_additionalUnits', 'Ip_totalExistCovers', 'Ip_totalReqCovers', 'Ip_additionalCoverOpt'];
        this.setCustomError(arr1);
        this.coversInfo.patchValue({
          ReqWaitPeriod: '', ReqBenefPeriod: '', ExistWaitPeriod: '', ExistBenefPeriod: ''
        });
        this.IpCoverInfo = this.IPCdup;
        this.submitObj.coversInfo.forEach((key) => {
          if (key.coverCode == 'IPC') {
            delete key.totalRequestedCover;
          }
        });
        this.showHide['Ip_unitShow'] = false;
        this.showHide['Ip_additionalUnitShow'] = false;
        this.totalCoverValue[3] = [];
      }
    }
  }
  coverOption(event, val1, key1, val2, key2) {
    if (event.target.value === '2') {
      this.showHide[val1] = true;
      this.showHide[val2] = false;
      if (key2) {
        this.coversInfo.controls[key2].setErrors(null);
        this.coversInfo.controls[key2].reset();
      }
    }
    else if (event.target.value === '3') {
      this.showHide[val1] = false;
      this.showHide[val2] = true;
      this.coversInfo.controls[key1].setErrors(null);
      this.coversInfo.controls[key1].reset();
    }
    else {
      this.showHide[val1] = false;
      this.coversInfo.controls[key1].setErrors(null);
      this.coversInfo.controls[key1].reset();
      if (val2) { this.showHide[val2] = false; }
      if (key2) {
        this.coversInfo.controls[key2].setErrors(null);
        this.coversInfo.controls[key2].reset();
      }
    }
  }

  // changeDecimal(event,name) {
  //   let val = this.fixPosStr(event.target.value);
  //   this.coversInfo.controls[name].setValue(val);
  // }

  fixPosStr(val) {
    if (val != '') {
      let value = val.replace(/(,)/g, '')
      value = Number(value).toFixed(2);
      let amount = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
      if ((amount == NaN) || (amount == 'nan') || (amount == 'NaN')) {
        return '';
      }
      else return amount;
    }
  }
  addExistingReq(event, key1, key2, val, ids) {
    if (this.coversInfo.controls[key1].value === undefined) { this.coversInfo.controls[key1].value = 0; }
    if (this.coversInfo.controls[key2].value === undefined) { this.coversInfo.controls[key2].value = 0; }
    if (event != '' && event.target.value) {
      let vals1 = event.target.value.replace(/(,)/g, '').split('.');
      let vals2 = this.coversInfo.controls[key1].value.replace(/(,)/g, '').split('.');
      let vals3 = this.coversInfo.controls[key2].value.replace(/(,)/g, '').split('.');
      if (vals1[0].length > 16) {
        event.target.value = event.target.value.substr(0, 16)
      }
      if (vals2[0].length > 16) {
        this.coversInfo.controls[key1].value = this.coversInfo.controls[key1].value.substr(0, 16)
      }
      if (vals3[0].length > 16) {
        this.coversInfo.controls[key2].value = this.coversInfo.controls[key2].value.substr(0, 16)
      }
    }

    let val1 = (this.coversInfo.controls[key1].value) ? parseFloat(this.coversInfo.controls[key1].value.replace(/(,)/g, '')) : 0;
    let val2 = (this.coversInfo.controls[key2].value) ? parseFloat(this.coversInfo.controls[key2].value.replace(/(,)/g, '')) : 0;

    this.totalCoverValue[val] = val1 + val2;
    this.totalCoverValue[val] = this.fixPosStr(this.totalCoverValue[val].toString());
    if (val == 1) {
      this.deathCoverInfo.totalRequestedCover = this.totalCoverValue[val];
    } else if (val == 2) {
      this.disabilityCoverInfo.totalRequestedCover = this.totalCoverValue[val];
    } else if (val == 3) {
      this.IpCoverInfo.totalRequestedCover = this.totalCoverValue[val];
    }
    if (event != '' && event.target.value) { event.target.value = this.fixPosStr(event.target.value); }
    if (ids == 'totalExistCoversId') { this.deathCoverInfo.existingCoverAmount = event.target.value; }
    else if (ids == 'totalReqCoversId') { this.deathCoverInfo.additionalCoverAmount = event.target.value; }

    else if (ids == 'dis_totalExistCoversId') { this.disabilityCoverInfo.existingCoverAmount = event.target.value; }
    else if (ids == 'dis_totalReqCoversId') { this.disabilityCoverInfo.additionalCoverAmount = event.target.value; }

    else if (ids == 'Ip_totalExistCoversId') { this.IpCoverInfo.existingCoverAmount = event.target.value; }
    else if (ids == 'Ip_totalReqCoversId') { this.IpCoverInfo.additionalCoverAmount = event.target.value; }
  }

  isValDigitDot(event) {
    const key = (event.which) ? event.which : event.keyCode;
    if (!((key > 47 && key <= 57) || ( key == 8) || ( key == 0) || (key == 127) || (key == 9) || (key == 13) || (key == 46) )) {
        return false;
    } else if (key == 46) {
          if ((event.target.value) && (event.target.value.indexOf('.') >= 0)) {
            return false;
          } else {
            return true;
          }
    } else if ( key > 47 && key <= 58) {
      var actLength = (event.target.value.length)+1;
      var dotIndex = event.target.value.indexOf('.');
      if (dotIndex < 0 && actLength <= 3) {
        return true;
      } else if (dotIndex >= 0) {
        var textAvailNow = event.target.value;
        var textString = textAvailNow.toString();
        var afterDecimal = textString.split(".")[1];
        var actualLenAfterDecimal = (afterDecimal.length)+1;
        if (actualLenAfterDecimal > 2) {
          return false;
        } else {
          return true;
        }
      } else {
        return false;
      }
    }
        return true;
  }

  numberOnly(event, type, maxLength): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (type === '2' && charCode === 46 && event.target.value.split('.').length === 2) { return false; }
    if (type === '2' && charCode > 31 && (charCode < 46 || charCode === 47 || charCode > 57)) {
      return false;
    } else if (type === '1' && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    if (event.target.value.length >= maxLength) {
      return false;
    }
    return true;
  }
  checkErr(event) {
    if (event.target.checked === false) {
      if (this.submittedBy.controls['emailId'].getError('required')) {
        this.submittedBy.controls['emailId'].setErrors(null);
      }
      this.chekErr = false;
    }
    if (event.target.checked === true) {
      if (this.submittedBy.controls['emailId'].value == null || this.submittedBy.controls['emailId'].value == '') {
        this.submittedBy.controls['emailId'].setErrors({ 'required': true });
      }
      this.chekErr = true;
    }
  }
  copyCover(event) {
    if (event.target.checked === true) {
      if (this.coversInfo.controls['deathCover'].value == true) {
        this.showHide['dis_unitShow'] = this.showHide['unitShow'];
        this.showHide['dis_additionalUnitShow'] = this.showHide['additionalUnitShow'];

        this.showHide['dis_ageBasedShow'] = this.showHide['ageBasedShow'];
        this.showHide['dis_additionalAgeBasedShow'] = this.showHide['additionalAgeBasedShow'];

        this.coversInfo.patchValue({
          dis_coverOpt: this.coversInfo.controls['coverOpt'].value,
          dis_additionalCoverOpt: this.coversInfo.controls['additionalCoverOpt'].value,
          dis_totalExistCovers: this.coversInfo.controls['totalExistCovers'].value,
          dis_totalReqCovers: this.coversInfo.controls['totalReqCovers'].value,
        });
        this.disabilityCoverInfo.existingCoverUnits = this.coversInfo.controls['units'].value;
        this.disabilityCoverInfo.additionalCoverUnits = this.coversInfo.controls['additionalUnits'].value;

        this.disabilityCoverInfo.existingAgeFactor = this.coversInfo.controls['ageBased'].value;
        this.disabilityCoverInfo.additionalAgeFactor = this.coversInfo.controls['additionalAgeBased'].value;

        this.addExistingReq('', 'dis_totalExistCovers', 'dis_totalReqCovers', '2', 'dis');
      }
    }
  }
  fundChange(event) {
    if (event.target.value === 'MTAA' || event.target.value === 'MTAS') {
      this.contactInfo.controls['insuranceScale'].setErrors({ 'required': true });
      $('#InsDiv').show();
    } else {
      $('#InsDiv').hide();
      this.contactInfo.controls['insuranceScale'].setErrors(null);
      this.submitObj.contactInfo[0].insuranceScale = '';
      this.submitObj.contactInfo[0].rolloverPending = '';
    }
  }
  hideModal() {
    this.isDirty = false;
    $('#submittedModal').hide();
    $('html, body').animate({ scrollTop: $('#selectfundplan').position().top }, 'slow');
  }
  filterSearch(event) {
    this.searchVal = event.target.value;
  }
  movetoRight(id) {
    this.selectedDocId.push(id.documentTypeID);
    this.selectedDoc.push(id);
  }
  movetoLeft(id) {
    if (id.documentTypeName.toLowerCase() == 'application form') {
      if (this.docList.findIndex(x => x.documentTypeName.toLowerCase() == 'application form') == -1) {
        this.docList.unshift(id);
      }
    }
    this.selectedDocId.splice(this.selectedDocId.indexOf(id.documentTypeID), 1);
    this.selectedDoc = this.selectedDoc.filter(x => x.documentTypeID != id.documentTypeID);
  }
  dateRangeOnly(event) {
    if (event.keyCode === 47) {
      return;  // let divide allow
    }
    const regEx = this.conf.appConstants.regEx.dateRangeOnly;
    return event.key.match(regEx) ? true : false;
  }
}