import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { SubmitNewUnderwritingComponent } from './submit-new-underwriting.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { FileUploadModule } from 'ng2-file-upload';
import { AppConfiguration } from '../../../app-configuration';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DebugElement } from '@angular/core';
import { AlertModule } from 'ngx-bootstrap';
import { FlashMessagesService } from 'angular2-flash-messages';

describe('SubmitNewUnderwritingComponent', () => {
  let component: SubmitNewUnderwritingComponent;
  let fixture: ComponentFixture<SubmitNewUnderwritingComponent>;
  let de: DebugElement;
  let el:HTMLElement;

  beforeEach(async(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 200000;
    TestBed.configureTestingModule({
      declarations: [ SubmitNewUnderwritingComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        DateRangePickerModule,
        DatePickerModule,
        FileUploadModule,
        RouterTestingModule,
        HttpClientTestingModule,
        AlertModule
      ],
      providers:[
        AppConfiguration,
        FlashMessagesService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmitNewUnderwritingComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('form'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set submitted to true',async(() =>{
    component.formSubmit();
    expect(component.submitted).toBeTruthy();
  }));
  
  it('should call the onsubmit method',async(() => {
    fixture.detectChanges();
    spyOn(component,'formSubmit');
    el = fixture.debugElement.query(By.css('#submitBtn')).nativeElement;
    el.click();
    expect(component.formSubmit).toHaveBeenCalledTimes(1);
  }));

  it('form should be reset',(() => {
    el = fixture.debugElement.query(By.css('#resetBtn')).nativeElement;
    el.click();
    expect(component.resetForm).toBeTruthy();
  }));
  
  it('form should be valid',(() => {
    component.appInfo.controls['refNo'].setValue('1234');
    component.appInfo.controls['fundPlan'].setValue('4CAB');
    component.appInfo.controls['appCategory'].setValue('4');
    component.appInfo.controls['Title'].setValue('Mr');
    
    component.appInfo.controls['fName'].setValue('fname');
    component.appInfo.controls['surName'].setValue('lname');
    component.appInfo.controls['dob'].setValue('2019-05-05');
    component.appInfo.controls['dojFund'].setValue('2019-05-05');
    component.appInfo.controls['dojCompany'].setValue('2019-05-05');

    component.contactInfo.controls['address1'].setValue('coimbatore');
    component.contactInfo.controls['address2'].setValue('India');
    component.contactInfo.controls['suburb'].setValue('Suburb');  
    component.contactInfo.controls['state'].setValue('TN');
    component.contactInfo.controls['postCode'].setValue('1234');
    component.contactInfo.controls['contact'].setValue('9876543210');
    component.contactInfo.controls['applicantEmail'].setValue('test@test.in');
    component.contactInfo.controls['preferedTOC'].setValue('321');
    
    component.coversInfo.controls['deathCover'].setValue(true);
    component.coversInfo.controls['coverOpt'].setValue("1");
    component.coversInfo.controls['totalExistCovers'].setValue("2");
    component.coversInfo.controls['additionalCoverOpt'].setValue("2");

    component.additionalinfo.controls['additionalInfo'].setValue("Additional Info");
    component.additionalinfo.controls['confirmationMail'].setValue(true);

    component.submittedBy.controls['Name'].setValue("Additional Info");
    component.submittedBy.controls['emailId'].setValue('test@test.in');
    component.submittedBy.controls['phNo'].setValue("9876543210");

    expect(component.NewUnderWriting.valid).toBeTruthy();
  }));

  it('alphabhets only',(() => {
    expect(component.appInfo.controls['fName']).not.toContain(Number);
    expect(component.appInfo.controls['surName']).not.toContain(Number);
    expect(component.contactInfo.controls['suburb']).not.toContain(Number);
  }));

  // it('email validation',(() => {
  //   expect(component.submittedBy.controls['emailId'].value).toMatch(/\S+@\S+\.\S+/);
  // }))
  it('form should be invalid',(() => {
    component.appInfo.controls['refNo'].setValue('');
    component.appInfo.controls['fundPlan'].setValue('');
    component.appInfo.controls['appCategory'].setValue('');
    component.appInfo.controls['Title'].setValue('');
    component.appInfo.controls['fName'].setValue('');
    component.appInfo.controls['surName'].setValue('');
    component.appInfo.controls['dob'].setValue('');
    component.appInfo.controls['dojFund'].setValue('');
    component.appInfo.controls['dojCompany'].setValue('');
    component.contactInfo.controls['address1'].setValue('');
    component.contactInfo.controls['address2'].setValue('');
    component.contactInfo.controls['suburb'].setValue('');  
    component.contactInfo.controls['state'].setValue('');
    component.contactInfo.controls['postCode'].setValue('');
    component.contactInfo.controls['contact'].setValue('');
    component.contactInfo.controls['applicantEmail'].setValue('');
    component.contactInfo.controls['preferedTOC'].setValue('');
    component.coversInfo.controls['deathCover'].setValue();
    component.coversInfo.controls['coverOpt'].setValue("");
    component.coversInfo.controls['totalExistCovers'].setValue("");
    component.coversInfo.controls['additionalCoverOpt'].setValue("");
    component.additionalinfo.controls['additionalInfo'].setValue("");
    component.additionalinfo.controls['confirmationMail'].setValue();
    component.submittedBy.controls['Name'].setValue("");
    component.submittedBy.controls['emailId'].setValue('');
    component.submittedBy.controls['phNo'].setValue("");
    expect(component.NewUnderWriting.valid).toBeFalsy();
  }));

});
