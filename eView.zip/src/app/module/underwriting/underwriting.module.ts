import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FileUploadModule } from 'ng2-file-upload';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { NgxPaginationModule } from 'ngx-pagination';
import { AlertModule } from 'ngx-bootstrap';

import { FeatureToggleGuard } from '../../guards/feature-toggle-guard.guard';
import { ValidateGuard } from '../../guards/validate.guard';
import { CanDeactivateGuard } from '../../guards/can-deactivate.guard';
import { CustomDirectiveModule } from '../../directives/custom-directive/custom-directive.module';
import { SubmitNewUnderwritingComponent } from './submit-new-underwriting/submit-new-underwriting.component';

const routes: Routes = [
  { path: 'status', loadChildren: './status/status.module#StatusModule', canActivate: [ValidateGuard, FeatureToggleGuard], data: { permissionId: ['eQuery_UWStatusRpt', 'Underwriting_UWStatusRept'], featureToggleKey: 'uwStatus' } },
  { path: 'sla', loadChildren: './sla/sla.module#SlaModule', canActivate: [ValidateGuard, FeatureToggleGuard], data: { permissionId: ['eQuery_UWSLARpt', 'Underwriting_UWSLARept'], featureToggleKey: 'uwSla' } },
  { path: 'requirement', loadChildren: './requirement/requirement.module#RequirementModule', canActivate: [ValidateGuard, FeatureToggleGuard], data: { permissionId: ['eQuery_UWReqRpt', 'Underwriting_UWReqRept'], featureToggleKey: 'uwRequirement' } },
  { path: 'submit-new-underwriting', component: SubmitNewUnderwritingComponent, canActivate: [ValidateGuard, FeatureToggleGuard], canDeactivate: [CanDeactivateGuard], data: { permissionId: ['eLodgement_SubmitUnderwriting', 'Underwriting_SubmitNewUnderwriting'], featureToggleKey: 'uwSubmitNew' } }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    FileUploadModule,
    DateRangePickerModule,
    DatePickerModule,
    NgxPaginationModule,
    AlertModule.forRoot(),
    CustomDirectiveModule
  ],
  declarations: [
    SubmitNewUnderwritingComponent
  ]
})
export class UnderwritingModule { }