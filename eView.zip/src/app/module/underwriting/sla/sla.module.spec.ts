import { SlaModule } from './sla.module';

describe('SlaModule', () => {
  let slaModule: SlaModule;

  beforeEach(() => {
    slaModule = new SlaModule();
  });

  it('should create an instance', () => {
    expect(slaModule).toBeTruthy();
  });
});
