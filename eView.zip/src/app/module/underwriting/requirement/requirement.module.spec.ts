import { RequirementModule } from './requirement.module';

describe('RequirementModule', () => {
  let requirementModule: RequirementModule;

  beforeEach(() => {
    requirementModule = new RequirementModule();
  });

  it('should create an instance', () => {
    expect(requirementModule).toBeTruthy();
  });
});
