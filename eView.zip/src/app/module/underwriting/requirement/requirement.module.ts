import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { Ng2CompleterModule } from "ng2-completer";
import { FileUploadModule } from 'ng2-file-upload';

import { ReportsComponent } from './reports/reports.component';
import { DetailsComponent } from './details/details.component';
import { ReportDetailsService } from '../../../service/underwriting/report-details.service';
import { ValidateGuard } from '../../../guards/validate.guard';
import { CustomDirectiveModule } from '../../../directives/custom-directive/custom-directive.module';

const routes: Routes = [
  {
    path: '', component: ReportsComponent, canActivate: [ValidateGuard],
    data: {
      reportURL: 'requirementReports',
      permissionId: ['eQuery_UWReqRpt', 'Underwriting_UWReqRept']
    }
  },
  {
    path: 'reports', component: ReportsComponent, canActivate: [ValidateGuard],
    data: {
      reportURL: 'requirementReports',
      permissionId: ['eQuery_UWReqRpt', 'Underwriting_UWReqRept']
    }
  },
  {
    path: 'reports/:id/:fund', component: DetailsComponent, canActivate: [ValidateGuard],
    resolve: {
      details: ReportDetailsService
    },
    data: {
      reportType: 'requirement',
      permissionId: ['eQuery_UWReqRpt', 'Underwriting_UWReqRept']
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(routes),
    DateRangePickerModule,
    DatePickerModule,
    NgxPaginationModule,
    Ng2SmartTableModule,
    Ng2CompleterModule,
    FileUploadModule,
    CustomDirectiveModule
  ],
  declarations: [ReportsComponent, DetailsComponent]
})
export class RequirementModule { }