import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { DetailsComponent } from './details.component';
import { AppConfiguration } from '../../../../app-configuration';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FileUploadModule } from 'ng2-file-upload';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { Ng2CompleterModule } from "ng2-completer";
import { SearchModel } from '../../../../service/search-model';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

describe('DetailsComponent', () => {
  let component: DetailsComponent;
  let fixture: ComponentFixture<DetailsComponent>;
  const route = ({ snapshot:{data:{details: {   
    applicationInfo:{  
       "applicationDate":"2018-10-09T21:29",
       "applicationNo":476941,
       "coverType":null,
       "fundCode":"HOST",
       "fundName":"HOSTPLUS",
       "lastActionDate":null,
       "status":"Open",
       "source":"Import",
       "applicationDetails":{  
          "category":"New Application",
          "coversInfo":[  
             {  
                "coverCode":"Trauma",
                "current":null,
                "decision":null,
                "loading":null,
                "proposed":null,
                "requestBenefitPeriod":null,
                "requestWaitPeriod":null,
                "approved":null
             }
          ],
          "decisionLetterPath":null,
          "source":"Import",
          "underWriter":"Tamilarasan, Anbumallika",
          "eApplyRefNo":"N_476941",
          "finalised":null
       }
    },
    eventInfo:[],
    memberInfo:{},
    requirementInfo:[],
    slaEventInfo:[]
} } } } as any) as ActivatedRoute

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        FileUploadModule,
        Ng2SmartTableModule,
        Ng2CompleterModule
      ],
      declarations: [ DetailsComponent ],
      providers: [
        AppConfiguration,
        FlashMessagesService,
        SearchModel,
        CurrencyPipe,
        DatePipe,
        { provide: ActivatedRoute, useValue: route }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
