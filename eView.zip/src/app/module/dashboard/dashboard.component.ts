import { Component, OnInit } from '@angular/core';
import { MenuService } from '../../service/menu/menu.service';
import { Router } from '@angular/router';
import { ModalComponent } from '../../layout/modal/modal.component';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  menuItems: Array<any>;
  userPermissions;
  showUWTabByDefault:boolean;
  public modalRef: BsModalRef;

  constructor(public menu: MenuService,private router: Router, private modalService: BsModalService) {    
    this.menuItems = menu.getMenu();
    let perm  = (JSON.parse(sessionStorage.getItem('userDetails')).menus)?JSON.parse(sessionStorage.getItem('userDetails')).menus:[];
    this.userPermissions = perm.join(',');
 
    this.checkPwdExpiry();
  }

  checkPwdExpiry() {
    let userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
    if (userDetails && userDetails.pwdChangedTime && sessionStorage.getItem('passwordExpiryPopup') == 'yes') {
      let DateTimeApi = userDetails.pwdChangedTime;
      let today = new Date(new Date().toDateString());
      let pwdChangedDate = new Date();
      pwdChangedDate.setFullYear(DateTimeApi.slice(0,4));
      pwdChangedDate.setMonth(DateTimeApi.slice(4,6)-1); 
      pwdChangedDate.setDate(DateTimeApi.slice(6,8));
      
      let Difference_In_Time = today.getTime() - pwdChangedDate.getTime(); 
      let Difference_In_Days = Math.floor(Difference_In_Time / (1000 * 3600 * 24))+1;
      if(Difference_In_Days >= 54 && Difference_In_Days < 61) {
        this.modalRef = this.modalService.show(ModalComponent, { animated: true, keyboard: true, backdrop: true, ignoreBackdropClick: false });
        this.modalRef.content.type = "PASSWORD_EXPIRY";
        this.modalRef.content.days = 60 - Difference_In_Days;
        sessionStorage.setItem('passwordExpiryPopup','no');
      }
    }
  }

  ngOnInit() {
//UW
let UWSubmit = this.userPermissions.indexOf('eLodgement_SubmitUnderwriting') > -1 || this.userPermissions.indexOf('Underwriting_SubmitNewUnderwriting') > -1;
let UWStatusRpt = this.userPermissions.indexOf('eQuery_UWStatusRpt') > -1 || this.userPermissions.indexOf('Underwriting_UWStatusRept') > -1;
let UWReqRpt = this.userPermissions.indexOf('eQuery_UWReqRpt') > -1 || this.userPermissions.indexOf('Underwriting_UWReqRept') > -1;
let UWSLARpt = this.userPermissions.indexOf('eQuery_UWSLARpt') > -1 || this.userPermissions.indexOf('Underwriting_UWSLARept') > -1;
//Claims
let claimsSubmit = this.userPermissions.indexOf('eLodgement_SubmitClaim') > -1 || this.userPermissions.indexOf('Claims_SubmitNewClaim') > -1;
let claimsStatusRpt = this.userPermissions.indexOf('eQuery_ClaimsStatusRpt') > -1 || this.userPermissions.indexOf('Claims_ClaimsStatusRpt') > -1;
let claimsReqRpt = this.userPermissions.indexOf('eQuery_ClaimsReqRpt') > -1 || this.userPermissions.indexOf('Claims_ClaimsReqRpt') > -1;
let claimsSLARpt = this.userPermissions.indexOf('eQuery_ClaimsSLARpt') > -1 || this.userPermissions.indexOf('Claims_ClaimsSLARpt') > -1;
let claimsPaymentRpt = this.userPermissions.indexOf('eQuery_ClaimsPaymentRpt') > -1 || this.userPermissions.indexOf('Claims_ClaimsPaymentRpt') > -1;
let claimsValidate = this.userPermissions.indexOf('eClaims_ValidateClaim') > -1 || this.userPermissions.indexOf('Claims_ValidateClaim') > -1;

let claimsEnabled = claimsSubmit || claimsStatusRpt || claimsReqRpt || claimsSLARpt || claimsPaymentRpt || claimsValidate;
this.showUWTabByDefault = !claimsEnabled;

if(!UWSubmit && !UWStatusRpt && !UWReqRpt && !UWSLARpt && !claimsSubmit && !claimsStatusRpt && !claimsReqRpt && !claimsSLARpt && !claimsPaymentRpt && !claimsValidate){
  
  if(this.userPermissions.indexOf('eApply_eApply') >= 0 || this.userPermissions.indexOf('EApply_Corporate') >= 0){
    this.router.navigate(['/eapply-corporate']);
  }else if(this.userPermissions.indexOf('SharedDocuments_MemberFileUpload') >= 0 || this.userPermissions.indexOf('SharedDocuments_SearchDocuments') >= 0 || this.userPermissions.indexOf('SharedDocuments_ManageDocuments') >= 0){
    this.router.navigate(['/shared-documents/reports']);
  }else if(this.userPermissions.indexOf('UserManagement_CreateNewUser') >= 0){
    this.router.navigate(['/users/create']);
  }else if(this.userPermissions.indexOf('UserManagement_SearchUpdateUser') >= 0){
    this.router.navigate(['/users/update-user/reports']);
  }else if(this.userPermissions.indexOf('Steadfast_Steadfast') >= 0){
    this.router.navigate(['/steadfast']);
  }    

}     
  }

}
