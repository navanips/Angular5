import { Component, OnInit } from '@angular/core';
import { AppConfiguration } from '../../app-configuration';
@Component({
  selector: 'app-steadfast',
  templateUrl: './steadfast.component.html',
  styleUrls: ['./steadfast.component.css']
})
export class SteadfastComponent implements OnInit {

 appExternalURLS : any;
  constructor(private appConfig: AppConfiguration) {
    this.appExternalURLS = appConfig.externalURLS;
   }
  ngOnInit() {
  }

}
