import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppConfiguration } from '../../app-configuration';
import { SteadfastComponent } from './steadfast.component';

describe('SteadfastComponent', () => {
  let component: SteadfastComponent;
  let fixture: ComponentFixture<SteadfastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SteadfastComponent ],
      providers: [
        AppConfiguration
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SteadfastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

 
});
