import { Component, OnInit } from '@angular/core';
import { AppConfiguration } from '../../app-configuration';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-session-expired',
  templateUrl: './session-expired.component.html',
  styleUrls: ['./session-expired.component.css']
})
export class SessionExpiredComponent implements OnInit {

  appExternalURLS: any;
  constructor(private conf: AppConfiguration, private titleService: Title) { 
    this.appExternalURLS = conf.externalURLS;
    this.titleService.setTitle("Session timeout | eView - MetLife"); 
  }

  ngOnInit() {
  }

}
