import { Component, OnInit } from '@angular/core';
import { AppConfiguration } from '../../app-configuration';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RestApiService } from '../../service/rest-api.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-eapply-corporate',
  templateUrl: './eapply-corporate.component.html',
  styleUrls: ['./eapply-corporate.component.css']
})
export class EapplyCorporateComponent implements OnInit {
  fundList: any;
  userID: any;
  corporatePath:any;
  submitted: boolean;
  eApplyForm = new FormGroup({
    fundName: new FormControl('', Validators.required)
  });
  userPermissions;
  constructor(private appConfig: AppConfiguration, private http: RestApiService) {
    const perm  = (JSON.parse(sessionStorage.getItem('userDetails')).menus) ? JSON.parse(sessionStorage.getItem('userDetails')).menus : [];
    this.userPermissions = perm.join(',');
  }

  ngOnInit() {
    this.submitted = false;
    this.http.get(this.appConfig.URLS.commonUrl.fundList).subscribe(data => {
      this.fundList = data;
    });
    let env = window.location.origin;
    //let env = 'http://www.dit.eservice.metlife.com.au';
    this.corporatePath = env.replace('eservice','eapplication');
  }

  isValidFund() { return this.eApplyForm.controls['fundName'].valid; }
  fundName() { return this.eApplyForm.controls['fundName'].value; }

  launcheApply() {
    this.submitted = true;
    if (this.fundName()) {
      window.open(this.corporatePath + this.appConfig.externalURLS.eApply.apply + this.fundName(), "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=100,left=100,width=900,height=600");
    }
  }

  launchOnboard() {
    this.submitted = true;
    this.userID = JSON.parse(sessionStorage.getItem('userDetails'));
    if (this.fundName()) {
      const fundvalue = $( '#fundName option:selected' ).text();
      window.open(this.corporatePath + this.appConfig.externalURLS.eApply.onboard + this.fundName()+'&userid=' + this.userID.userName + '&PartnerName=' + fundvalue, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=100,left=100,width=900,height=600");
    }
  }

  launchDashboard() {
    this.submitted = true;
    if (this.fundName()) {
      window.open(this.corporatePath + this.appConfig.externalURLS.eApply.dashboard + this.fundName(), "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=100,left=100,width=900,height=600");
    }
  }
}
