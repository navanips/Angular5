import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppConfiguration } from '../../app-configuration';
import { By } from '@angular/platform-browser';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { EapplyCorporateComponent } from './eapply-corporate.component';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('EapplyCorporateComponent', () => {
  let component: EapplyCorporateComponent;
  let fixture: ComponentFixture<EapplyCorporateComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      declarations: [ EapplyCorporateComponent ],
      providers: [AppConfiguration],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EapplyCorporateComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('formGroup'));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should fund name field need to exist', () => {
    const addItemDebugElement = fixture.debugElement.query(By.css('#fundName'));
    expect(addItemDebugElement.nativeElement).toBeTruthy();
  });

  it('should call the launchEApply method', async(() => {
    fixture.detectChanges();
    spyOn(component, 'launcheApply');
    el = fixture.debugElement.query(By.css('#eApply')).nativeElement;
    el.click();
    expect(component.launcheApply).toHaveBeenCalledTimes(1);
  }));

});
