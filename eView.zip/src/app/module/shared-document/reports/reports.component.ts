import { Component, OnInit, HostListener } from '@angular/core';
import { Observable } from 'rxjs';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router, NavigationStart, Event } from '@angular/router';
import { AppConfiguration } from '../../../app-configuration';
import { RestApiService } from '../../../service/rest-api.service';
import { SharedDocumentModel } from '../../../service/shared-document/shared-document-model';
import { SharedDocumentService } from '../../../service/shared-document/shared-document.service';
import { FileUploader, FileItem, ParsedResponseHeaders, FileUploaderOptions, Headers } from 'ng2-file-upload';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalComponent } from '../../../layout/ngb-modal/ngb-modal.component';
import * as $ from 'jquery';
import * as moment from 'moment';
import { NgxSpinnerService } from "ngx-spinner";
import { CustomSpinnerService } from '../../../service/spinner/custom-spinner.service';
import { FlashMessageService } from '../../../service/flash-message/flash-message.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  ShareDocUpload: FormGroup;
  showFilter: boolean=true;
  showuploaddoc:boolean;
  gridColumns: any;
  reports: any=[];
  tableData = [];
  successList =[];
  errorList = [];
  searchData: any;
  userID:any;
  userName:any;
  fundList: any;
  documents: any;
  departments: any;
  reportLimit: any;
  reportOffset: any;
  curPageIndex: any;
  filequelength:any;
  metadata: any ={count:''};
  pageType: any;
  filename:any;
  configUrl:any;
  config: any;
  UploadData:any;
  selectedAll:any;
  isSelected:boolean;
  selectedAllUpload:any;
  isSelectedUpload:boolean;
  deletedocuemntid:any;
  errmSG:any;
  uploaderrMsg:any
  uploaderrText:any;
  checkedList= [];
  checkedListsearch = [];
  urls = [];
  uploadRef = [];
  uploaderReference = [];
  submitted = false;
  queryModal:any;
  retentionlist:any;
  errorMsg:any;
  errorfileValidMsg:any;
  errorText:any;
  memfileshow:any;
  campaignsshow:any;
  allfileshow:boolean;
  showresult:boolean;
  firstName:any;
  searched:boolean = false;
  uploaderrMsg1;
  uploaderrText1:any;
  successMsgDocument:boolean;
  fileUploadRequest = 0;
  allowedMimeType:any;
  lastName:any;
  public dateRangeExceeded: Boolean;
  public startDateRange:boolean;
  public futureDateRange: Boolean;
  public uploader: FileUploader = new FileUploader({});
  private uploaderOptions: FileUploaderOptions = {};
  public alerts: any[] = [];
  public today: Date = new Date(new Date().toDateString());
  public dateValue: Date = new Date();
  public weekStart: Date = new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000));;
  public weekEnd: Date = this.today;
  public monthStart: Date = new Date(new Date(new Date().setDate(1)).toDateString()); 
  public monthEnd: Date = this.today;  
  public lastStart: Date = new Date(new Date(new Date(new Date().setMonth(new Date().getMonth() - 1)).setDate(1)).toDateString()); 
  public lastEnd: Date = new Date(new Date().getFullYear(), new Date().getMonth(), 0); 
  public yearStart: Date = new Date(new Date().getFullYear(), 0, 1); 
  public yearEnd: Date = this.today; 
  public format = 'dd/MM/yyyy';
  userPermissions:any;
  dataupload:any;
  indexupload:any;
  roles;
  showDocTypeAll:boolean;
  
  @HostListener('window:beforeunload') goToPage() {
    sessionStorage.setItem('Searched' , JSON.stringify(this.searched));
    sessionStorage.setItem('reportName' , 'sharedDoc');
    sessionStorage.setItem('reportData' , JSON.stringify(this.data.searchModal));
  }

  constructor(private errorMsgFlash:FlashMessageService,private spin:CustomSpinnerService, private route: ActivatedRoute, private router: Router,
    private data: SharedDocumentModel, public sharedDocReportService: SharedDocumentService,private http:RestApiService,private appConfig: AppConfiguration,private ngbModal: NgbModal) {
      let perm  = (JSON.parse(sessionStorage.getItem('userDetails')).menus)?JSON.parse(sessionStorage.getItem('userDetails')).menus:[];
      this.userPermissions = perm.join(',');
      this.uploaderOptions['method'] = 'POST';
      this.uploaderOptions['autoUpload'] = false;
      this.allowedMimeType = ['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','text/csv','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','image/jpeg','image/png'];
      this.uploaderOptions['maxFileSize'] = 200 * 1024 * 1024;
      this.uploaderOptions['allowedMimeType'] = this.allowedMimeType;
      this.uploaderOptions['authToken'] = "Bearer " + sessionStorage.getItem('userToken');
      this.uploader.setOptions(this.uploaderOptions);
      this.uploader.options.filters.push({ name: 'customMimeType', fn: function(item, options) {
        let allowedType = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'png', 'jpg', 'jpeg'];
        let type = item.name.slice(item.name.lastIndexOf('.') + 1);
        if(allowedType.indexOf(type.toLowerCase()) !==-1){
          this.customMimeType = true;
          return true;
        }else{
          this.customMimeType = false;
          return false;
        } 
      }}); 
  }

  BooleanConverter(value: any) {
    return value;
  }
    
  ngOnInit() {
    //this.reports = this.routesnapshot.data['reports'].items;
    this.errorMsgFlash.hideErrorMessage();
    let roles  = (JSON.parse(sessionStorage.getItem('userDetails')).roles)?JSON.parse(sessionStorage.getItem('userDetails')).roles:[];
    this.roles = roles.join(',')
    this.dateRangeExceeded = false;
    this.futureDateRange = false;
    this.startDateRange = false;
    this.showresult = false;
    this.successMsgDocument= false;
    this.userID = JSON.parse(sessionStorage.getItem('userDetails'))
    if(this.userID) {
      this.userName = this.userID.userName;
      this.firstName = this.userID.firstName;
      this.lastName = this.userID.lastName;
    }
   

     this.retentionlist = [
        { name: '10 Days', value: '10 Days' },
        { name: '20 Days', value: '20 Days' },
        { name: '1 Year', value: '1 Year' },
        { name: '2 Years', value: '2 Years'}
    ];

    this.ShareDocUpload = new FormGroup({
      fileName: new FormControl('', [Validators.required]),
      fundCode: new FormControl('', [Validators.required]),
      documentType: new FormControl('', [Validators.required]),
      retention: new FormControl('', [Validators.required]),
      effectiveDate: new FormControl('', [Validators.required]),
      departmentname: new FormControl('', []),
      description: new FormControl('', [])
    });
    this.allfileshow = true;
   // this.metadata = this.route.snapshot.data['reports'].metadata;
    this.UploadData = Object.assign({}, this.data.uploadModel);
    this.http.get(this.appConfig.URLS.shareddocument.fundList).subscribe(response => {
      this.fundList = response;
    }); 
    this.http.get(this.appConfig.URLS.shareddocument.documentTypes).subscribe(response => {
      this.documents = response;
      this.checkRoleBasedDocType();
    }); 
    if(!sessionStorage.getItem('reportData') && sessionStorage.getItem('reportName') != 'sharedDoc') {
        this.data.resetSearchModel();
    }
    this.searchData = Object.assign({}, this.data.searchModal);
    sessionStorage.setItem('reportName' , 'sharedDoc');
    sessionStorage.setItem('reportData' , JSON.stringify(this.data.searchModal));
    this.departments = this.sharedDocReportService.getDepartmentResult();

    let dataSort = this.data.searchModal.metaData;
    // this.showFilter = false;
    this.showuploaddoc=false;

    this.reportLimit = this.data.searchModal.metaData.reportLimit - this.data.searchModal.metaData.reportOffset;
    this.reportOffset = 1;
    this.pageType = 'status';

    let lim = this.reportLimit;
    let offs = (this.data.searchModal.metaData.reportLimit == 0)?20:this.data.searchModal.metaData.reportLimit;
    let pageindex = (parseInt(offs)/parseInt(lim));
    this.curPageIndex = pageindex;

    this.config = {
      itemsPerPage: this.reportLimit,
      currentPage: this.curPageIndex,
      totalItems: this.metadata.count
    };

     this.gridColumns = [
      {
        columnTitle: 'Fund name',
        columnKey:'fundName',
        currentSort: (dataSort.orderby == 'fundName')?true:false,
        colwidth:'col-1',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'fundName')?dataSort.order:'asc'
      },
      {
        columnTitle: 'Filename',
        columnKey:'file',
        currentSort: (dataSort.orderby == 'file')?true:false,
        colwidth:'col-3',
        cursor:'pointer-cursor',
        order:  (dataSort.orderby == 'file')?dataSort.order:'asc'
      },
      {
        columnTitle: 'Date/Time uploaded',
        columnKey:'createdDate',
        currentSort: (dataSort.orderby == 'createdDate')?true:false,
        cursor:'pointer-cursor',
        colwidth:'col-1 p-1',
        order: (dataSort.orderby == 'createdDate')?dataSort.order:'asc'
      },
      {
        columnTitle: 'Effective date',
        columnKey:'effectiveDate',
        currentSort: (dataSort.orderby == 'effectiveDate')?true:false,
        colwidth:'col-1 p-1',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'effectiveDate')?dataSort.order:'asc'
      },
      {
        columnTitle: 'Comments',
        columnKey:'description',
        currentSort: (dataSort.orderby == 'description')?true:false,
        colwidth:'col-3',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'description')?dataSort.order:'asc'
      },
      // {
      //   columnTitle: 'Comments',
      //   currentSort: false,
      //   colwidth:'col-1',
      //   cursor:'',
      //   order: ''
      // }
      {
        columnTitle: 'Uploaded by',
        columnKey:'uploadedBy',
        currentSort: (dataSort.orderby == 'uploadedBy')?true:false,
        colwidth:'col-1',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'uploadedBy')?dataSort.order:'asc'
      }
    ];

    this.uploader.onWhenAddingFileFailed = (item, filter) => {
       switch (filter.name) {
            case 'fileSize':
                this.filename = item.name;
                this.errorMsg = true;
                this.uploaderrMsg = false;
                this.errorfileValidMsg= false;
                this.errorText = 'The files did not upload as the total size of all files exceeds 200MB';
                break;
            case 'mimeType':
              this.filename = item.name;
              this.errorMsg = false;
              this.errorfileValidMsg = true;
              this.uploaderrMsg= false;
              this.errmSG = "The files did not upload due to invalid files (extensions):"+this.filename;
              break;
            case 'customMimeType':       
              this.filename = item.name;
              this.errorMsg = false;
              this.errorfileValidMsg = true;
              this.uploaderrMsg= false;
              this.errmSG = "The files did not upload due to invalid files (extensions):"+this.filename;
              break;                   
        }
    };

    if(sessionStorage.getItem('Searched') == 'true') {
        this.filterResults();
      }
   
  }

get f() { return this.ShareDocUpload.controls; }

checkRoleBasedDocType(){
  this.showDocTypeAll = true;
  let memberFileUpload = this.userPermissions.indexOf('SharedDocuments_MemberFileUpload');
  let manageDocuments = this.userPermissions.indexOf('SharedDocuments_ManageDocuments');
  if(memberFileUpload >= 0 && manageDocuments<0){
    this.showDocTypeAll = false;
    this.searchData.documentType = this.documents[0].documentTypeName;
    this.UploadData.documentType = this.documents[0].documentTypeName;
    this.ChangeFiletype('Member File');     
  }
}

ngAfterViewInit()
  {
    this.uploader.onAfterAddingFile = (item => {
      this.errorMsg = false;
      this.uploaderrMsg = false;
      this.errorfileValidMsg= false;
      item.withCredentials = false;
      this.uploaderReference.push(item);
    });      
  }

  resetModel(){
    this.submitted = false;
    this.filename='';
    // this.errorfileValidMsg = false;
    // this.errorMsg = false;
    this.allfileshow = true;
    this.memfileshow = false;
    this.campaignsshow = false;
    // this.uploaderrMsg = false;
    //this.uploader.queue = [];
    this.ShareDocUpload.reset();
    this.ShareDocUpload.patchValue({
    fileName:'',
    fundCode: '',
    documentType: '',
    retention: '10 Days',
    departmentname:'',
    description:''
    });
  }

  clearQueue() {
      this.uploader.queue = [];
  }

  selectAllUpload() {
    for (var i = 0; i < this.tableData.length; i++) {
      this.tableData[i].isSelectedUpload = this.selectedAllUpload;
    }
    this.getCheckedItemListUpload();
  }

  checkIfAllSelectedUpload() {
    this.selectedAllUpload = this.tableData.every(function(item:any) {
        return item.isSelectedUpload == true;
      });
    this.getCheckedItemListUpload();
  }

  getCheckedItemListUpload() {
    this.tableData.filter((x,index) => x.Id = index);
    this.checkedList = [];
    this.uploader.clearQueue();
    for (var i = 0; i < this.tableData.length; i++) {
      if(this.tableData[i].isSelectedUpload ){
        this.checkedList.push(this.tableData[i]);
        this.uploader.queue.push(this.uploaderReference[this.tableData[i].Id])
      }
    }
    
    if (this.checkedList.length && this.checkedList) {   
       $('#addtolistdisable,#deletedisable').removeClass('buttonDisabledshared');
    } else {
       $('#addtolistdisable,#deletedisable').addClass('buttonDisabledshared');
    }
  }

  onFileSelected(currentEvent){
    if (currentEvent.length == 0) {
      return false;
    }
    this.successMsgDocument = false;
    this.selectedAllUpload = false;
    this.successList = [];
    this.errorList = [];
    for(let i=0;i<this.uploader.queue.length;i++) {
      var files = [].slice.call(this.uploader.queue);
      this.tableData.push({
        fundCode : this.UploadData.fundCode,
        filename: files[i].some.name,
        fileexnname: files[i].some.name.substr(0,files[i].some.name.lastIndexOf(".")),
        documentType : this.UploadData.documentType,
        effectiveDate : this.UploadData.effectiveDate,
        retention : this.UploadData.retention,
        department:this.UploadData.department,
        description : this.UploadData.description,
        fundNamedata:this.UploadData.fundName,
        fundName:encodeURIComponent(this.UploadData.fundName),
        Id:i,
        userId:this.userName,
        username:this.firstName,
        lastName:this.lastName
      }) 
    }
  }

  removeTableData(data, index) {
    this.UploadtoggleModel()
    if(this.tableData){
      this.selectedAll = false;
      for (var i = 0; i < this.tableData.length; i++) {
      this.tableData[i].isSelectedUpload = false;
      }
    }
    this.uploaderReference.splice(data.Id,1);
    //this.tableData = this.tableData.filter(x => x.Id != data.Id);
    this.tableData.splice(index, 1);
    return true;
  } 

  removeTableDataModel(data, index){
    this.dataupload = data;
    this.indexupload = index;
    let ngbModalOptions: NgbModalOptions = {
        backdrop : 'static',
        keyboard : true
    };
    const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
    m.componentInstance.Title = 'Confirmation';
    m.componentInstance.confMessage = 'Are you sure you want to remove this document?';
    let res = this.BooleanConverter(m.result);
    res.then((userResponse) => {
      if (userResponse == true) {
        this.removeTableData(this.dataupload, this.indexupload);
      }
    }); 
  }
  
  UploadtoggleModel(){
    $('#DeleteUploadDocModal').hide();
  }

  ChangeFiletype(value){
    if(value == 'Member File'){
      this.UploadData.effectiveDate = new Date(new Date(new Date().setDate(new Date().getDate())).toDateString());
      this.memfileshow = true;
      this.campaignsshow = false;
      this.allfileshow = false;
      this.allowedMimeType = ['text/csv','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
      this.uploaderOptions['allowedMimeType'] = this.allowedMimeType;
      this.uploader.setOptions(this.uploaderOptions);
    }
    else if(value == 'Campaigns'){
      this.UploadData.effectiveDate = '';
      this.campaignsshow = true;
      this.memfileshow = false;
      this.allfileshow = false;
      this.allowedMimeType = ['text/csv','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
      this.uploaderOptions['allowedMimeType'] = this.allowedMimeType;
      this.uploader.setOptions(this.uploaderOptions);
    }else{
      this.UploadData.effectiveDate = '';
      this.allfileshow = true;
      this.memfileshow = false;
      this.campaignsshow = false;
      this.allowedMimeType = ['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','text/csv','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','image/jpeg','image/png'];
      this.uploaderOptions['allowedMimeType'] = this.allowedMimeType;
      this.uploader.setOptions(this.uploaderOptions);
    }
  }

  upload(){ 
    this.uploaderrMsg1 = this.uploader.queue.length;
    this.spin.show();
  //   var ref = this;
  //   this.checkedList.filter(x=> ref.uploadRef.push(x.Id));
  //  if(this.checkedList.length != this.uploader.queue.length) {
  //   this.uploader.queue.filter((currentItem,index) => {
  //     if(ref.uploadRef.indexOf(index) == -1) {
  //       this.uploaderQueue.push(currentItem);
  //       this.uploader.queue.splice(index,1);
  //     }
  //   });     
  //  }

    this.uploader.queue.filter((currentItem,index) => {
      this.fileUploadRequest++;
      const searchArray = [];
      this.configUrl = this.appConfig.serviceBaseUrl+this.appConfig.URLS.shareddocument.sharedDocUploadReports;
      Object.keys(this.checkedList[index]).forEach(key => {
        if (this.checkedList[index][key] && key != 'Id' && key != 'isSelectedUpload' && key!='fundNamedata' && key !='fileexnname') {
          if (key === 'effectiveDate') {
            searchArray.push(`${key}=='${moment(this.checkedList[index][key]).format('YYYY/MM/DD')}'`);
          } else if(key === 'filename') {
            let fname = encodeURIComponent(this.checkedList[index][key]);
            if (this.checkedList[index][key] != 'All') searchArray.push(`${key}=="${fname}"`);
          }
          else {
            if (this.checkedList[index][key] != 'All') searchArray.push(`${key}=='${this.checkedList[index][key]}'`);
          }
        }
      });
      const params: any = searchArray.join(';');
      const queryUrl = `${this.configUrl}?insertkey=${params}`;
      currentItem.url = queryUrl;
    });
    
    this.uploader.onBuildItemForm = (item, form) => {
      form.append('Type', item.alias);
      form.append('Key', item._file);
      form.append('multipart', item.file);
    };
    let ss= this.uploader.uploadAll();
    this.uploader.onErrorItem = (item, response, status, headers) => this.onErrorItem(item, response, status, headers);
    this.uploader.onSuccessItem = (item, response, status, headers) => this.onSuccessItem(item, response, status, headers);
    this.uploader.onCompleteAll = () => {
      this.curPageIndex = 1;
      this.searchData.metaData.reportLimit = this.reportLimit;
      this.searchData.metaData.reportOffset = 0;
      this.filterResults();
      this.spin.hide();
      $('#addtolistdisable,#deletedisable').addClass('buttonDisabledshared');
    };
  }

  
  onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    let ind = this.uploader.getIndexOfItem(item);
    this.uploaderReference = this.uploaderReference.filter(x => x.url != item.url);
    this.uploader.removeFromQueue(item);
    let suc = JSON.parse(response);
    if (suc.response == 'Success'){
          this.filename = '';
          this.errmSG='';
          this.submitted = false;
          this.successMsgDocument = true;
          this.successList.push({status : 'success',fileName:this.checkedList[ind]['filename'],message : 'Document uploaded successfully'});
          this.errorList.push({status : 'success',fileName:this.checkedList[ind]['filename'],message : 'Document uploaded successfully'});
          this.tableData = this.tableData.filter(x => x.Id != this.checkedList[ind].Id);
          this.checkedList.splice(ind,1);
          this.resetModel(); 
    }else{
      this.filename='';
      //this.uploaderrMsg = true;
      this.uploaderrText = suc.message;
    }
    this.tableData.filter((x,index) => x.Id = index);
  }

  onClearForm() {
    let reportData = Object.assign({}, this.data.resetModel);
    this.searchData = reportData; 
    // this.data.resetSearchModel();
    // sessionStorage.setItem('reportData',JSON.stringify(this.data.searchModal)) 
    // this.searchData = Object.assign({}, this.data.searchModal);
  }

  onErrorItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
     let ind = this.uploader.getIndexOfItem(item);
     this.uploaderReference = this.uploaderReference.filter(x => x.url != item.url);
     this.uploader.removeFromQueue(item);
     if(response){
      let err = JSON.parse(response);
      this.successList.push({
        status : 'failure',
        fileName:this.checkedList[ind]['filename'],
        message:err.message
      });
     }else{
      this.successList.push({
        status : 'failure',
        fileName:this.checkedList[ind]['filename'],
        message:'An unexpected error has occurred. Please try again.'
      });
     }
     this.tableData = this.tableData.filter(x => x.Id != this.checkedList[ind].Id);
     this.checkedList.splice(ind,1);
     this.tableData.filter((x,index) => x.Id = index);
     this.resetModel();
  }

 selectAll() {
    for (var i = 0; i < this.reports.length; i++) {
      this.reports[i].isSelected = this.selectedAll;
    }
    this.getCheckedItemList();
  }

  checkIfAllSelected() {
    this.selectedAll = this.reports.every(function(item:any) {
        return item.isSelected == true;
      });
    this.getCheckedItemList();
  }

  getCheckedItemList(){
    this.checkedListsearch = [];
    for (var i = 0; i < this.reports.length; i++) {
      if(this.reports[i].isSelected ){
        this.checkedListsearch.push(this.reports[i]);
      }
    }
    if (this.checkedListsearch.length && this.checkedListsearch) {   
       $('#downloadbutton').removeClass('buttonDisabled');
    } else {
       $('#downloadbutton').addClass('buttonDisabled');
    }
  }

  downloadSingleFile(filename,documentid){
    this.errorMsgFlash.hideErrorMessage(); 
    this.sharedDocReportService.downloadSingleFile(this.appConfig.URLS.shareddocument.sharedDocReports+'/'+documentid).subscribe(data => {
        var filetype = filename.split(".").pop();
        let mime;
        if(filetype.toLowerCase() == 'pdf' || filetype.toLowerCase() == 'doc' || filetype.toLowerCase() == 'docx' || filetype.toLowerCase() == 'xls' || filetype.toLowerCase() == 'xlsx' || filetype.toLowerCase() == 'jpg' || filetype.toLowerCase() == 'jpeg' || filetype.toLowerCase() == 'tif') {
            mime = 'application/'+filetype;
        } else if(filetype.toLowerCase() == 'txt') {
            mime = 'text/plain';
        }
        const fileStream = new Blob([data], {type: mime});
        const anchorTag = document.createElement('a');
        document.body.appendChild(anchorTag);

        if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
          window.navigator.msSaveBlob(fileStream,filename);
        } else {
          const fileURL = URL.createObjectURL(fileStream);
          anchorTag.href = fileURL;
          anchorTag.download = filename;
          anchorTag.click();
        }
      },err => {
        this.errorMsgFlash.showErrorMessage();
      });
  }

  downloadMultipleFile(){
    this.errorMsgFlash.hideErrorMessage();
    let documentsids = this.reports.filter(x => x.isSelected).map(x => x.documentId).join(',');
    if(documentsids!='' && documentsids!=null){
      this.sharedDocReportService.downloadMultipleFile(this.appConfig.URLS.shareddocument.sharedDocReports+'/'+documentsids+'/ZIP').subscribe(data => {
      if (navigator.appVersion.toString().indexOf('.NET') >= 0) {
        window.navigator.msSaveBlob(data, 'eViewDownloadDocument.zip');
      } else {
        const fileStream = new Blob([data], {type: 'application/zip'});
        const anchorTag = document.createElement('a');
            document.body.appendChild(anchorTag);
        const fileURL = URL.createObjectURL(fileStream);
        anchorTag.href = fileURL;
        anchorTag.download = 'eViewDownloadDocument.zip';
        anchorTag.click();
      }
    },err => {
        this.errorMsgFlash.showErrorMessage();
    });
    }
  }

  navigateToParent(){
    this.router.navigate(['.'], { relativeTo: this.route.parent });
  }

  toggleFilters() {
    this.showFilter = !this.showFilter;
  }

  canceltoggleFilters(){
     this.showFilter = !this.showFilter;
     let reportData = JSON.parse(sessionStorage.getItem('reportData'));
     this.searchData = reportData;
  }

  sortResults(sortColumn) {
    for (const column of this.gridColumns) {
      if (column === sortColumn) {
        // if(sortColumn.columnTitle == 'Filename' || sortColumn.columnTitle == 'Comments'){
        //   column.currentSort = false;
        //   return false;
        // }
        column.currentSort = true;
      } else {
        column.currentSort = false;
      }
    }
    if(this.data.searchModal.metaData.orderby == sortColumn.columnKey) {
      sortColumn.order = (sortColumn.order == 'asc')?'desc':'asc';
    }
    else {
      sortColumn.order = 'asc';
    }  
    this.curPageIndex = 1;
    this.data.searchModal.metaData.reportOffset = '0';
    this.data.searchModal.metaData.reportLimit = this.reportLimit;
    this.data.searchModal.metaData.orderby = sortColumn.columnKey;
    this.data.searchModal.metaData.order = sortColumn.order;
    this.filterResults();
  }

  deleteModel(documentid){
    // $('#DeleteDocModal').show();
    let ngbModalOptions: NgbModalOptions = {
        backdrop : 'static',
        keyboard : true
    };
    const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
    m.componentInstance.Title = 'Confirmation';
    m.componentInstance.confMessage = 'Are you sure you want to remove this document?';
    let res = this.BooleanConverter(m.result);
    res.then((userResponse) => {
      if (userResponse == true) {
        this.Deletedocument(documentid,this.userName);
      }
    }); 
  }

  deleteMultiple(){
    let ngbModalOptions: NgbModalOptions = {
        backdrop : 'static',
        keyboard : true
    };
    const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
    m.componentInstance.Title = 'Confirmation';
    m.componentInstance.confMessage = 'Are you sure you want to remove this document?';
    let res = this.BooleanConverter(m.result);
    res.then((userResponse) => {
      if (userResponse == true) {
         this.uploader.queue = [];
         for (var i = 0; i < this.checkedList.length; i++) {
            let tableDataDelete = this.tableData.findIndex((x) => (x.Id == this.checkedList[i].Id));
            this.uploaderReference.splice(tableDataDelete,1);
            this.tableData.splice(tableDataDelete, 1);
        }
      }
    }); 
    $('#addtolistdisable,#deletedisable').addClass('buttonDisabledshared');
  }
  searchfilterResults() {
    sessionStorage.setItem('reportName' , 'sharedDoc');
    sessionStorage.setItem('reportData' , JSON.stringify(this.searchData));
    this.searchData.metaData = {
      reportLimit: this.reportLimit,
      reportOffset: '0',
      orderby: 'createdDate',
      order: 'desc'
    };
    this.curPageIndex = 1;
    this.data.searchModal = Object.assign({}, this.searchData);
    this.filterResults()
  }

  filterResults() {
    this.errorMsgFlash.hideErrorMessage();   
    this.alerts = [];
    this.selectedAll = false;
    $('#downloadbutton').addClass('buttonDisabled');
    
    this.sharedDocReportService.searchReports('sharedDocReports').subscribe((reportsObj: any) => {
      this.reports = reportsObj.items;
      if(this.reports){
        this.showresult = true;
        this.showFilter = false;
        this.searched = true;
        sessionStorage.setItem('Searched' , JSON.stringify(this.searched)); 
        this.metadata = reportsObj.metadata;
        this.config = {
          itemsPerPage: this.reportLimit,
          currentPage: this.curPageIndex,
          totalItems: this.metadata.count
         };
         if(this.reports.length==0){
          this.showresult = false;
          this.showFilter = true;
         }
      }      
    },err => {
        this.errorMsgFlash.showErrorMessage();
      });
  }

  pageChanged(event) {
    this.selectedAll = false;
    $('#downloadbutton').addClass('buttonDisabled');
    this.curPageIndex = event;
    this.data.searchModal.metaData.reportOffset =
    ((Number(this.reportLimit) * (this.curPageIndex - 1))).toString();
    this.data.searchModal.metaData.reportLimit = Number(this.reportLimit) * (this.curPageIndex);
    this.filterResults();
  }
  onLimitChange(limit: any) {
    this.selectedAll = false;
    $('#downloadbutton').addClass('buttonDisabled');
    this.reportLimit = limit;
    this.curPageIndex = 1;
    this.data.searchModal.metaData.reportOffset = '0';
    this.data.searchModal.metaData.reportLimit = limit;
    this.filterResults();
  }

  toggleModel(){
    $('#DeleteDocModal').hide();
  }

  Deletedocument(deletedocuemntid,userName){
    this.errorMsgFlash.hideErrorMessage();   
    this.toggleModel();
    this.sharedDocReportService.deletefile(this.appConfig.URLS.shareddocument.sharedDocReports+'/'+deletedocuemntid+'/'+userName).subscribe(data => {
        if (data){
            $('#submittedModal').show();
            this.filterResults();
            return true;
        }else{
            this.errorMsgFlash.showErrorMessage();
         }
      },err => {
        this.errorMsgFlash.showErrorMessage();
      });
  }
  navigateToCurrentPage(){
    $('#submittedModal').hide();
  }
  
  setFundname(){
    const fundname = $("#fundnameselect option:selected").text();
    this.UploadData['fundName'] = fundname;
  }

  dateOnly(event) {
    const regEx = this.appConfig.appConstants.regEx.dateOnly;
    return event.key.match(regEx) ? true : false;
  }

  dateRangeOnly(event) {
    if (event.keyCode === 13 || event.keyCode === 32 || event.keyCode === 47 || event.keyCode === 45) {
      return;  // let enter it happen
    }
    const regEx = this.appConfig.appConstants.regEx.dateRangeOnly;
    return event.key.match(regEx) ? true : false;
  }

  onDateRangeChange(event) {
    this.futureDateRange = event.endDate > this.today ? true : false;
    this.dateRangeExceeded = event.daySpan > this.appConfig.appConstants.maxDateRangeAllowed ? true : false;
    this.startDateRange = event.endDate >= event.startDate ? false : true;
  }

 tabnavigate(){
  this.alerts = [];
  this.successMsgDocument = false;
  this.errorMsg = false;
  this.errorfileValidMsg = false;
  this.successList = [];
  this.errorList = [];
  }

}
