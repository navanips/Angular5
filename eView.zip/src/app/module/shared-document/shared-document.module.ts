import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { NgxPaginationModule } from 'ngx-pagination';
import { TooltipModule } from 'ng2-tooltip-directive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FileUploadModule } from 'ng2-file-upload';

import { ValidateGuard } from '../../guards/validate.guard';
import { AuthGuard } from '../../guards/auth.guard';
import { AlertModule } from 'ngx-bootstrap';
import { ReportsComponent } from './reports/reports.component';
import { CustomDirectiveModule } from '../../directives/custom-directive/custom-directive.module';

const routes: Routes = [
  {
    path: 'reports', component: ReportsComponent, canActivate: [ValidateGuard, AuthGuard],
    data: {
      reportURL: 'sharedDocReports',
      permissionId: ['SharedDocuments_MemberFileUpload', 'SharedDocuments_SearchDocuments', 'SharedDocuments_ManageDocuments'],
      featureToggleKey: 'sharedDocsReports'
    }

  }
];

@NgModule({
  declarations: [ReportsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    DateRangePickerModule,
    DatePickerModule,
    NgxPaginationModule,
    FileUploadModule,
    AlertModule.forRoot(),
    TooltipModule,
    CustomDirectiveModule
  ]
})
export class SharedDocumentModule { }