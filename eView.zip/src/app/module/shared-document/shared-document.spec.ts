import { SharedDocumentModule } from './shared-document.module';

describe('SharedDocumentModule', () => {
  let sharedDocumentModule: SharedDocumentModule;

  beforeEach(() => {
    sharedDocumentModule = new SharedDocumentModule();
  });

  it('should create an instance', () => {
    expect(sharedDocumentModule).toBeTruthy();
  });
});
