import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-under-construction',
  templateUrl: './under-construction.component.html',
  styleUrls: ['./under-construction.component.css']
})
export class UnderConstructionComponent implements OnInit {

  constructor(private titleService: Title) {
    this.titleService.setTitle("Under construction | eView - MetLife"); 
   }

  ngOnInit() {
  }

}
