import { StatusClaimModule } from './status-claim.module';

describe('StatusClaimModule', () => {
  let statusClaimModule: StatusClaimModule;

  beforeEach(() => {
    statusClaimModule = new StatusClaimModule();
  });

  it('should create an instance', () => {
    expect(statusClaimModule).toBeTruthy();
  });
});
