import { NgModule ,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule,CurrencyPipe } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { ValidateGuard } from '../../../guards/validate.guard';
import { NgxPaginationModule} from 'ngx-pagination';
import { Ng2SmartTableModule} from 'ng2-smart-table';
import { Ng2CompleterModule} from "ng2-completer";
import { FileUploadModule } from 'ng2-file-upload';

import { ReportsComponent } from './reports/reports.component';
import { DetailsComponent } from './details/details.component';
import { ClaimReportDetailsService } from '../../../service/claim/claim-report-details.service';
import { CustomDirectiveModule } from '../../../directives/custom-directive/custom-directive.module';

const routes: Routes = [
  { path: '', component: ReportsComponent,canActivate : [ValidateGuard],
    data: {
        reportURL : 'statusReports',
        permissionId:['eQuery_ClaimsStatusRpt','Claims_ClaimsStatusRpt']
    }
  },
  { path: 'reports', component: ReportsComponent,canActivate : [ValidateGuard],
    data: {
        reportURL : 'statusReports',
        permissionId:['eQuery_ClaimsStatusRpt','Claims_ClaimsStatusRpt']
    }
  },
  { path: 'reports/:id/:product', component: DetailsComponent,canActivate : [ValidateGuard],
    resolve:{
      data: ClaimReportDetailsService,
    },
    data: {
      reportType: 'status',
      permissionId:['eQuery_ClaimsStatusRpt','Claims_ClaimsStatusRpt']
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(routes),
    DateRangePickerModule,
    DatePickerModule,
    NgxPaginationModule,
    Ng2SmartTableModule,
    Ng2CompleterModule,
    FileUploadModule,
    CustomDirectiveModule
  ],
  providers: [CurrencyPipe],
  declarations: [ReportsComponent, DetailsComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class StatusClaimModule { }