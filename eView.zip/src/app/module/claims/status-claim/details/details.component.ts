import { Component, OnInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { ClaimReportDetailsService } from '../../../../service/claim/claim-report-details.service';
import { AppConfiguration } from '../../../../app-configuration';
import { DatePipe, CurrencyPipe } from '@angular/common';
import { RestApiService } from '../../../../service/rest-api.service';
import { FileUploader, FileItem, ParsedResponseHeaders, FileUploaderOptions, Headers } from 'ng2-file-upload';
import { NgxSpinnerService } from "ngx-spinner";
import { AngularElementType } from '@syncfusion/ej2-angular-base';
import { StatusSearchModel } from '../../../../service/claim/status/status-search-model';
import * as $ from 'jquery';
import { CustomSpinnerService } from '../../../../service/spinner/custom-spinner.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  applicationDetails: any;
  appStatus: any;
  exportFileURL: any;
  coversinfos: any;
  userPermissions: any;
  eventInfoSettings: any;
  paymentInfoSettings: any;
  eventInfoData: any;
  paymentInfoData: any;
  deathCover: any;
  TPDCover: any;
  IPCover: any;
  finalAppStatus: any;

  //document Related
  uploadSummary: any;
  showSummary: boolean;
  existingDocuments: any;
  documentList: any;
  selectedDocument: any;
  //refSelectedDocument : any;
  selectedDocumentID: any;
  selectedOldDocumentID: any;
  validBrowsedFile: any;
  dummyUploaderQueue: any;
  searchText: any;
  additionalRequirement: boolean;
  browseShow: boolean;
  selectedOldDocument: any;
  fileUploadRequest = 0;
  totalRequest = 0;
  successRequest = 0;
  errorMsg: any;
  errorText: any;
  submitObj: any;
  claimStrategy:any;
  public uploader: FileUploader = new FileUploader({});
  private uploaderOptions: FileUploaderOptions = {};
  @ViewChild('fileInput') fileInput: any;

  constructor(private currencyConverter: CurrencyPipe, private searchData: StatusSearchModel, private spin: CustomSpinnerService, private restAPI: RestApiService, private datePipe: DatePipe, private appConfig: AppConfiguration, private route: ActivatedRoute,
    private router: Router, private ReportDetService: ClaimReportDetailsService, private location: Location) {
    if(sessionStorage.getItem('userDetails')) {
      let perm = (JSON.parse(sessionStorage.getItem('userDetails')).menus) ? JSON.parse(sessionStorage.getItem('userDetails')).menus : [];
      this.userPermissions = perm.join(',');
    }
    this.uploaderOptions['url'] = this.appConfig.serviceBaseUrl + this.appConfig.URLS.fileUrl.fileUpload;
    this.uploaderOptions['method'] = 'POST';
    this.uploaderOptions['autoUpload'] = false;
    this.uploaderOptions['maxFileSize'] = 50 * 1024 * 1024;
    this.uploaderOptions['allowedMimeType'] = ['text/csv', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'image/png', 'image/jpeg', 'image/jpg'];
    this.uploaderOptions['authToken'] = "Bearer " + sessionStorage.getItem('userToken');
    this.uploader.options.filters.push({name:'customMimeType',fn:function(item,options) {
      let allowedType = ['pdf','doc','docx','xls','xlsx','csv','png','jpg','jpeg'];
      let type = item.name.slice(item.name.lastIndexOf('.')+1);
      if(allowedType.indexOf(type.toLowerCase()) !==-1){
        this.customMimeType = true;
        return true;
      }else{
        this.customMimeType = false;
        return false;
      }
    }});     
    this.uploader.setOptions(this.uploaderOptions);
    this.uploader.onAfterAddingAll = item => {
      this.uploadSummary = [];
      this.showSummary = false;
    };
    this.uploader.onWhenAddingFileFailed = (item, filter) => {
      switch (filter.name) {
        case 'fileSize':
          this.uploadSummary = [];
          this.showSummary = true;
          this.uploadSummary.push({
            status: 'error',
            fileName: '',
            message: 'The files did not upload as the total size of all files exceeds 50MB',
          });
          break;
        case 'mimeType':
          this.uploadSummary = [];
          this.showSummary = true;
          this.uploadSummary.push({
            status: 'error',
            fileName: '',
            message: 'The files did not upload due to invalid files (extensions):' + item.name
          });
          break;
        case 'customMimeType':  
          this.uploadSummary = [];
          this.showSummary = true;
          this.uploadSummary.push({
            status: 'error',
            fileName: '',
            message: 'The files did not upload due to invalid files (extensions):' + item.name
          });        
          break;            
      }
    };
  }

  ngOnInit() {
    this.applicationDetails = (this.route.snapshot.data['data'])?this.route.snapshot.data['data']:{};

    if (this.applicationDetails.application) {
      this.exportFileURL = this.appConfig.URLS.claims.claimStatusExport + '/' + this.applicationDetails.application.claimNo + '/' + this.applicationDetails.application.product;
    }
    if (this.applicationDetails.event.length > 0) {
      this.constructEventHistory(this.applicationDetails.event);
    }
    if (this.applicationDetails.paymentHistory.length > 0) {
      if (this.applicationDetails.application.product == 'SCI') {
        this.constructPaymentHistorySCI(this.applicationDetails.paymentHistory);
      } else {
        this.constructPaymentHistoryGroup(this.applicationDetails.paymentHistory);
      }
    }
    this.claimStrategy = [];
    if(this.applicationDetails.claimStrategy.length > 0) {
      this.constructclaimStrategy();
    }
    
    this.setFileConfiguration();
    this.loadDocumentList();
    let userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
    this.submitObj = {
      claimNo : this.applicationDetails.application.claimNo,
      productType :this.applicationDetails.application.product,
      fundCode: this.applicationDetails.application.fundCode,
      fundName: this.applicationDetails.application.fundName,
      memberInfo: this.applicationDetails.member,
      submittedPhone: userDetails.mobile,
      firstName: userDetails.firstName,
      lastName: userDetails.lastName,
      documentInfo: []
    };
    this.submitObj.memberInfo.memberDob = this.datePipe.transform(this.submitObj.memberInfo.memberDob, "yyyy-MM-dd");
  }

  ngAfterViewInit() {
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
    });
  }

  loadDocumentList() {
    this.restAPI.get(this.appConfig.URLS.claims.documentList).subscribe(result => {
      this.documentList = result;
      this.loadExistingDocuments();
    });
  }

  loadExistingDocuments() {
    // this.restAPI.get(this.appConfig.URLS.claims.existingDocsList + this.applicationDetails.application.claimNo).subscribe(result => {
    //   this.existingDocuments = result;
    //   this.populateDocumentSection();
    //   this.constructStatus(this.applicationDetails.application.statusCode);
    // });
    this.existingDocuments = this.applicationDetails.requirmentHistory;
    this.populateDocumentSection();
    this.constructStatus(this.applicationDetails.application.statusCode);    
  }
  constructStatus(statusCode) {
    let reviewingEventList = ['O', 'N', 'R'];
    let finalisedEventList = ['C', 'D'];
    let inactiveEventList = ['Z'];
    if (!statusCode) {
      this.finalAppStatus = 'None';
    }
    if (reviewingEventList.indexOf(statusCode) != -1) {
      this.finalAppStatus = 'Reviewing';
      if (this.existingDocuments.length > 0) {
        this.finalAppStatus = 'Awaiting';
      }
    } else if (finalisedEventList.indexOf(statusCode) != -1) {
      this.finalAppStatus = 'Finalised';
    } else if (inactiveEventList.indexOf(statusCode) != -1) {
      this.finalAppStatus = 'Inactive';
    } else {
      this.finalAppStatus = 'None';
    }

  }

  populateDocumentSection() {
    if (this.existingDocuments.length > 0) {
      this.existingDocuments.forEach((item, index) => {
        let document = this.documentList.filter(x => (x.documentTypeName == item.requirement) ? x.documentTypeID : '');
        let documentTypeID;
        if (document.length == 0) {
          documentTypeID = index;
        } else {
          documentTypeID = document[0].documentTypeID;
          this.selectedDocumentID.push(documentTypeID);
        }        
        this.validBrowsedFile.push({
          outstanding: true,
          delete: false,
          documentTypeID: documentTypeID,
          documentTypeName: item.requirement,
          dateRequested: item.requestedDate,
          comments: item.description,
          daysSinceRquested: item.daysSinceRequested,
          sub: []
        });
      });
    }

  }


  setFileConfiguration() {

    this.selectedDocument = [];
    this.selectedDocumentID = [];
    this.validBrowsedFile = [];
    this.dummyUploaderQueue = [];
    this.additionalRequirement = false;
    this.selectedOldDocument = [];
    this.selectedOldDocumentID = [];
    this.existingDocuments = [];
  }

  submitApplication() {
    if (this.successRequest === this.totalRequest) {
      let docList = this.submitObj.documentInfo;
      let finaldocList = [];
      docList.forEach(item => {
        finaldocList.push({
          'documentLocation': item.filePath,
          'docType': item.fileType
        });
      });
      this.submitObj.documentInfo = finaldocList;
      this.restAPI.update(this.appConfig.URLS.claims.submitExistingClaim, this.submitObj).subscribe(result => {
        this.uploadSummary = [];
        this.submitObj.documentInfo = [];
        this.showSummary = true;
        this.uploadSummary.push({
          status: 'success',
          fileName: '',
          message: 'All document(s) uploaded successfully',
        });
      }, err => {
        this.uploadSummary = [];
        this.showSummary = true;
        this.uploadSummary.push({
          status: 'error',
          fileName: '',
          message: 'An unexpected error has occurred. Please try again.',
        });
      });
    } else {
      this.showSummary = true;
    }
  }

  upload() {
    if (this.uploader.queue.length == 0 && this.submitObj.documentInfo.length > 0) {
      this.successRequest = 0;
      this.totalRequest = 0;
      this.submitApplication();
      return false;
    }
    this.spin.show();
    this.successRequest = 0;
    this.totalRequest = 0;
    this.fileUploadRequest = 0;
    this.uploadSummary = [];
    this.uploader.queue.forEach((currentItem, index) => {
      this.fileUploadRequest++;
      this.totalRequest++;
      if (this.dummyUploaderQueue.length > index) {
        currentItem.url = this.appConfig.serviceBaseUrl + this.appConfig.URLS.fileUrl.fileUpload + '?docType=' + this.dummyUploaderQueue[index].documentTypeName;
      }
    });
    this.uploader.onBuildItemForm = (item, form) => {
      form.append('Type', item.alias);
      form.append('Key', item._file);
      form.append('multipart', item.file);
    }; 
    let ss = this.uploader.uploadAll();
    this.uploader.onErrorItem = (item, response, status, headers) => this.onErrorItem(item, response, status, headers);
    this.uploader.onSuccessItem = (item, response, status, headers) => this.onSuccessItem(item, response, status, headers);
    this.uploader.onCompleteAll = () => {
      let deleteKeys = [];
      this.validBrowsedFile.forEach((item, index) => {
        item.sub.forEach((subItem, subIndex) => {
          if (subItem.delete) {
            deleteKeys.push(subItem.randomKey);
          }
        });
      });
      this.triggerDelete(deleteKeys);
    };
  }

  triggerDelete(deleteKeys) {
    deleteKeys.forEach((item) => {
      setTimeout(() => {
        $('#' + item).trigger('click');
      }, 1000);
    });
  }

  onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    this.uploader.removeFromQueue(item);
    let parsedResponse = JSON.parse(response);
    this.submitObj.documentInfo.push(parsedResponse);

    this.uploadSummary.push({
      status: 'success',
      fileName: item.file.name,
      message: 'Document uploaded successfully',
    });
    this.fileUploadRequest--;
    this.successRequest++;
    if (this.fileUploadRequest == 0) {
      this.spin.hide();
      this.submitApplication();
    }
    //for removing the delete button
    let uploadCategory = parsedResponse.fileType;
    let uploadFileName = parsedResponse.fileName;
    let categoryIndex;
    this.dummyUploaderQueue = this.dummyUploaderQueue.filter(x => x.documentTypeName != parsedResponse.fileType);

    this.validBrowsedFile.forEach((item, index) => {
      let currentCategory = item.documentTypeName;
      if (currentCategory == uploadCategory) {
        categoryIndex = index;
        item.sub.forEach((subitem, subindex) => {
          let currentfileName = subitem.fileName.replace("'","");
          if (currentfileName == uploadFileName || currentfileName.indexOf(uploadFileName) > -1) {

            item.sub[subindex].delete = false;
          }
        });
      }
    });
  }

  onErrorItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {

    let ind = this.uploader.getIndexOfItem(item);
    //this.uploader.removeFromQueue(item);
    this.fileUploadRequest--;
    if (this.fileUploadRequest == 0) {
      this.spin.hide();
      this.submitApplication();
    }
    if(response) {
      let parsedResponse = JSON.parse(response);
      this.dummyUploaderQueue = this.dummyUploaderQueue.filter(x => x.documentTypeName != parsedResponse.docType);
      this.uploadSummary.push({
        status: 'error',
        fileName: item.file.name,
        message: parsedResponse.message,
      });
    }else{
      this.uploadSummary.push({
        status: 'error',
        fileName: item.file.name,
        message: 'An unexpected error has occurred. Please try again.',
      });
    }    
  }

  toggleAdditionalRequirement() {
    this.additionalRequirement = !this.additionalRequirement;
  }

  removeBrowsedFile(data, mainindex, subindex) {
    //removing from the uploaded queue
    let index = this.dummyUploaderQueue.findIndex(x => x.documentTypeID == data.documentTypeID);
    this.uploader.queue.splice(index, 1);

    //remove from the sub

    this.validBrowsedFile[mainindex].sub.splice(subindex, 1);

    //remove the Browsed category and add it back to document list
    if (this.validBrowsedFile[mainindex].sub.length == 0 && !this.validBrowsedFile[mainindex].outstanding) {
      let docID = this.validBrowsedFile[mainindex].documentTypeID;
      this.validBrowsedFile.splice(mainindex, 1);
      this.dummyUploaderQueue.splice(mainindex, 1);
      let removalIndex = this.selectedDocumentID.indexOf(docID);
      this.selectedDocumentID.splice(removalIndex, 1);

      //fix if that checkbox selected
      let removeIndex = this.selectedOldDocumentID.indexOf(docID);
      this.selectedOldDocument.splice(removeIndex, 1);
      this.selectedOldDocumentID.splice(removeIndex, 1);

      //remove that checkbox selection
    }

    //this.selectedDocument.push(data); 
    //this.validBrowsedFile = this.validBrowsedFile.filter(x => x.documentTypeID != data.documentTypeID);    
    //this.dummyUploaderQueue = this.dummyUploaderQueue.filter(x => x.documentTypeID != data.documentTypeID);
  }

  checkOnlyTable(event, data) {
    let CheckdLength = document.querySelectorAll('input[name="checkBoxes"]:checked').length;
    if (CheckdLength > 0) {
      this.browseShow = true;
    } else {
      this.browseShow = false;
    }
    if (event.target.checked == true) {
      this.selectedOldDocumentID.push(data);
    } else {
      this.selectedOldDocumentID.forEach((item, index) => {
        if (item.documentTypeID == data.documentTypeID) {
          this.selectedOldDocumentID.splice(index, 1);
        }
      });
    }
  }

  onFileSelected(browsedFile) {
    let fName = [];
    if (this.fileInput.nativeElement.value) {
      fName = this.fileInput.nativeElement.value.split("\\")
    }
    let ext = fName[fName.length - 1].split('.');
    let arrExt = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'png', 'jpg', 'jpeg']
      const fileBrowser = this.fileInput.nativeElement;
      if (this.uploader._mimeTypeFilter(browsedFile.target.files[0]) && this.uploader._fileSizeFilter(browsedFile.target.files[0]) && arrExt.indexOf(ext[ext.length-1].toLowerCase()) > -1) {
        //remove added queue and add queue manually
        let queLength = this.uploader.queue.length;
        this.uploader.queue.splice(queLength - 1, 1);

        //old category
        this.selectedOldDocumentID.forEach((item, index) => {
          this.uploader.addToQueue(fileBrowser.files);
          this.dummyUploaderQueue.push({
            documentTypeID: item.documentTypeID,
            documentTypeName: item.documentTypeName,
            fileName: fName[fName.length - 1],
          });
          this.validBrowsedFile.forEach((vitem, vindex) => {
            if (vitem.documentTypeID == item.documentTypeID) {
              this.validBrowsedFile[vindex].sub.push({
                documentTypeID: item.documentTypeID,
                documentTypeName: item.documentTypeName,
                fileName: fName[fName.length - 1],
                delete: true,
                randomKey: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
              });
            }
          });
        });
        //new category
        this.selectedDocument.forEach((item, index) => {
          this.uploader.addToQueue(fileBrowser.files);
          this.dummyUploaderQueue.push({
            documentTypeID: item.documentTypeID,
            documentTypeName: item.documentTypeName,
            fileName: fName[fName.length - 1],
          });
          this.validBrowsedFile.push({
            outstanding: false,
            documentTypeID: item.documentTypeID,
            documentTypeName: item.documentTypeName,
            sub: [{
              documentTypeID: item.documentTypeID,
              documentTypeName: item.documentTypeName,
              fileName: fName[fName.length - 1],
              delete: true,
              randomKey: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
            }]
          });
        });      
        //reset selected new & old document
        this.selectedDocument = [];
        this.selectedOldDocumentID = [];
        $('input[name="checkBoxes"]').prop('checked', false);
        this.browseShow = false;
      }
  }

  searchDocument(seachField) {
    this.searchText = seachField.target.value;
  }

  movetoRight(document) {
    this.selectedDocumentID.push(document.documentTypeID);
    this.selectedDocument.push(document);
  }

  movetoLeft(document) {
    this.selectedDocumentID.splice(this.selectedDocumentID.indexOf(document.documentTypeID), 1);
    this.selectedDocument = this.selectedDocument.filter(x => x.documentTypeID != document.documentTypeID);
  }

  constructclaimStrategy(){
   
    this.applicationDetails.claimStrategy.forEach(item => {
      let stratgeyText = item.comments;
      if(stratgeyText && stratgeyText!=''){
        let finalText = stratgeyText.replace(/\n/g, '<br/>');
        item.comments = finalText;
        this.claimStrategy.push(item);
      }      
    });
  }

  constructEventHistory(eventInfo) {
    this.eventInfoSettings = {
      actions: false,
      attr: {
        class: 'table table-responsive table-striped specialTable'
      },
      columns: {
        eventDate: {
          title: 'Date',
          filter: false,
          class: 'absoluteHeading',
          width: '100%',
          sortDirection: 'desc',
          valuePrepareFunction: (value) => {
            if (value) {
              return this.datePipe.transform(value, "dd/MM/yyyy");
            } else {
              return '-';
            }
          }
        },
        eventName: {
          title: 'Event',
          sort: false,
          class: 'hideHeading',
          width: '0%'
        },
        eventRequirement: {
          title: 'Description',
          sort: false,
          class: 'hideHeading',
          width: '0%'
        },
        eventComments: {
          title: 'Comments',
          sort: false,
          class: 'hideHeading',
          width: '0%'
        }
      }
    };
    this.eventInfoData = [];
    eventInfo.forEach(item => {
      this.eventInfoData.push({
        'eventDate': new Date(item.eventDate).getTime(),
        'eventName': item.event,
        'eventRequirement': item.description,
        'eventComments': item.comments
      });
    });
  }
  constructPaymentHistorySCI(paymentInfo) {
    this.paymentInfoSettings = {
      actions: false,
      attr: {
        class: 'table table-responsive table-striped specialTable extraPadding'
      },
      columns: {
        datePaid: {
          title: 'Date paid',
          filter: false,
          width: '20%',
          sortDirection: 'desc',
          valuePrepareFunction: (value) => {
            if (value) {
              return this.datePipe.transform(value, "dd/MM/yyyy");
            } else {
              return '-';
            }
          }
        },
        paidFrom: {
          title: 'Paid from',
          filter: false,
          width: '20%',
          valuePrepareFunction: (value) => {
            if (value) {
              return this.datePipe.transform(value, "dd/MM/yyyy");
            } else {
              return '-';
            }
          }
        },
        paidTo: {
          title: 'Paid to',
          filter: false,
          width: '20%',
          valuePrepareFunction: (value) => {
            if (value) {
              return this.datePipe.transform(value, "dd/MM/yyyy");
            } else {
              return '-';
            }
          }
        },
        amount: {
          title: 'Amount paid',
          filter: false,
          width: '20%',
          valuePrepareFunction: (value) => {
            if (value) {
              return this.currencyConverter.transform(value, 'USD', true);
            } else {
              return '-';
            }
          }
        }
      }
    };
    this.paymentInfoData = [];
    paymentInfo.forEach(item => {
      this.paymentInfoData.push({
        'datePaid': new Date(item.dispatchDate).getTime(),
        'paidFrom': new Date(item.fromDate).getTime(),
        'paidTo': new Date(item.toDate).getTime(),
        'amount': item.amount ? item.amount : 0
      });
    });
  }

  constructPaymentHistoryGroup(paymentInfo) {
    this.paymentInfoSettings = {
      actions: false,
      attr: {
        class: 'table table-responsive table-striped specialTable extraPadding'
      },
      columns: {
        datePaid: {
          title: 'Date paid',
          filter: false,
          width: '20%',
          sortDirection: 'desc',
          valuePrepareFunction: (value) => {
            if (value) {
              return this.datePipe.transform(value, "dd/MM/yyyy");
            } else {
              return '-';
            }
          }
        },
        sumInsured: {
          title: 'Sum insured',
          filter: false,
          width: '20%',
          valuePrepareFunction: (value) => {
            if (value) {
              return this.currencyConverter.transform(value, 'USD', true);
            } else {
              return '-';
            }
          }
        },
        amount: {
          title: 'Amount paid',
          filter: false,
          width: '20%',
          valuePrepareFunction: (value) => {
            if (value) {
              return this.currencyConverter.transform(value, 'USD', true);
            } else {
              return '-';
            }
          }
        }
      }
    };
    this.paymentInfoData = [];
    paymentInfo.forEach(item => {
      this.paymentInfoData.push({
        'datePaid': new Date(item.dispatchDate).getTime(),
        'sumInsured': item.sumInsured ? item.sumInsured : 0,
        'amount': item.amount ? item.amount : 0
      });
    });
  }
  exportExcel() {
    this.ReportDetService.exportAsExcel(this.exportFileURL).subscribe(data => {

      if (navigator.appVersion.toString().indexOf('.NET') >= 0) {
        window.navigator.msSaveBlob(data, 'Claims_event_history.xlsx');
      } else {
        const fileStream = new Blob([data], { type: 'application/octet-stream' });
        const anchorTag = document.createElement('a');
        document.body.appendChild(anchorTag);
        const fileURL = URL.createObjectURL(fileStream);
        anchorTag.href = fileURL;
        anchorTag.download = 'Claims_event_history.xlsx';
        anchorTag.click();
      }

    });
  }

  navigateToFreshReport() {
    this.searchData.resetSearchModel();
    sessionStorage.setItem('Searched', 'false');
    this.router.navigate(['/claims/status/reports'])
  }
}