import { ValidateClaimModule } from './validate-claim.module';

describe('ValidateClaimModule', () => {
  let ValidateModules: ValidateClaimModule;

  beforeEach(() => {
    ValidateModules = new ValidateClaimModule();
  });

  it('should create an instance', () => {
    expect(ValidateModules).toBeTruthy();
  });
});
