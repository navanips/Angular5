import { Component, OnInit, HostListener } from '@angular/core';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConfiguration } from '../../../../app-configuration';
import { ClaimSearchModel } from '../../../../service/claim/claim-search-model';
import { ClaimReportsService } from '../../../../service/claim/claim-reports.service';
import { ClaimSearchService } from '../../../../service/claim/claim-search.service';
import { RestApiService } from '../../../../service/rest-api.service';
import { FlashMessageService } from '../../../../service/flash-message/flash-message.service';
import { UserService } from '../../../../service/user/user.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
   showFilter: boolean = true;
   gridColumns: any;
   reports: any = [];
   searched:boolean = false;
   searchData: any;
   fundList: any;
   status: any;
   currentSort: any;
   reportLimit: any;
   reportOffset: any;
   curPageIndex: any;
   metadata: any ={count:''};
   pageType: any;
   config: any; 
   userPermissions:any;
   roles;
   public dateRangeExceeded: Boolean;
   public futureDateRange: Boolean;
   public startDateRange:Boolean;
   searchNewFlag = false;
   dateRangeExceededErrorMsg: any;
   //applicationdateinvalid:boolean;

   public today: Date = new Date(new Date().toDateString());
   public dateValue: Date = new Date();
   public weekStart: Date = new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000));;
   public weekEnd: Date = this.today;
   public monthStart: Date = new Date(new Date(new Date().setDate(1)).toDateString()); 
   public monthEnd: Date = this.today;  
   public lastStart: Date = new Date(new Date(new Date(new Date().setMonth(new Date().getMonth() - 1)).setDate(1)).toDateString()); 
   public lastEnd: Date = new Date(new Date().getFullYear(), new Date().getMonth(), 0); 
   public yearStart: Date = new Date(new Date().getFullYear(), 0, 1); 
   public yearEnd: Date = this.today; 
   public format = 'dd/MM/yyyy';

   @HostListener('window:beforeunload') goToPage() {
    sessionStorage.setItem('Searched' , JSON.stringify(this.searched));
    sessionStorage.setItem('reportName' , 'ValidateClaim');
    sessionStorage.setItem('reportData' , JSON.stringify(this.data.valiadtemodel));
  }

   constructor(private userService: UserService, private route: ActivatedRoute, private router: Router,
    private data: ClaimSearchModel, public claimReportService: ClaimReportsService,private appConfig: AppConfiguration, public claimSearchSvc: ClaimSearchService,public http:RestApiService, private errorMsg: FlashMessageService) {
      let perm  = (JSON.parse(sessionStorage.getItem('userDetails')).menus)?JSON.parse(sessionStorage.getItem('userDetails')).menus:[];
      this.userPermissions = perm.join(',');
      let roles  = (JSON.parse(sessionStorage.getItem('userDetails')).roles)?JSON.parse(sessionStorage.getItem('userDetails')).roles:[];
      this.roles = roles.join(',')
      this.userPermissions = perm.join(',');
      this.getFund();
     }

    ngOnInit() {
      // if(this.route.snapshot.data['reports']) {
      //   this.reports = this.route.snapshot.data['reports'].items;
      //   this.metadata = this.route.snapshot.data['reports'].metadata;
      // }
      this.errorMsg.hideErrorMessage();
      this.dateRangeExceeded = false;
      this.futureDateRange = false;
      this.startDateRange = false;
      if(!sessionStorage.getItem('reportData') && sessionStorage.getItem('reportName') != 'ValidateClaim') {
        this.data.ValidteresetSearchModel();
      }
      this.searchData = Object.assign({}, this.data.valiadtemodel);
        sessionStorage.setItem('reportName' , 'ValidateClaim');
        sessionStorage.setItem('reportData' , JSON.stringify(this.data.valiadtemodel))
      // this.searchData = Object.assign({}, this.data.valiadtemodel);
      // sessionStorage.setItem('reportName' , 'ValidateClaim');
      // sessionStorage.setItem('reportData' , JSON.stringify(this.data.valiadtemodel))

      this.status = [
        { name: '', value: 'All' },
        { name: 'Pending', value: 'Pending' },
        { name: 'Submit', value: 'Submitted' }
      ];
      this.currentSort = 'credte';
      this.reportLimit = this.data.valiadtemodel.metaData.reportLimit - this.data.valiadtemodel.metaData.reportOffset;
      this.reportOffset = 0;
      // this.showFilter = false;
      
      let lim = this.reportLimit;
      let offs = (this.data.valiadtemodel.metaData.reportLimit == 0)?20:this.data.valiadtemodel.metaData.reportLimit;
      let pageindex = (parseInt(offs)/parseInt(lim));
      this.curPageIndex = pageindex;

      let dataSort = this.data.valiadtemodel.metaData;

      this.config = {
      itemsPerPage: this.reportLimit,
      currentPage: this.curPageIndex,
      totalItems: this.metadata.count
      }; 
      this.gridColumns = [
        {
          columnKey: 'claimrefno',
          columnTitle: 'eClaims reference no.',
          currentSort: (dataSort.orderby == 'claimrefno')?true:false,
          order: (dataSort.orderby == 'claimrefno')?dataSort.order:'asc',
          columnWidth: 15
        },
        {
          columnKey: 'partner',
          columnTitle: 'Fund name',
          currentSort: (dataSort.orderby == 'partner')?true:false,
          order: (dataSort.orderby == 'partner')?dataSort.order:'asc',
          columnWidth: 12
        },
        {
          columnKey: 'fname',
          columnTitle: 'Insured first name',
          currentSort: (dataSort.orderby == 'fname')?true:false,
          order: (dataSort.orderby == 'fname')?dataSort.order:'asc',
          columnWidth: 12
        },
        {
          columnKey: 'lname',
          columnTitle: 'Insured last name',
          currentSort: (dataSort.orderby == 'lname')?true:false,
          order: (dataSort.orderby == 'lname')?dataSort.order:'asc',
          columnWidth: 12
        },        
        {
          columnKey: 'dob',
          columnTitle: 'Insured date of birth',
          currentSort: (dataSort.orderby == 'dob')?true:false,
          order: (dataSort.orderby == 'dob')?dataSort.order:'asc',
          columnWidth: 9
        },
        {
          columnKey: 'credte',
          columnTitle: 'Lodgement date',
          currentSort: (dataSort.orderby == 'credte')?true:false,
          order: (dataSort.orderby == 'credte')?dataSort.order:'desc',
          columnWidth: 10
        },
        {
          columnKey: 'productDesc',
          columnTitle: 'Product',
          currentSort: (dataSort.orderby == 'productDesc')?true:false,
          order: (dataSort.orderby == 'productDesc')?true:false,
          columnWidth: 12
        },
        {
          columnKey: 'lstupdbyusr',
          columnTitle: 'Actioned by',
          currentSort: (dataSort.orderby == 'lstupdbyusr')?true:false,
          order: (dataSort.orderby == 'lstupdbyusr')?true:false,
          columnWidth: 12
        },
        {
          columnKey: 'claimStatusDesc',
          columnTitle: 'Status',
          currentSort: (dataSort.orderby == 'claimStatusDesc')?true:false,
          order: (dataSort.orderby == 'claimStatusDesc')?true:false,
          columnWidth: 8
        },
        {
          columnKey: 'coverTypeDesc',
          columnTitle: 'Claim type',
          currentSort: (dataSort.orderby == 'coverTypeDesc')?true:false,
          order: (dataSort.orderby == 'coverTypeDesc')?true:false,
          columnWidth: 12
        }
      ];
      if(sessionStorage.getItem('Searched') == 'true') {
        this.filterResults();
        // this.claimReportService.ValiadtesearchReports('validateReports').subscribe((reportsObj: any) => {
        //   this.reports = reportsObj.items;
        //   this.metadata = reportsObj.metadata;
        //   this.searched = true;
        //   sessionStorage.setItem('Searched' , JSON.stringify(this.searched));
        //   this.showFilter = false;
        //   this.config = {
        //     itemsPerPage: this.reportLimit,
        //     currentPage: this.curPageIndex,
        //     totalItems: this.metadata.count
        //   }; 
        // });
        // this.showFilter = false;
      }
    }

    getFund() {
      this.http.get(this.appConfig.URLS.claims.validatefund).subscribe(response => {
        this.fundList = response;
      }); 
    }
    navigateToParent(){
      this.router.navigate(['.'], { relativeTo: this.route.parent });
    }

    onExportReport() {
      this.errorMsg.hideErrorMessage();
      this.claimReportService.ValiadteexportClaimReports('claimValiadteExport').subscribe(data => {
        if (navigator.appVersion.toString().indexOf('.NET') >= 0) {
          window.navigator.msSaveBlob(data, 'eClaims_Report.xlsx');
        } else {
          const fileStream = new Blob([data], {type: 'application/octet-stream'});
          const anchorTag = document.createElement('a');
              document.body.appendChild(anchorTag);
          const fileURL = URL.createObjectURL(fileStream);
          anchorTag.href = fileURL;
                      anchorTag.download = 'eClaims_Report.xlsx';
                      anchorTag.click();
        }
        }, err => {
          this.errorMsg.showErrorMessage();
        });
    }

    sortResults(sortColumn) {
    for (const column of this.gridColumns) {
      if (column === sortColumn) {
        column.currentSort = true;
      } else {
        column.currentSort = false;
      }
    }
    if(this.data.valiadtemodel.metaData.orderby == sortColumn.columnKey) {
      sortColumn.order = (sortColumn.order == 'asc')?'desc':'asc';
    }
    else {
      sortColumn.order = 'asc';
    }      
    this.curPageIndex = 1;
    this.data.valiadtemodel.metaData.reportOffset = '0';
    this.data.valiadtemodel.metaData.reportLimit = this.reportLimit;
    this.data.valiadtemodel.metaData.orderby = sortColumn.columnKey;
    this.data.valiadtemodel.metaData.order = sortColumn.order;
    this.filterResults();
  }

  //  onDateChange(searchValue : any ) { 
  //   const diffTime = Math.abs(searchValue.model.angularValue[1].getTime() - searchValue.model.angularValue[0].getTime());
  //   const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
  //   if(diffDays<=365){
  //     this.applicationdateinvalid = false;
  //   }else{
  //     this.applicationdateinvalid = true;
  //   } 
  // }
  
  toggleFilters() {
    this.showFilter = !this.showFilter;
  }

  canceltoggleFilters(){
    //this.data.ValidteresetSearchModel();
    let reportData = Object.assign({}, this.data.resetvalidemodel);
    this.searchData = reportData;
    // sessionStorage.setItem('reportData',JSON.stringify(this.data.valiadtemodel))
    // if(this.data.valiadtemodel.applicationdate){
    //   let reportData = JSON.parse(sessionStorage.getItem('reportData'));
    //   this.searchData = reportData;
    // }
    // else{
    //   let reportData = JSON.parse(sessionStorage.getItem('reportData'));
    //   this.searchData = reportData;
    //   this.data.valiadtemodel.applicationdate = [new Date(new Date(new Date().setFullYear(new Date().getFullYear() - 1)).toDateString()), new Date(new Date().toDateString())];
    // }
  }

  searchfilterResults() {
    let orderKey = this.searchData.metaData.orderby;
    let orderType = this.searchData.metaData.order;
    sessionStorage.setItem('reportName' , 'ValidateClaim');    
    sessionStorage.setItem('reportData' , JSON.stringify(this.searchData));
    
    // if(sessionStorage.getItem('Searched') == 'true') {
    //   this.curPageIndex = this.reportLimit / 20;
    // } else {
    //   this.curPageIndex = 1;
    // }
    // if(this.searchNewFlag == true){
    //   this.curPageIndex = 1;
    //   this.reportLimit = 20;
    // }
    this.searchData.metaData = {
      reportLimit: this.reportLimit,
      reportOffset: '0',
      orderby: orderKey,
      order: orderType
    };
    this.curPageIndex = 1;
    this.data.valiadtemodel = Object.assign({}, this.searchData);
    this.filterResults()
  }
  
  filterResults() {
    
        this.errorMsg.hideErrorMessage();
        this.claimReportService.ValiadtesearchReports('validateReports').subscribe((reportsObj: any) => {
        this.reports = (reportsObj.items)?reportsObj.items:[];
        this.metadata = reportsObj.metadata;
        this.searched = true;        
        sessionStorage.setItem('Searched' , JSON.stringify(this.searched));
        this.showFilter = false;
        this.searchNewFlag=true;
        this.config = {
          itemsPerPage: this.reportLimit,
          currentPage: this.curPageIndex,
          totalItems: (this.metadata)?this.metadata.count:0
        };
        if(this.metadata == null || this.metadata.count == 0){
          this.searched = false;
          this.showFilter = true;
        }
        },err => { 
          this.reports = [];
          this.metadata = {offset:0,limit:20,count:0};
          this.showFilter = true;
          this.searched = false;
          this.errorMsg.showErrorMessage();
        }); 
  }

  pageChanged(event) { 
    this.curPageIndex = event;
    this.data.valiadtemodel.metaData.reportOffset =
    ((Number(this.reportLimit) * (this.curPageIndex - 1))).toString();
    // this.data.valiadtemodel.metaData.reportOffset = '0';
    this.data.valiadtemodel.metaData.reportLimit = Number(this.reportLimit) * (this.curPageIndex);
    this.filterResults();
  }

  onLimitChange(limit: any) {
    if(limit < this.reportLimit) {
      this.scrollToTop();
    }
    this.reportLimit = limit;
    this.curPageIndex = 1;
    this.data.valiadtemodel.metaData.reportOffset = '0';
    this.data.valiadtemodel.metaData.reportLimit = limit;
    this.filterResults();
  }

  scrollToTop() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  }
  dateOnly(event) {
    const regEx = this.appConfig.appConstants.regEx.dateOnly;
    return event.key.match(regEx) ? true : false;
  }

  dateRangeOnly(event) {
    if (event.keyCode === 13 || event.keyCode === 32 || event.keyCode === 47 || event.keyCode === 45) {
      return;  // let enter it happen
    }
    const regEx = this.appConfig.appConstants.regEx.dateRangeOnly;
    return event.key.match(regEx) ? true : false;
  }

  onDateRangeChange(event) {
    this.futureDateRange = event.endDate > this.today ? true : false;    
    this.startDateRange = event.endDate >= event.startDate ? false : true;

    let externalUser = this.userService.checkExternalUser();
    if (externalUser) {
      let lastYearDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
      this.dateRangeExceeded = event.startDate >= lastYearDate ? false : true;
      this.dateRangeExceededErrorMsg = 'Time period cannot exceed 12 Months from Current Date.';
    } else {
      this.dateRangeExceeded = event.daySpan > this.appConfig.appConstants.maxDateRangeAllowed ? true : false;
      this.dateRangeExceededErrorMsg = 'Time period cannot exceed 1 year';
    }
  }
}
