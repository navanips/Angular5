import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { NgxPaginationModule } from 'ngx-pagination';
import { FileUploadModule } from 'ng2-file-upload';
import { AlertModule } from 'ngx-bootstrap';
import { DateFormatPipe } from '../../../filters/date-format.pipe';

import { ReportsComponent } from './reports/reports.component';
import { DetailsComponent } from './details/details.component';
import { ValidateGuard } from '../../../guards/validate.guard';
import { ValidateClaimReportDetailsService } from '../../../service/claim/validate-claim-report-details.service';
import { CustomDirectiveModule } from '../../../directives/custom-directive/custom-directive.module';

const routes: Routes = [

  {
    path: '', component: ReportsComponent, canActivate: [ValidateGuard],
    data: {
      reportURL: 'validateReports',
      permissionId: ['eClaims_ValidateClaim', 'Claims_ValidateClaim']
    }
  },
  {
    path: 'reports', component: ReportsComponent, canActivate: [ValidateGuard],
    data: {
      reportURL: 'validateReports',
      permissionId: ['eClaims_ValidateClaim', 'Claims_ValidateClaim']
    }
  },
  {
    path: 'reports/:id', component: DetailsComponent, canActivate: [ValidateGuard],
    resolve: {
      data: ValidateClaimReportDetailsService,
    },
    data: {
      reportType: 'validate',
      permissionId: ['eClaims_ValidateClaim', 'Claims_ValidateClaim']
    }
  }
];

@NgModule({
  declarations: [ReportsComponent, DetailsComponent, DateFormatPipe],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(routes),
    DateRangePickerModule,
    DatePickerModule,
    NgxPaginationModule,
    FileUploadModule,
    AlertModule.forRoot(),
    CustomDirectiveModule
  ]
})
export class ValidateClaimModule { }