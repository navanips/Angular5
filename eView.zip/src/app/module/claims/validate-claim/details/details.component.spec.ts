import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { DetailsComponent } from './details.component';
import { AppConfiguration } from '../../../../app-configuration';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { ValidateClaimReportDetailsService } from '../../../../service/claim/validate-claim-report-details.service';
import {
  HttpModule,
  Http,
  Response,
  ResponseOptions,
  XHRBackend
} from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { AlertModule } from 'ngx-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { FileUploadModule } from 'ng2-file-upload';
import { ClaimSearchModel } from '../../../../service/claim/claim-search-model';
import { FlashMessagesService } from 'angular2-flash-messages';
import { ActivatedRoute } from '@angular/router'

describe('DetailsComponent', () => {
  let component: DetailsComponent;
  let fixture: ComponentFixture<DetailsComponent>;
  let de: DebugElement;
  let el:HTMLElement;
  const route = ({ snapshot:{data:{data: {   
    claim:{"actionBy":"test","claimReferenceNo":"EAC4001608","fundCode":"Virgin","fundName":"CITV","product":"CRESHLDED","status":"Pending","submittedDate":"2019-10-02T03:07:13.338","type":"DISABILITY","claimID":1007077,"claimSummaryPdf":"/shared/eclaims/EAC4001608_201910020307.pdf","productDesc":"CreditShield Edge","typeDesc":"Injury/Illness (Disability)","statusDesc":"Pending"},"member":{"firstName":"Yuvarajan","memberDob":"1989-02-02T00:00","memberGender":null,"surName":"B","title":"Mr"},"policy":{"policyProductTypes":[{"code":"CRESHLDED","codeName":"CreditShield Edge"}],"policyClaimTypes":null,"individualPartnerCheck":true,"existCreditCardNo":"4444","eventDate":"02/02/2016"},"uploadedDocuments":[{"documentId":3019294,"documentLocation":"/shared/eclaims/abc_1569949555016.pdf","docName":"abc_1569949555016.pdf","docType":"Medical Statement","documentStatus":"ACT"}]
  } } } } as any) as ActivatedRoute

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailsComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        DateRangePickerModule,
        DatePickerModule,        
        RouterTestingModule,
        HttpClientTestingModule,
        AlertModule,
        FileUploadModule
      ],
      providers: [
        AppConfiguration,
        ValidateClaimReportDetailsService,
        { provide: XHRBackend, useClass: MockBackend },
        ClaimSearchModel,
        FlashMessagesService,
        { provide: ActivatedRoute, useValue: route }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('form'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Policy information not to be shown',() =>{
    const policyInfo = fixture.debugElement.query(By.css('#existingccYes'));
    expect(policyInfo).toBeFalsy();
  });

  it('Policy information Start & end date validation',() =>{
    const startDate = fixture.debugElement.query(By.css('#startDate'));
    if(startDate) {
      expect(startDate.nativeElement.value).toBe('');
    }
    const endDate = fixture.debugElement.query(By.css('#endDate'));
    if(endDate) {
      expect(endDate.nativeElement.value).toBe('');
    }
  });

  // it('Minimum monthly payment should enable for injured & unemployment',() =>{
  //   const monthpayment = fixture.debugElement.query(By.css('#amount_claim'));
  //   expect(monthpayment).toBeTruthy();
  // });

  // it('Minimum monthly payment should accept numbers only',() =>{
  //   const monthpayment = fixture.debugElement.query(By.css('#amount_claim'));
  //   monthpayment.nativeElement.value = 'metlife';
  //   expect(monthpayment.nativeElement.value).toMatch(/^[0-9]+$/);
  // });

  it('upload button should upload the file',() =>{
    el = fixture.debugElement.query(By.css('#SubmitBtn')).nativeElement;
    el.click();
    expect(component.upload).toBeTruthy();
  });

  // it('delete button should delete the file',() =>{
  //   el = fixture.debugElement.query(By.css('#delete1')).nativeElement;console.log(el)
  //   el.click();
  //   expect(component.removeTableData).toBeTruthy();
  // });

  it('submitter name & email should not to null', () => {
    const submitterName = fixture.debugElement.query(By.css('#submitterName'));
    submitterName.nativeElement.value = "";
    expect(submitterName.nativeElement.value).not.toBe(null);

    const submitterEmail = fixture.debugElement.query(By.css('#submitterEmail'));
    submitterEmail.nativeElement.value = "";
    expect(submitterEmail.nativeElement.value).not.toBe(null);
  });
  
  it('submitter name & email should not exceed 32 characters', () => {
    const submitterName = fixture.debugElement.query(By.css('#submitterName'));
    submitterName.nativeElement.value = "Test";
    expect(submitterName.nativeElement.value.length).not.toBeGreaterThan(32);

    const submitterEmail = fixture.debugElement.query(By.css('#submitterEmail'));
    submitterEmail.nativeElement.value = "test@cognizant.com";
    expect(submitterEmail.nativeElement.value.length).not.toBeGreaterThan(32);
  });

  it('should submit',async(() => {
    fixture.detectChanges();
    spyOn(component,'onSubmit');
    expect(component.onSubmit).toBeTruthy ();
  }));

  it('should download the pdf',async(() => {
    el = fixture.debugElement.query(By.css('#SummaryPdf')).nativeElement;
    el.click();
    expect(component.downloadPDF).toBeTruthy();
  }));

});
