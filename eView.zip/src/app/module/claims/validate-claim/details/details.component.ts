import { Component, OnInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { ClaimReportDetailsService } from '../../../../service/claim/claim-report-details.service';
import { AppConfiguration } from '../../../../app-configuration';
import { RestApiService } from '../../../../service/rest-api.service';
import { FileUploader, FileItem, ParsedResponseHeaders, FileUploaderOptions, Headers } from 'ng2-file-upload';
import { ClaimSearchModel } from '../../../../service/claim/claim-search-model';
import * as $ from 'jquery';
import * as moment from 'moment';
import { NgxSpinnerService } from "ngx-spinner";
import { CustomSpinnerService } from '../../../../service/spinner/custom-spinner.service';
import { FlashMessageService } from '../../../../service/flash-message/flash-message.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  @ViewChild('fileInput') fileInput: any;
  applicationDetails: any;
  PDFName : any;
  userPermissions:any;
  public alerts: any[] = [];
  selectedDoc = [];
  selectedDocId = [];
  tableData = [];
  tableDataRef = [];
  selectedOld = [];
  selectedOldDoc = [];
  fileUploadRequest = 0;
  totalRequest = 0;
  successRequest = 0;
  uploadSummary:any;
  exportFileURL: any;
  appStatus: any;
  userDetails: any;
  docList: any;
  policyInfoDiv;
  ccNoDiv;
  submitted = false;
  ReqDiv = false;
  amtOutInt; 
  outStandBal;
  searchVal = '';
  assObj = [];
  minMotnhlyPayment;
  fromDate;
  toDate;
  submitObj = {
    claim : {
      additional: "",
      claimReferenceNo: ""
    },
    insured : {
      userName:"",
      submittedEmail: "",
      submittedPhone: "",
      firstName : "",
      lastName: "",
      dateOfBirth: "",
      title : "",
      gender : "",
    },
    eligibilityCheck : {
      existingCreditCardInsurance : ""
    },
    policy : {
      insuranceCommencementStartDate: "",
      insuranceCommencementEndDate:"",
      claimType:"",
      eventDate:"",
      product:""
    },
    document : []
  };
  public uploader: FileUploader = new FileUploader({});
  private uploaderOptions: FileUploaderOptions = {};
  progress= [];
  fileNames = [];
  uploadBtnShow;
  browseShow;
  dateDiv = false;
  NoCCDiv = false;
  public format = 'dd/MM/yyyy';
  constructor(private spin:CustomSpinnerService, private appConfig: AppConfiguration, private route: ActivatedRoute,
    private router: Router, private ReportDetService: ClaimReportDetailsService, private location: Location,private api:RestApiService, private claimModel: ClaimSearchModel, private errorMsg: FlashMessageService) {
      if(sessionStorage.getItem('userDetails')) {
        let perm  = (JSON.parse(sessionStorage.getItem('userDetails')).menus)?JSON.parse(sessionStorage.getItem('userDetails')).menus:[];
        this.userPermissions = perm.join(',');
      }
      this.userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
      if(this.userDetails) {
        this.submitObj.insured.userName = this.userDetails.firstName+' '+this.userDetails.lastName;
        this.submitObj.insured.submittedEmail = this.userDetails.email;
        this.submitObj.insured.submittedPhone = this.userDetails.mobile;
      }
      this.uploaderOptions['method'] = 'POST';
      this.uploaderOptions['autoUpload'] = false;
      this.uploaderOptions['maxFileSize'] = 50 * 1024 * 1024;
      this.uploaderOptions['allowedMimeType'] = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/csv', 'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','image/png','image/jpeg','image/jpg'];
      this.uploaderOptions['authToken'] = "Bearer " + sessionStorage.getItem('userToken');
      this.uploader.setOptions(this.uploaderOptions);
    }

  ngOnInit() {
      this.errorMsg.hideErrorMessage();
      this.applicationDetails = this.route.snapshot.data['data'];
      if(this.applicationDetails) {
        this.appStatus = this.applicationDetails.claim.status;
        this.exportFileURL = this.appConfig.URLS.claims.claimValiadteExport + '/' + this.applicationDetails.claim.claimNo;
        let clType = this.applicationDetails.claim.type;
  
        if(clType == 'CRTILLNESS' || clType == 'DEATH' ) {
          this.amtOutInt = true;
        } else if(clType == 'DISABILITY' || clType == 'INVOUNEMPY' || clType == 'UNEMPLOY') {
          this.minMotnhlyPayment = true;
        } else if(clType == 'LIFEEVNTS') {
          this.outStandBal = true;
        }

        this.submitObj.claim.claimReferenceNo = this.applicationDetails.claim.claimReferenceNo;

        this.submitObj.insured.firstName = this.applicationDetails.member.firstName;
        this.submitObj.insured.lastName = this.applicationDetails.member.surName;
        this.submitObj.insured.dateOfBirth = this.applicationDetails.member.memberDob;
        this.submitObj.insured.title = this.applicationDetails.member.title;
  
        this.submitObj.policy.claimType = this.applicationDetails.policy.claimType;
        this.submitObj.policy.eventDate = this.applicationDetails.policy.eventDate;
        this.submitObj.policy.product = (this.applicationDetails.policy.policyProductTypes)?this.applicationDetails.policy.policyProductTypes[0].code:'';
        this.removeClaimSummary();

        if(this.applicationDetails.claim.claimSummaryPdf){
          let pdfName = this.applicationDetails.claim.claimSummaryPdf.split('/');
          this.PDFName = pdfName[pdfName.length-1];
        }        
      }

     this.getDoc();
     this.uploader.onWhenAddingFileFailed = (item, filter) => {
      if(filter.name == 'fileSize') { 
        this.uploadSummary = [];  
        this.uploadSummary.push({
          status : 'error',
          fileName : '',
          message : 'File size exceeds the maximum of 50 MB per file.You can upload mutiple files if required.',
        });        
      }
      if(filter.name == 'mimeType') { 
        this.uploadSummary = [];  
        this.uploadSummary.push({
          status : 'error',
          fileName : '',
          message : 'The selected file type is not a valid file type. The following file formats only are supported *.pdf, *.doc, *.docx, *.xls, *.xlsx, *.csv, *.jpg, *.jpeg, *.png',
        });        
      }      
    }; 
  }

  removeClaimSummary(){
    let deleteIndex = -1;
    this.applicationDetails.uploadedDocuments.forEach((element, index) => {
      let docTypeLength = element.docType.length;
      let checkDot = element.docType.charAt(docTypeLength-1);
      if(checkDot=='.'){
        element.docType = element.docType.slice(0, docTypeLength-1);
      }
      if(element.docType.toLowerCase()=='claim summary'){
        deleteIndex = index;
      }
    });
    if(deleteIndex > -1) {
      this.applicationDetails.uploadedDocuments.splice(deleteIndex, 1);
    }
  }

  ngAfterViewInit()
  {
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
    });    
  }

  navigateToPrevPage() {
    this.router.navigate(['.'], { relativeTo: this.route.parent });
  }

  exportExcel() {
    this.errorMsg.hideErrorMessage();
    this.ReportDetService.exportAsExcel(this.exportFileURL).subscribe(data => {

      if (navigator.appVersion.toString().indexOf('.NET') >= 0) {
        window.navigator.msSaveBlob(data, 'Validate Claim Report.xlsx');
      } else {
        const fileStream = new Blob([data], {type: 'application/octet-stream'});
        const anchorTag = document.createElement('a');
        document.body.appendChild(anchorTag);
        const fileURL = URL.createObjectURL(fileStream);
        anchorTag.href = fileURL;
        anchorTag.download = 'Validate Claim Report.xlsx';
        anchorTag.click();
      }
    }, err => {
      this.errorMsg.showErrorMessage();
    });
  }

  getDoc()
  {    
    let api;
    if(this.applicationDetails.policy.individualPartnerCheck === true) {
      api = '/validateclaim/VALIDATECLAIM_INDI';
    } else {
      api = '/validateclaim/VALIDATECLAIM_GROUP';
    }
    this.api.get(this.appConfig.URLS.validateClaim.DocList+api).subscribe(result => {
      this.docList = result;
    });  
  }

  onChange(event) {
    if(event === "Yes") { 
      this.policyInfoDiv = true; 
    } else {
      this.policyInfoDiv = false;
    }
  }

  CCNo(event){
    if(event === "Yes") { 
      this.ccNoDiv = true; 
    } else {
      this.ccNoDiv = false;
    }
  }
  checkValid(form) { 
    let focusArr = $('input,textarea,select').filter('[required]:visible');
    let check = false;
    focusArr.each(function(index) {
      if(focusArr[index].validity.valid == false && check == false) {
        focusArr[index].focus();
        check = true;
      }
    });
    if(form.valid == false) {
      $('#collapseFour').addClass('show')
    }
    if(this.policyInfoDiv || this.ccNoDiv) {
      this.dateDiv = true;
    }
    if(this.policyInfoDiv == false) {
      this.NoCCDiv = true;
    }
  }

  fixPos(event,val) {
    if (event.target.value != '') {
      if(event.target.value.length > 18) {
        event.target.value = event.target.value.substr(0,18)
      }
      let value = event.target.value.replace(/(,)/g, '')
      value = Number(value).toFixed(2);
      let amount = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
      if ((amount == NaN) || (amount == 'nan') || (amount == 'NaN')) {
        event.target.value = '';
      }
      else {
        event.target.value = amount;        
      }
    } 
  }
  
  numberOnly(event,type): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;    
    if (type === '2' && charCode === 46 && event.target.value.split('.').length === 2) { return false; }
    if (type === '2' && charCode > 31 && (charCode < 46 || charCode === 47 || charCode > 57)) {
      return false;
    } else if (type === '1' && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  removeTableData(data) {
    let ind = this.tableDataRef.findIndex(x => (x.documentTypeID == data.documentTypeID && x.documentTypeName == data.documentTypeName && x.Id == data.Id));
    this.tableData = this.tableData.filter(x => (x.Id != data.Id));
    this.uploader.queue.splice(ind,1);
    this.tableDataRef = this.tableDataRef.filter(x => (x.Id != data.Id));
  }

  onFileSelected(input) {
    let fName = [];
    if(this.fileInput.nativeElement.value) {
      fName = this.fileInput.nativeElement.value.split("\\")
    }
    let ext = fName[fName.length - 1].split('.');
    let arrExt = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'png', 'jpg', 'jpeg']
    if(arrExt.indexOf(ext[ext.length-1].toLowerCase()) == -1) {
      //this.uploader.queue.splice(this.uploader.queue.length-1,1);
      this.selectedDoc = [];
      this.selectedDocId = [];
      this.uploadSummary = [];
      this.uploadSummary.push({
        status: 'error',
        fileName: '',
        message: 'The selected file type is not a valid file type. The following file formats only are supported *.pdf, *.doc, *.docx, *.xls, *.xlsx, *.csv, *.jpg, *.jpeg, *.png',
      });
    }
    console.log(this.uploader.queue);    
    let validDoc = [];let inValid = [];
    for(let i = 0;i<this.selectedDoc.length;i++) {
      const fileBrowser = this.fileInput.nativeElement;
      if(i > 0) { 
        this.uploader.addToQueue(fileBrowser.files);
      }
      if(this.uploader._mimeTypeFilter(input.target.files[0]) && this.uploader._fileSizeFilter(input.target.files[0])) {
        let uniqId = Math.round((Math.pow(36, 10 + 1) - Math.random() * Math.pow(36, 10))).toString(36).slice(1);
        this.uploadSummary = [];
        this.tableData.push({
          Id: uniqId,
          docType : this.selectedDoc[i].docType,
          documentTypeID : this.selectedDoc[i].documentTypeID,
          documentTypeName: this.selectedDoc[i].documentTypeName,
          fileName: fName[fName.length-1],
          delete: (this.selectedDoc[i].delete==false)?false:true,
        });
        this.tableDataRef.push({
          Id: uniqId,
          docType : this.selectedDoc[i].docType,
          documentTypeID : this.selectedDoc[i].documentTypeID,
          documentTypeName: this.selectedDoc[i].documentTypeName,
          fileName: fName[fName.length-1],
          delete: (this.selectedDoc[i].delete==false)?false:true,
        });
        validDoc.push(this.selectedDoc[i])         
      } else {
        inValid.push(this.selectedDoc[i])
      }
    }
    //  this.selectedDoc = inValid;    
    this.selectedDoc = []; 
    this.selectedDocId = []; 
  }

  upload() { 
    if(this.uploader.queue.length > 0) {
      this.spin.show();
      this.totalRequest = 0;
      this.successRequest = 0;
      this.uploadSummary = [];
      this.uploader.queue.forEach((currentItem,index) => {
        this.fileUploadRequest++;
        this.totalRequest++;
        if(this.tableDataRef.length > index) {
          currentItem.url = this.appConfig.serviceBaseUrl+this.appConfig.URLS.validateClaim.fileUpload+'?docType='+this.tableDataRef[index].documentTypeName;
        }
      });    
        this.uploader.onBuildItemForm = (item, form) => {
          form.append('Type', item.alias);
          form.append('Key', item._file);
          form.append('multipart', item.file);
        };
        let ss= this.uploader.uploadAll();
        this.uploader.onErrorItem = (item, response, status, headers) => this.onErrorItem(item, response, status, headers);
        this.uploader.onSuccessItem = (item, response, status, headers) => this.onSuccessItem(item, response, status, headers); 
        this.uploader.onCompleteAll = () => {
          this.spin.hide();
          if(this.successRequest === this.totalRequest) { 
            this.formSubmit();
          }
        };
    }
  }

  onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    let ind = this.uploader.getIndexOfItem(item);
    this.uploader.removeFromQueue(item);
    let suc = JSON.parse(response); 
    this.tableData.filter(x=> (x.Id == this.tableDataRef[ind].Id)?x.delete=false:'' )
    this.tableDataRef.splice(ind,1);
    this.submitObj.document.push(suc[0]);
    this.uploadSummary.push({
      status : 'success',
      fileName : item.file.name,
      message : 'Document uploaded successfully',
    });
    this.successRequest++;
    this.fileUploadRequest--;
    if(this.fileUploadRequest == 0) {
        this.spin.hide();
    }
  }

  onErrorItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    let ind = this.uploader.getIndexOfItem(item);
    this.uploader.removeFromQueue(item);
   
    // this.selectedDoc.push(this.tableDataRef[ind]);
    this.tableData = this.tableData.filter(x => x.Id != this.tableDataRef[ind].Id)
    this.tableDataRef.splice(ind,1);         
    this.fileUploadRequest--;
    if(this.fileUploadRequest == 0){
        this.spin.hide();
    }
    if(response){
      let suc = JSON.parse(response);
      this.uploadSummary.push({
        status : 'error',
        fileName : item.file.name,
        message : suc.message,
      }); 
    }else{
      this.uploadSummary.push({
        status : 'error',
        fileName : item.file.name,
        message : 'An unexpected error has occurred. Please try again.',
      }); 
    }
       
  }
  
  changeDateFormat(val) {
    return val ? moment(new Date(val)).format('DD/MM/YYYY'):null;
  }

  dateformatChange(event,val) {
    if(val === 'from') { this.submitObj.policy.insuranceCommencementStartDate = this.changeDateFormat(event.value); 
    } else {
      this.submitObj.policy.insuranceCommencementEndDate = this.changeDateFormat(event.value);
    }
  }

  downloadPDF(url,filtype) {
    if(url !== null && url !== '') {
      this.api.downloadNoteReceipt(this.appConfig.URLS.validateClaim.downloadPDF+'?path='+url).subscribe(res => {
        let names = url.split("/");
        let mime;
        if(filtype.toLowerCase() == 'pdf' || filtype.toLowerCase() == 'doc' || filtype.toLowerCase() == 'docx' || filtype.toLowerCase() == 'xls' || filtype.toLowerCase() == 'xlsx' || filtype.toLowerCase() == 'jpg' || filtype.toLowerCase() == 'jpeg' || filtype.toLowerCase() == 'tif') {
          mime = 'application/'+filtype;
        } else if(filtype.toLowerCase() == 'txt') {
          mime = 'text/plain';
        }
        
        var newBlob = new Blob([res], { type: mime });
  
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(newBlob,names[names.length - 1]);
          return;
        }
        const data = window.URL.createObjectURL(newBlob);
        var link = document.createElement('a');
        link.href = data;
        link.download = names[names.length - 1];//+"."+filtype
        link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
  
        setTimeout(function () {
            window.URL.revokeObjectURL(data);
        }, 100);
  
      }, error => {
        
      })
    }
  }

  formSubmit() {
    this.errorMsg.hideErrorMessage();
    this.api.update(this.appConfig.URLS.claims.addClaims,this.submitObj).subscribe(result => {    
      if (result) {
        $('#submittedModal').show();
        this.uploadSummary = [];    
        this.uploadSummary.push({
          status : 'success',
          fileName : '',
          message : 'All document(s) uploaded successfully',
        });
      } else {
        this.alerts=[{
          'type':'danger',
          'msg':'An unexpected error has occurred. Please try again.',
          'timeout':30000
        }];
      }
    },err => {
      this.errorMsg.showErrorMessage();   
    });
  }
  onSubmit() {
    this.submitted = true;    
    if(this.uploader.queue.length > 0) {
      this.upload();
    } else {
      this.formSubmit();
    }
  }

  //Design Change functionality
  filterSearch(event) {
    this.searchVal = event.target.value;
  }
  movetoRight(id) {
    this.selectedDocId.push(id.documentTypeID);
    this.selectedDoc.push(id);
  }
  movetoLeft(id) {
    this.selectedDocId.splice(this.selectedDocId.indexOf(id.documentTypeID), 1);
    this.selectedDoc = this.selectedDoc.filter(x => x.documentTypeID != id.documentTypeID);
  }  
  FreshReport() {
    this.claimModel.ValidteresetSearchModel()
    sessionStorage.setItem('Searched','false');
    this.router.navigate(['/claims/validateClaim/reports'])
  }

  alphaOnly(event, val) {
    let letters;
    if (val === 'alpha') { letters = /^[A-Za-z]+$/; }
    else if (val === 'alphanum') { letters = /^[A-Za-z0-9/]+$/; }
    else if (val === 'num') { letters = /^[0-9]+$/; } else if(val == 'alphacomma') {
      letters = /^[A-Za-z-'\s]*$/;
    }
    if (event.key.match(letters)) { 
      return true; 
    } else { return false; }
  }
  resetForm(val) { 

    val.resetForm();
    this.tableData = [];
    this.tableDataRef = [];
    this.selectedDoc = [];
    this.selectedDocId = [];
    this.uploadSummary = [];
    this.policyInfoDiv = undefined;
    this.ccNoDiv = undefined;
    this.uploader.clearQueue();
    val.form.controls['userName'].setValue(this.userDetails.firstName+' '+this.userDetails.lastName);
    val.form.controls['emailID'].setValue(this.userDetails.email);
    val.form.controls['submittedPhone'].setValue(this.userDetails.mobile);
    if(val.form.controls['product']) {
      val.form.controls['product'].setValue((this.applicationDetails.policy.policyProductTypes)?this.applicationDetails.policy.policyProductTypes[0].code:'');
    }
    
  }  
}
