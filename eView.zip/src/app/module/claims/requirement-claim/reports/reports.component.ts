import { Component, OnInit, HostListener } from '@angular/core';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConfiguration } from '../../../../app-configuration';
import { ClaimSearchModel } from '../../../../service/claim/claim-search-model';
import { ClaimReportsService } from '../../../../service/claim/claim-reports.service';
import { ClaimSearchService } from '../../../../service/claim/claim-search.service';
import { RestApiService } from '../../../../service/rest-api.service';
import { UserService } from '../../../../service/user/user.service';
import { FlashMessageService } from '../../../../service/flash-message/flash-message.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  gridColumns: any;
  reports: any = [];
  searchData: any;
  fundList: any;
  types: any;
  status: any;
  currentSort: any;
  reportLimit: any;
  reportOffset: any;
  curPageIndex: any;
  metadata: any = { count: '' };
  pageType: any;
  claimdetail: any;
  claimtyperadio: any;
  userPermissions: any;
  showresult: boolean;
  searched: boolean = false;
  showFilter: boolean = true;
  public dateRangeExceeded: Boolean;
  public futureDateRange: Boolean;
  public startDateRange: Boolean;
  dateRangeExceededErrorMsg: any;

  public today: Date = new Date(new Date().toDateString());
  public dateValue: Date = new Date();
  public weekStart: Date = new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000));;
  public weekEnd: Date = this.today;
  public monthStart: Date = new Date(new Date(new Date().setDate(1)).toDateString());
  public monthEnd: Date = this.today;
  public lastStart: Date = new Date(new Date(new Date(new Date().setMonth(new Date().getMonth() - 1)).setDate(1)).toDateString());
  public lastEnd: Date = new Date(new Date().getFullYear(), new Date().getMonth(), 0);
  public yearStart: Date = new Date(new Date().getFullYear(), 0, 1);
  public yearEnd: Date = this.today;
  public format = 'dd/MM/yyyy';
  config: any;

  @HostListener('window:beforeunload') goToPage() {
    sessionStorage.setItem('Searched', JSON.stringify(this.searched));
    sessionStorage.setItem('reportName', 'CLREQ');
    sessionStorage.setItem('reportData', JSON.stringify(this.data.searchModal));
  }

  constructor(private userService: UserService, private errorMsg: FlashMessageService, private route: ActivatedRoute, private router: Router,
    private data: ClaimSearchModel, public claimReportService: ClaimReportsService, private appConfig: AppConfiguration, public claimSearchSvc: ClaimSearchService, private api: RestApiService) {
    let perm = (JSON.parse(sessionStorage.getItem('userDetails')).menus) ? JSON.parse(sessionStorage.getItem('userDetails')).menus : [];
    this.userPermissions = perm.join(',');
  }

  ngOnInit() {
    this.reports = [];
    this.showresult = false;
    this.errorMsg.hideErrorMessage();
    if (!sessionStorage.getItem('reportData') && sessionStorage.getItem('reportName') != 'CLREQ') {
      this.data.resetSearchModel();
    }
    this.searchData = Object.assign({}, this.data.searchModal);
    sessionStorage.setItem('reportName', 'CLREQ');
    sessionStorage.setItem('reportData', JSON.stringify(this.data.searchModal));
    this.api.get(this.appConfig.URLS.commonUrl.fundList).subscribe(response => {
      this.fundList = response;
    });
    this.api.get(this.appConfig.URLS.claims.claimtypesList).subscribe(response => {
      this.types = response;
      if (this.types != null) {
        //this.claimtyperadio = this.types["Group Life"];
        let claimTypeList = this.types["Group Life"].concat(this.types['SCI']);        
        let sortedClaimType = claimTypeList.sort(function (a, b) {
          var nameA = a.description.toLowerCase(), nameB = b.description.toLowerCase()
          if (nameA < nameB) //sort string ascending
            return -1
          if (nameA > nameB)
            return 1
          return 0 //default return value (no sorting)
        });
        this.claimtyperadio = sortedClaimType;          
      }
    });
    this.api.get(this.appConfig.URLS.claims.claimstatusList).subscribe(response => {
      this.status = response;
    });

    this.currentSort = 'claimNo';
    this.reportLimit = this.data.searchModal.metaData.reportLimit - this.data.searchModal.metaData.reportOffset;
    this.reportOffset = 0;
    this.pageType = 'status';

    let lim = this.reportLimit;
    let offs = (this.data.searchModal.metaData.reportLimit == 0) ? 20 : this.data.searchModal.metaData.reportLimit;
    let pageindex = (parseInt(offs) / parseInt(lim));
    this.curPageIndex = pageindex;

    let dataSort = this.data.searchModal.metaData;

    this.config = {
      itemsPerPage: this.reportLimit,
      currentPage: this.curPageIndex,
      totalItems: this.metadata.count
    };
    this.gridColumns = [
      {
        columnKey: 'claimNo',
        columnTitle: 'Claim No.',
        currentSort: (dataSort.orderby == 'claimNo') ? true : false,
        order: (dataSort.orderby == 'claimNo') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'firstname',
        columnTitle: 'Member name',
        currentSort: (dataSort.orderby == 'firstname') ? true : false,
        order: (dataSort.orderby == 'firstname') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'fundName',
        columnTitle: 'Fund',
        currentSort: (dataSort.orderby == 'fundName') ? true : false,
        order: (dataSort.orderby == 'fundName') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'claimType',
        columnTitle: 'Claim type',
        currentSort: (dataSort.orderby == 'claimType') ? true : false,
        order: (dataSort.orderby == 'claimType') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'clientReferenceNo',
        columnTitle: 'Client reference No.',
        currentSort: (dataSort.orderby == 'clientReferenceNo') ? true : false,
        order: (dataSort.orderby == 'clientReferenceNo') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'applicationDate',
        columnTitle: 'Claims submitted date',
        currentSort: (dataSort.orderby == 'applicationDate') ? true : false,
        order: (dataSort.orderby == 'applicationDate') ? dataSort.order : 'asc',
        columnWidth: 2
      }
    ];
    if (sessionStorage.getItem('Searched') == 'true') {
      this.filterResults();
    }
  }

  navigateToParent() {
    this.router.navigate(['.'], { relativeTo: this.route.parent });
  }

  onExportReport() {
    this.errorMsg.hideErrorMessage();
    this.claimReportService.exportClaimReports('claimRequirementExport').subscribe(data => {
      if (navigator.appVersion.toString().indexOf('.NET') >= 0) {
        window.navigator.msSaveBlob(data, 'Claims_Requirement_Report.xlsx');
      } else {
        const fileStream = new Blob([data], { type: 'application/octet-stream' });
        const anchorTag = document.createElement('a');
        document.body.appendChild(anchorTag);
        const fileURL = URL.createObjectURL(fileStream);
        anchorTag.href = fileURL;
        anchorTag.download = 'Claims_Requirement_Report.xlsx';
        anchorTag.click();
      }
    }, err => {
      this.errorMsg.showErrorMessage();
    });
  }

  sortResults(sortColumn) {
    for (const column of this.gridColumns) {
      if (column === sortColumn) {
        column.currentSort = true;
      } else {
        column.currentSort = false;
      }
    }
    if (this.data.searchModal.metaData.orderby == sortColumn.columnKey) {
      sortColumn.order = (sortColumn.order == 'asc') ? 'desc' : 'asc';
    }
    else {
      sortColumn.order = 'asc';
    }
    this.curPageIndex = 1;
    this.data.searchModal.metaData.reportOffset = '0';
    this.data.searchModal.metaData.reportLimit = this.reportLimit;
    this.data.searchModal.metaData.orderby = sortColumn.columnKey;
    this.data.searchModal.metaData.order = sortColumn.order;
    this.filterResults();
  }

  toggleFilters() {
    this.showFilter = !this.showFilter;
  }

  canceltoggleFilters() {
    let reportData = Object.assign({}, this.data.resetModel);
    this.searchData = reportData;
  }

  searchfilterResults() {
    let orderKey = this.searchData.metaData.orderby;
    let orderType = this.searchData.metaData.order;
    sessionStorage.setItem('reportName', 'CLREQ');
    sessionStorage.setItem('reportData', JSON.stringify(this.searchData));
    this.searchData.metaData = {
      reportLimit: this.reportLimit,
      reportOffset: '0',
      orderby: orderKey,
      order: orderType
    };
    this.curPageIndex = 1;
    this.data.searchModal = Object.assign({}, this.searchData);
    this.data.searchModal.productType = '';//fix for search
    this.filterResults()
  }

  filterResults() {
    this.errorMsg.hideErrorMessage();
    this.searchData.productType = '';
    
    this.claimReportService.searchReports('requirementReports').subscribe((reportsObj: any) => {
      this.reports = (reportsObj.items) ? reportsObj.items : [];
      this.metadata = (reportsObj.metadata) ? reportsObj.metadata : { count: 0 };
      this.reports.forEach((item, index) => {
        this.reports[index].otherDetails = {};
      });
      if (this.reports) {
        this.showresult = true;
        this.showFilter = false;
        this.searched = true;
        sessionStorage.setItem('Searched', JSON.stringify(this.searched));
        this.config = {
          itemsPerPage: this.reportLimit,
          currentPage: this.curPageIndex,
          totalItems: this.metadata.count
        };
      }
      if (this.reports.length == 0) {
        this.showresult = false;
        this.showFilter = true;
      }
    }, err => {
      this.reports = [];
      this.errorMsg.showErrorMessage();
      this.showresult = false;
      this.showFilter = true;
      this.searched = false;
    });
  }

  pageChanged(event) {
    this.curPageIndex = event;
    this.data.searchModal.metaData.reportOffset =
      ((Number(this.reportLimit) * (this.curPageIndex - 1))).toString();
    // this.data.searchModal.metaData.reportOffset =
    // ((Number(this.data.searchModal.metaData.reportLimit))).toString();
    this.data.searchModal.metaData.reportLimit = Number(this.reportLimit) * (this.curPageIndex);
    this.filterResults();
  }
  onLimitChange(limit: any) {
    if (limit < this.reportLimit) {
      this.scrollToTop();
    }
    this.reportLimit = limit;
    this.curPageIndex = 1;
    this.data.searchModal.metaData.reportOffset = '0';
    this.data.searchModal.metaData.reportLimit = limit;
    this.filterResults();
  }

  onChange(deviceValue) {
    this.claimtyperadio = deviceValue == 'SCI' ? this.types["SCI"] : this.types["Group Life"];
    this.searchData.claimType = '';
  }

  scrollToTop() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  }

  dateRangeOnly(event) {
    if (event.keyCode === 13 || event.keyCode === 32 || event.keyCode === 47 || event.keyCode === 45) {
      return;  // let enter it happen
    }
    const regEx = this.appConfig.appConstants.regEx.dateRangeOnly;
    return event.key.match(regEx) ? true : false;
  }

  onDateRangeChange(event) {
    this.futureDateRange = event.endDate > this.today ? true : false;
    this.startDateRange = event.endDate >= event.startDate ? false : true;

    let externalUser = this.userService.checkExternalUser();
    if (externalUser) {
      let lastYearDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
      this.dateRangeExceeded = event.startDate >= lastYearDate ? false : true;
      this.dateRangeExceededErrorMsg = 'Time period cannot exceed 12 Months from Current Date.';
    } else {
      this.dateRangeExceeded = event.daySpan > this.appConfig.appConstants.maxDateRangeAllowed ? true : false;
      this.dateRangeExceededErrorMsg = 'Time period cannot exceed 1 year';
    }
  }

  isObjectEmpty(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }

  getOtherDetails(reportType, claimNo, index, product) {
    this.errorMsg.hideErrorMessage();
    if (this.isObjectEmpty(this.reports[index].otherDetails)) {
      let detailsURL = this.appConfig.URLS.claims.reportDetails + '/' + reportType + '/' + claimNo + '/' + product;
      this.api.get(detailsURL).subscribe(result => {
        this.reports[index].otherDetails = result;
      }, err => {
        this.errorMsg.showErrorMessage();
      });
    }
  }
}