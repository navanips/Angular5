import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DetailsComponent } from './details.component';
import { AppConfiguration } from '../../../../app-configuration';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FileUploadModule } from 'ng2-file-upload';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { Ng2CompleterModule } from "ng2-completer";
import { CurrencyPipe, DatePipe } from '@angular/common';
import { ClaimSearchModel } from '../../../../service/claim/claim-search-model';
import { ActivatedRoute } from '@angular/router'

describe('DetailsComponent', () => {
  let component: DetailsComponent;
  let fixture: ComponentFixture<DetailsComponent>;
  const route = ({ snapshot:{data:{data: {   
    application:{"amount":null,"assessor":"BIZFLOW USER","benefitPaid":null,"benefitPeriod":null,"claimCause":"Unknown","claimNo":68799,"claimType":"Death Only          ","claimTypeDes":"Death Only          ","disabilityDate":"2019-09-19T00:00","dispatchDate":null,"fromDate":null,"fundCode":"AAMI","fundName":"AAMI","insuredBenefit":null,"lastActionDate":null,"lastPaidDate":null,"monthlyBenefit":null,"percentageSalaryInsured":"0.00","percentageSuperContribution":"0.00","policyNo":"","product":"Group Life","scheme":"AAMI - Life Insurance                                            ","statusCode":"N","statusDescription":"Pending","submittedDate":"2019-09-20T00:00","sumInsured":"3000.00","toDate":null,"waitPeriod":null},event:[{"actualSLA":null,"comments":null,"dateReceived":null,"dateRequested":null,"daysInRequested":null,"description":"","event":"Follow Up 1","eventDate":"2019-10-01T17:11:40.667","requirement":null,"standardSLA":null},{"actualSLA":null,"comments":"Requested requirement for Authorities","dateReceived":null,"dateRequested":null,"daysInRequested":null,"description":"Information Requested","event":"Information Requested","eventDate":"2019-10-01T17:11:38.940","requirement":null,"standardSLA":null},{"actualSLA":null,"comments":null,"dateReceived":null,"dateRequested":null,"daysInRequested":null,"description":"General","event":"Assessment - ongoing","eventDate":"2019-10-01T17:10:40.657","requirement":null,"standardSLA":null},{"actualSLA":null,"comments":null,"dateReceived":null,"dateRequested":null,"daysInRequested":null,"description":"","event":"Follow Up 1","eventDate":"2019-09-26T10:08:59.487","requirement":null,"standardSLA":null}],member:{"clientReferenceNo":"","firstName":"Sxxxxx","surName":"Mxxxx","memberDob":"1996-09-09T00:00","memberGender":"F"},claimStrategy:[],"paymentHistory":[],requirmentHistory:[{"requirement":"Information Requested","description":"Requested requirement for Authorities","requestedDate":"2019-10-01T17:11:38.940","daysSinceRequested":"3"}]
  } } } } as any) as ActivatedRoute

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FormsModule, 
        ReactiveFormsModule, 
        HttpClientTestingModule,
        FileUploadModule,
        Ng2SmartTableModule,
        Ng2CompleterModule
      ],
      declarations: [ DetailsComponent ],
      providers: [
        AppConfiguration,
        CurrencyPipe,
        DatePipe,
        ClaimSearchModel,
        { provide: ActivatedRoute, useValue: route }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
