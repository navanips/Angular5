import { RequirementClaimModule } from './requirement-claim.module';

describe('RequirementClaimModule', () => {
  let requirementClaimModule: RequirementClaimModule;

  beforeEach(() => {
    requirementClaimModule = new RequirementClaimModule();
  });

  it('should create an instance', () => {
    expect(requirementClaimModule).toBeTruthy();
  });
});
