import { ClaimsModule } from './claims.module';

describe('ClaimsReportModule', () => {
  let ClaimsModules: ClaimsModule;

  beforeEach(() => {
    ClaimsModules = new ClaimsModule();
  });

  it('should create an instance', () => {
    expect(ClaimsModules).toBeTruthy();
  });
});
