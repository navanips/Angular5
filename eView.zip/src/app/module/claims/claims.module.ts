import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { FileUploadModule } from 'ng2-file-upload';
import { AlertModule } from 'ngx-bootstrap';

import { ValidateGuard } from '../../guards/validate.guard';
import { CanDeactivateGuard } from '../../guards/can-deactivate.guard';
import { FeatureToggleGuard } from '../../guards/feature-toggle-guard.guard';
import { SubmitClaimsComponent } from './submit-claims/submit-claims.component';
import { CustomDirectiveModule } from '../../directives/custom-directive/custom-directive.module';

const routes: Routes = [
  { path: 'status', loadChildren: './status-claim/status-claim.module#StatusClaimModule', canActivate: [ValidateGuard, FeatureToggleGuard], data: { permissionId: ['eQuery_ClaimsStatusRpt', 'Claims_ClaimsStatusRpt'], featureToggleKey: 'claimStatus' } },
  { path: 'sla', loadChildren: './sla-claim/sla-claim.module#SlaClaimModule', canActivate: [ValidateGuard, FeatureToggleGuard], data: { permissionId: ['eQuery_ClaimsSLARpt', 'Claims_ClaimsSLARpt'], featureToggleKey: 'claimSla' } },
  { path: 'requirement', loadChildren: './requirement-claim/requirement-claim.module#RequirementClaimModule', canActivate: [ValidateGuard, FeatureToggleGuard], data: { permissionId: ['eQuery_ClaimsReqRpt', 'Claims_ClaimsReqRpt'], featureToggleKey: 'claimRequirement' } },
  { path: 'payment', loadChildren: './payment-claim/payment-claim.module#PaymentClaimModule', canActivate: [ValidateGuard, FeatureToggleGuard], data: { permissionId: ['eQuery_ClaimsPaymentRpt', 'Claims_ClaimsPaymentRpt'], featureToggleKey: 'claimPayment' } },
  { path: 'submit-claims', component: SubmitClaimsComponent, canActivate: [ValidateGuard, FeatureToggleGuard], canDeactivate: [CanDeactivateGuard], data: { permissionId: ['eLodgement_SubmitClaim', 'Claims_SubmitNewClaim'], featureToggleKey: 'claimSubmitNew' } },
  { path: 'validateClaim', loadChildren: './validate-claim/validate-claim.module#ValidateClaimModule', canActivate: [ValidateGuard, FeatureToggleGuard], data: { permissionId: ['eClaims_ValidateClaim', 'Claims_ValidateClaim'], featureToggleKey: 'claimValidate' } },
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    DateRangePickerModule,
    DatePickerModule,
    FileUploadModule,
    AlertModule.forRoot(),
    CustomDirectiveModule
  ],
  declarations: [SubmitClaimsComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class ClaimsModule {
  constructor() { }
}