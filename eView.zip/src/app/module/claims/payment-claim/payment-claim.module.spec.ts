import { PaymentClaimModule } from './payment-claim.module';

describe('PaymentClaimModule', () => {
  let paymentClaimModule: PaymentClaimModule;

  beforeEach(() => {
    paymentClaimModule = new PaymentClaimModule();
  });

  it('should create an instance', () => {
    expect(paymentClaimModule).toBeTruthy();
  });
});
