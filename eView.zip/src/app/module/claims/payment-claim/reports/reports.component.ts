import { Component, OnInit, HostListener } from '@angular/core';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConfiguration } from '../../../../app-configuration';
import { PaymentSearchModel } from '../../../../service/claim/payment/payment-search-model';
import { ClaimReportsService } from '../../../../service/claim/claim-reports.service';
import { ClaimSearchService } from '../../../../service/claim/claim-search.service';
import { RestApiService } from '../../../../service/rest-api.service';
import { UserService } from '../../../../service/user/user.service';
import { FlashMessageService } from '../../../../service/flash-message/flash-message.service'
import * as $ from 'jquery';
import * as moment from 'moment';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  showFilter: boolean = true;
  gridColumns: any;
  reports: any = [];
  searchData: any;
  fundList: any;
  types: any;
  status: any;
  currentSort: any;
  reportLimit: any;
  reportOffset: any;
  curPageIndex: any;
  metadata: any = { count: '' };
  pageType: any;
  claimdetail: any;
  claimtyperadio: any;
  userPermissions: any;
  searched: boolean = false;
  showresult: boolean;
  searchError: any;
  public dateRangeExceeded: Boolean;
  public futureDateRange: Boolean;
  public startDateRange: Boolean;
  dateRangeExceededErrorMsg: any;
  submitted = false;
  public today: Date = new Date(new Date().toDateString());
  public dateValue: Date = new Date();
  public weekStart: Date = new Date(new Date().getTime() - (7 * 24 * 60 * 60 * 1000));;
  public weekEnd: Date = this.today;
  public monthStart: Date = new Date(new Date(new Date().setDate(1)).toDateString());
  public monthEnd: Date = this.today;
  public lastStart: Date = new Date(new Date(new Date(new Date().setMonth(new Date().getMonth() - 1)).setDate(1)).toDateString());
  public lastEnd: Date = new Date(new Date().getFullYear(), new Date().getMonth(), 0);
  public yearStart: Date = new Date(new Date().getFullYear(), 0, 1);
  public yearEnd: Date = this.today;
  public format = 'dd/MM/yyyy';
  config: any;
  externalUser:any;

  @HostListener('window:beforeunload') goToPage() {
    sessionStorage.setItem('Searched', JSON.stringify(this.searched));
    sessionStorage.setItem('reportName', 'CLPAYMENT');
    sessionStorage.setItem('reportData', JSON.stringify(this.data.searchModal));
  }

  constructor(private userService: UserService, private flashErrorMsg: FlashMessageService, private route: ActivatedRoute, private router: Router,
    private data: PaymentSearchModel, public claimReportService: ClaimReportsService, private appConfig: AppConfiguration, public claimSearchSvc: ClaimSearchService, private api: RestApiService) {
    let perm = (JSON.parse(sessionStorage.getItem('userDetails')).menus) ? JSON.parse(sessionStorage.getItem('userDetails')).menus : [];
    this.userPermissions = perm.join(',');
    this.data.generateModals();
  }

  ngOnInit() {
    // this.reports = this.route.snapshot.data['reports'].items;
    // this.metadata = this.route.snapshot.data['reports'].metadata;
    this.reports = [];
    this.showresult = false;
    this.externalUser = this.userService.checkExternalUser();
    this.flashErrorMsg.hideErrorMessage();
    if (!sessionStorage.getItem('reportData') && sessionStorage.getItem('reportName') != 'CLPAYMENT') {
      this.data.resetSearchModel();
    }
    this.searchData = Object.assign({}, this.data.searchModal);
    sessionStorage.setItem('reportName', 'CLPAYMENT');
    sessionStorage.setItem('reportData', JSON.stringify(this.data.searchModal));
    // this.fundList = this.claimSearchSvc.getFundsResult();
    // this.types = this.claimSearchSvc.getCliamtypesResult();
    // this.status = this.claimSearchSvc.getClaimstatusResult();
    this.api.get(this.appConfig.URLS.commonUrl.fundList).subscribe(response => {
      this.fundList = response;
    });
    this.api.get(this.appConfig.URLS.claims.claimtypesList).subscribe(response => {
      this.types = response;
      if (this.types != null) {
        this.claimtyperadio = this.types["Group Life"];
      }
    });
    this.api.get(this.appConfig.URLS.claims.claimstatusList).subscribe(response => {
      this.status = response;
    });

    this.currentSort = 'claimNo';
    this.reportLimit = this.data.searchModal.metaData.reportLimit - this.data.searchModal.metaData.reportOffset;
    this.reportOffset = 0;
    this.pageType = 'status';
    // this.showFilter = false;

    let lim = this.reportLimit;
    let offs = (this.data.searchModal.metaData.reportLimit == 0) ? 20 : this.data.searchModal.metaData.reportLimit;
    let pageindex = (parseInt(offs) / parseInt(lim));
    this.curPageIndex = pageindex;

    let dataSort = this.data.searchModal.metaData;

    this.config = {
      itemsPerPage: this.reportLimit,
      currentPage: this.curPageIndex,
      totalItems: this.metadata.count
    };
    this.gridColumns = [
      {
        columnKey: 'claimNo',
        columnTitle: 'Claim No.',
        currentSort: (dataSort.orderby == 'claimNo') ? true : false,
        order: (dataSort.orderby == 'claimNo') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'firstname',
        columnTitle: 'Full name',
        currentSort: (dataSort.orderby == 'firstname') ? true : false,
        order: (dataSort.orderby == 'firstname') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'fundName',
        columnTitle: 'Fund',
        currentSort: (dataSort.orderby == 'fundName') ? true : false,
        order: (dataSort.orderby == 'fundName') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'clientReferenceNo',
        columnTitle: 'Client reference No.',
        currentSort: (dataSort.orderby == 'clientReferenceNo') ? true : false,
        order: (dataSort.orderby == 'clientReferenceNo') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'disabilityDate',
        columnTitle: 'Disability date',
        currentSort: (dataSort.orderby == 'disabilityDate') ? true : false,
        order: (dataSort.orderby == 'disabilityDate') ? dataSort.order : 'asc',
        columnWidth: 2
      },
      {
        columnKey: 'dispatchDate',
        columnTitle: 'Claims submitted date',
        currentSort: (dataSort.orderby == 'dispatchDate') ? true : false,
        order: (dataSort.orderby == 'dispatchDate') ? dataSort.order : 'asc',
        columnWidth: 2
      },
    ];
    if (sessionStorage.getItem('Searched') == 'true') {
      this.filterResults();
    }
  }

  navigateToParent() {
    this.router.navigate(['.'], { relativeTo: this.route.parent });
  }

  onExportReport() {
    this.flashErrorMsg.hideErrorMessage();
    this.claimReportService.exportClaimReports('claimPaymentExport').subscribe(data => {
      if (navigator.appVersion.toString().indexOf('.NET') >= 0) {
        window.navigator.msSaveBlob(data, 'Claims_Payment_Report.xlsx');
      } else {
        const fileStream = new Blob([data], { type: 'application/octet-stream' });
        const anchorTag = document.createElement('a');
        document.body.appendChild(anchorTag);
        const fileURL = URL.createObjectURL(fileStream);
        anchorTag.href = fileURL;
        anchorTag.download = 'Claims_Payment_Report.xlsx';
        anchorTag.click();
      }
    }, err => {
      this.flashErrorMsg.showErrorMessage();
    });
  }

  sortResults(sortColumn) {
    for (const column of this.gridColumns) {
      if (column === sortColumn) {
        column.currentSort = true;
      } else {
        column.currentSort = false;
      }
    }
    if (this.data.searchModal.metaData.orderby == sortColumn.columnKey) {
      sortColumn.order = (sortColumn.order == 'asc') ? 'desc' : 'asc';
    }
    else {
      sortColumn.order = 'asc';
    }
    this.curPageIndex = 1;
    this.data.searchModal.metaData.reportOffset = '0';
    this.data.searchModal.metaData.reportLimit = this.reportLimit;
    this.data.searchModal.metaData.orderby = sortColumn.columnKey;
    this.data.searchModal.metaData.order = sortColumn.order;
    this.filterResults();
  }

  toggleFilters() {
    this.showFilter = !this.showFilter;
  }

  canceltoggleFilters() {
    this.submitted=false;
    let reportData = Object.assign({}, this.data.resetModel);
    this.searchData = reportData;
  }

  searchfilterResults() {
    let orderKey = this.searchData.metaData.orderby;
    let orderType = this.searchData.metaData.order;
    sessionStorage.setItem('reportName', 'CLPAYMENT');
    sessionStorage.setItem('reportData', JSON.stringify(this.searchData));
    this.searchData.metaData = {
      reportLimit: this.reportLimit,
      reportOffset: '0',
      orderby: orderKey,
      order: orderType
    };
    this.curPageIndex = 1;
    this.data.searchModal = Object.assign({}, this.searchData);
    this.filterResults()
  }

  filterResults() {
    this.flashErrorMsg.hideErrorMessage();
    
    this.claimReportService.searchReports('paymentReports').subscribe((reportsObj: any) => {
      this.reports = (reportsObj.items) ? reportsObj.items : [];
      this.metadata = (reportsObj.metadata) ? reportsObj.metadata : { count: 0 };
      if (this.reports) {
        this.showresult = true;
        this.showFilter = false;
        this.searched = true;
        sessionStorage.setItem('Searched', JSON.stringify(this.searched));
        this.config = {
          itemsPerPage: this.reportLimit,
          currentPage: this.curPageIndex,
          totalItems: this.metadata.count
        };
      }
      if (this.reports.length == 0) {
        this.showresult = false;
        this.showFilter = true;
      }
    }, err => {
      this.reports = [];
      this.flashErrorMsg.showErrorMessage();
      this.showresult = false;
      this.showFilter = true;
      this.searched = false;
    });
  }

  isObjectEmpty(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }

  getOtherDetails(reportType, claimNo, index, product) {
    this.flashErrorMsg.hideErrorMessage();
    let startDate = moment(this.searchData.applicationdate[0]).format('YYYY-MM-DD HH:mm:ss');
    let endDate = moment(this.searchData.applicationdate[1]).format('YYYY-MM-DD 23:59:59');
    
    let claimno = this.searchData.claimno;
    let clientReferenceNo = this.searchData.clientReferenceNo;
    let firstname = this.searchData.firstname;
    let surname = this.searchData.surname;
    let memberdob = this.searchData.memberdob;

    if (this.isObjectEmpty(this.reports[index].otherDetails)) {
      let detailsURL;
      if(claimno || clientReferenceNo || firstname || surname || memberdob){
        detailsURL = this.appConfig.URLS.claims.reportDetails + '/' + reportType + '/details/' + claimNo + '/' + product + '?startdate=&enddate=';
      }else{
        detailsURL = this.appConfig.URLS.claims.reportDetails + '/' + reportType + '/details/' + claimNo + '/' + product + '?startdate=' + startDate + '&enddate=' + endDate;
      }      
      this.api.get(detailsURL).subscribe(result => {
        this.reports[index].otherDetails = result;
      }, err => {
        this.flashErrorMsg.showErrorMessage();
      });
    }
  }

  pageChanged(event) {
    this.curPageIndex = event;
    this.data.searchModal.metaData.reportOffset =
      ((Number(this.reportLimit) * (this.curPageIndex - 1))).toString();
    // this.data.searchModal.metaData.reportOffset =
    // ((Number(this.data.searchModal.metaData.reportLimit))).toString();
    this.data.searchModal.metaData.reportLimit = Number(this.reportLimit) * (this.curPageIndex);
    this.filterResults();
  }
  onLimitChange(limit: any) {
    if (limit < this.reportLimit) {
      this.scrollToTop();
    }
    this.reportLimit = limit;
    this.curPageIndex = 1;
    this.data.searchModal.metaData.reportOffset = '0';
    this.data.searchModal.metaData.reportLimit = limit;
    this.filterResults();
  }

  onChange(deviceValue) {
    this.claimtyperadio = deviceValue == 'SCI' ? this.types["SCI"] : this.types["Group Life"];
    this.searchData.claimType = '';
  }

  scrollToTop() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  }

  dateRangeOnly(event) {
    if (event.keyCode === 13 || event.keyCode === 32 || event.keyCode === 47  || event.keyCode === 45) {
      return;  // let enter it happen
    }
    const regEx = this.appConfig.appConstants.regEx.dateRangeOnly;
    return event.key.match(regEx) ? true : false;
  }

  onDateRangeChange(event) {
    this.futureDateRange = event.endDate > this.today ? true : false;
    this.startDateRange = event.endDate >= event.startDate ? false : true;

    let externalUser = this.userService.checkExternalUser();
    if (externalUser) {
      let lastYearDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
      this.dateRangeExceeded = event.startDate >= lastYearDate ? false : true;
      this.dateRangeExceededErrorMsg = 'Time period cannot exceed 12 Months from Current Date.';
    } else {
      // this.dateRangeExceeded = event.daySpan > this.appConfig.appConstants.maxDateRangeAllowed ? true : false;
      // this.dateRangeExceededErrorMsg = 'Time period cannot exceed 1 year';
    }
  }
}
