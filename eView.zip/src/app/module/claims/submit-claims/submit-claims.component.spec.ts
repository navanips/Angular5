import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { SubmitClaimsComponent } from './submit-claims.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { FileUploadModule } from 'ng2-file-upload';
import { AppConfiguration } from '../../../app-configuration';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DebugElement } from '@angular/core';
import { AlertModule } from 'ngx-bootstrap';
import { FlashMessagesService } from 'angular2-flash-messages';

describe('SubmitClaimsComponent', () => {
  let component: SubmitClaimsComponent;
  let fixture: ComponentFixture<SubmitClaimsComponent>;
  let de: DebugElement;
  let el:HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubmitClaimsComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        DateRangePickerModule,
        DatePickerModule,
        FileUploadModule,
        RouterTestingModule,
        HttpClientTestingModule,
        AlertModule
      ],
      providers:[
        AppConfiguration,
        FlashMessagesService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmitClaimsComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('form'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set submitted to true',async(() =>{
    component.formSubmit();
    expect(component.submitted).toBeTruthy();
  }));

  it('should call the formSubmit method',async(() => {
    fixture.detectChanges();
    spyOn(component,'formSubmit');
    el = fixture.debugElement.query(By.css('#submitBtn')).nativeElement;
    el.click();
    expect(component.formSubmit).toHaveBeenCalledTimes(1);
  }));

  it('form should be reset',(() => {
    el = fixture.debugElement.query(By.css('#resetBtn')).nativeElement;
    el.click();
    expect(component.resetForm).toBeTruthy();
  }));
  
  it('form should be valid',(() => {
    component.appInfo.controls['refNo'].setValue('1234');
    component.appInfo.controls['fundPlan'].setValue('4CAB');
    component.appInfo.controls['Title'].setValue('Mr');
    component.appInfo.controls['fName'].setValue('fname');
    component.appInfo.controls['surName'].setValue('lname');
    component.appInfo.controls['dob'].setValue('2019-05-05');
    component.appInfo.controls['dojFund'].setValue('2019-05-05');
    component.coversInfo.controls['deathCover'].setValue(true);
    component.coversInfo.controls['sumInsured'].setValue("1000");
    component.coversInfo.controls['DateOfEvent'].setValue("2019-05-05");

    component.additionalinfo.controls['additionalInfo'].setValue("Additional Info");
    component.additionalinfo.controls['confirmationMail'].setValue(true);

    component.submittedBy.controls['Name'].setValue("Additional Info");
    component.submittedBy.controls['emailId'].setValue('test@test.in');
    component.submittedBy.controls['phNo'].setValue("9876543210");

    expect(component.NewClaims.valid).toBeTruthy();
  }));

  it('alphabhets only',(() => {
    expect(component.appInfo.controls['fName']).not.toContain(Number);
    expect(component.appInfo.controls['surName']).not.toContain(Number);
  }));

  it('form should be Invalid',(() => {
    component.appInfo.controls['refNo'].setValue('');
    component.appInfo.controls['fundPlan'].setValue('');
    component.appInfo.controls['Title'].setValue('');
    component.appInfo.controls['fName'].setValue('');
    component.appInfo.controls['surName'].setValue('');
    component.appInfo.controls['dob'].setValue('');
    
    component.coversInfo.controls['deathCover'].setValue();
    component.coversInfo.controls['sumInsured'].setValue("");
    component.coversInfo.controls['DateOfEvent'].setValue("");

    component.additionalinfo.controls['additionalInfo'].setValue("");
    component.additionalinfo.controls['confirmationMail'].setValue();

    component.submittedBy.controls['Name'].setValue("");
    component.submittedBy.controls['emailId'].setValue('');
    component.submittedBy.controls['phNo'].setValue("");

    expect(component.NewClaims.valid).toBeFalsy();
  }));

});
