import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { AppConfiguration } from '../../../app-configuration';
import { Router } from '@angular/router';
import { RestApiService } from '../../../service/rest-api.service';
import { ClaimConditionService } from '../../../service/claim/claim-condition.service';
import { CustomSpinnerService } from '../../../service/spinner/custom-spinner.service';
import { FileUploader, FileItem, ParsedResponseHeaders, FileUploaderOptions, Headers } from 'ng2-file-upload';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalComponent } from '../../../layout/ngb-modal/ngb-modal.component';
import { FlashMessageService } from '../../../service/flash-message/flash-message.service';
import * as $ from 'jquery';
import * as moment from 'moment';

@Component({
  selector: 'app-submit-claims',
  templateUrl: './submit-claims.component.html',
  styleUrls: ['./submit-claims.component.css']
})
export class SubmitClaimsComponent implements OnInit {

  @ViewChild('fileInput') fileInput: any;
  NewClaims: FormGroup;
  fundDetails: any;
  // categoryList: any;
  docList: any;
  userDetails: any;

  claimCauseData = [];
  claimCondData = [];

  submitted = false;

  HostplusSubmitted = false;
  DC_Cover = false;
  TIC_Cover = false;
  IP_Cover = false;
  TPD_Cover = false;

  uploadBtnShow = [];
  // progress= [];
  postdoc = [];
  fileNames = [];
  browseBtn = [];
  NoReason = [];
  selectedDoc = [];
  selectedDocId = [];
  tableData = [];
  tableDataRef = [];
  public alerts: any[] = [];
  public format = 'dd/MM/yyyy';
  public uploader: FileUploader = new FileUploader({});
  private uploaderOptions: FileUploaderOptions = {};
  deathCoverChecked = false;
  disabilityCoverChecked = false;
  IpCoverChecked = false;
  IllnessCoverChecked = false;
  chekErr = true;
  public today: Date = new Date(new Date().toDateString());
  tooltips = false;
  fileUploadRequest = 0;
  totalRequest = 0;
  successRequest = 0;
  uploadSummary: any = [];
  searchVal = ''
  deathCoverInfo = {
    coverCode: 'DTH',
    insCovercur: '',
    dateOfEvent: '',
    datePremiumStarted: '',
    underWrittenYesorNo: '',
    claimCondition: '',
    claimCause: '',
    sumInsuredClaim: ''
  };
  disabilityCoverInfo = {
    coverCode: 'TPD',
    insCovercur: '',
    dateOfEvent: '',
    datePremiumStarted: '',
    underWrittenYesorNo: '',
    claimCondition: '',
    claimCause: '',
    sumInsuredClaim: ''
  };
  IpCoverInfo = {
    coverCode: 'IPC',
    insCovercur: '',
    dateOfEvent: '',
    datePremiumStarted: '',
    underWrittenYesorNo: '',
    claimCondition: '',
    claimCause: '',
    sumInsuredClaim: ''
  };
  IllnessCoverInfo = {
    coverCode: 'IC',
    insCovercur: '',
    dateOfEvent: '',
    datePremiumStarted: '',
    underWrittenYesorNo: '',
    claimCondition: '',
    claimCause: '',
    sumInsuredClaim: ''
  };
  DTHdup = Object.assign({}, this.deathCoverInfo);
  TPDdup = Object.assign({}, this.disabilityCoverInfo);
  IPCdup = Object.assign({}, this.IpCoverInfo);
  ICdup = Object.assign({}, this.IllnessCoverInfo);
  accountbalanceObj: any = '';
  submitObj = {
    confirmHrs: false,
    fundCode: '',
    fundName:'',
    title: '',
    firstName: '',
    surName: '',
    gender: '',
    clientRefNumber: '',
    dateOfBirth: null,
    dateJoinedCompany: null,
    dateJoinedFund: null,
    additionalInfo: '',
    userName: '',
    submittedEmail: '',
    submittedPhone: '',
    categoryId: '',
    confirmEmailFlag: true,
    memberType: '',
    accountBalance: '',
    lastContributionDate: '',
    employerName: '',

    coversInfo: [],
    documentInfo: [{
      documentLocation: '',
      docType: ''
    }]
  };
  isDirty: boolean = false;
  @HostListener('window:beforeunload', ['$event'])
  doSomething($event) {
    if (this.isDirty) {
      $event.returnValue = 'Changes you made may not be saved.';
    }
  }
  constructor(private claimConditionService:ClaimConditionService, private errorMsg:FlashMessageService,private spin: CustomSpinnerService, private conf: AppConfiguration, private router: Router, private api: RestApiService, private fb: FormBuilder, private ngbModal: NgbModal) {
    this.getFundPlan();
    // this.getCategory();
    this.getDoc();
    this.claimCondgetData('death');
    this.uploaderOptions['url'] = this.conf.serviceBaseUrl + this.conf.URLS.claims.fileUpload;
    this.uploaderOptions['method'] = 'POST';
    this.uploaderOptions['autoUpload'] = false;
    this.uploaderOptions['maxFileSize'] = 50 * 1024 * 1024;
    this.uploaderOptions['allowedMimeType'] = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'image/png', 'image/jpeg', 'image/jpg'];
    this.uploaderOptions['authToken'] = "Bearer " + sessionStorage.getItem('userToken');
    this.uploader.setOptions(this.uploaderOptions);
    this.userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
    if (this.userDetails) {
      this.submitObj.userName = this.userDetails.firstName + ' ' + this.userDetails.lastName;
      this.submitObj.submittedEmail = this.userDetails.email;
      this.submitObj.submittedPhone = this.userDetails.mobile;
    }
  }
  BooleanConverter(value: any) {
    return value;
  }
  canDeactivate(): boolean {
    if (!this.isDirty || (!sessionStorage.getItem('userToken') && !sessionStorage.getItem('userDetails'))) return true;
    else {
      let ngbModalOptions: NgbModalOptions = {
        backdrop: 'static',
        keyboard: false
      };
      const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
      let docloc = this.submitObj.documentInfo.map(value => value.documentLocation).join(',');
      m.componentInstance.Title = 'Leave site?';
      m.componentInstance.confMessage = 'Changes you made may not be saved.';
      let res = this.BooleanConverter(m.result);
      res.then((userResponse) => {
        if (userResponse === true && docloc) {
          this.delUploaded(docloc);
        }
      });
      return res;
    }
  }
  ngOnInit() {
    this.errorMsg.hideErrorMessage();
    this.NewClaims = this.fb.group({
      appInfo: this.fb.group({
        refNo: new FormControl('', [Validators.required]),
        fundPlan: new FormControl('', [Validators.required]),
        // appCategory: new FormControl('',[Validators.required]),
        Title: new FormControl('', [Validators.required]),
        fName: new FormControl('', [Validators.required]),
        surName: new FormControl('', [Validators.required]),
        dob: new FormControl('', [Validators.required]),
        dojFund: new FormControl('', [Validators.required]),
        dojCompany: new FormControl(''),
        accountbalance: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.fundPlan.value == 'HOST', Validators.required),
        ])),
        dateofContribution: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.fundPlan.value == 'HOST', Validators.required),
        ])),
        memberType: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.fundPlan.value == 'HOST', Validators.required),
        ])),
        NameDOI: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.memberType.value == 'Executive', Validators.required),
        ])),
      }),
      coversInfo: this.fb.group({
        deathCover: new FormControl(''),
        disabilityCover: new FormControl(''),
        incomeProtectionCover: new FormControl(''),
        totalIllness: new FormControl(''),
        sumInsured: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.deathCover.value == true, Validators.required),
        ])),
        DateOfEvent: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.deathCover.value == true, Validators.required),
        ])),
        ClaimConditions: new FormControl(''),
        ClaimCauses: new FormControl(''),
        Underwritten: new FormControl(''),
        DateOfPremium: new FormControl(''),
        NoReasonDC: new FormControl(''),

        sumInsured_TIC: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.totalIllness.value == true, Validators.required),
        ])),
        DateOfEvent_TIC: new FormControl(''),
        ClaimConditions_TIC: new FormControl(''),
        ClaimCauses_TIC: new FormControl(''),
        Underwritten_TIC: new FormControl(''),
        DateOfPremium_TIC: new FormControl(''),
        NoReasonTIC: new FormControl(''),

        sumInsured_IP: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.incomeProtectionCover.value == true, Validators.required),
        ])),
        DateOfEvent_IP: new FormControl(''),
        ClaimConditions_IP: new FormControl(''),
        ClaimCauses_IP: new FormControl(''),
        Underwritten_IP: new FormControl(''),
        DateOfPremium_IP: new FormControl(''),
        NoReasonIP: new FormControl(''),

        sumInsured_DIS: new FormControl('', Validators.compose([
          this.conditional(group => group.controls.disabilityCover.value == true, Validators.required),
        ])),
        DateOfEvent_DIS: new FormControl(''),
        ClaimConditions_DIS: new FormControl(''),
        ClaimCauses_DIS: new FormControl(''),
        Underwritten_DIS: new FormControl(''),
        DateOfPremium_DIS: new FormControl(''),
        NoReasonDIS: new FormControl(''),
      }),
      documentInfo: this.fb.group({}),
      additionalinfo: this.fb.group({
        additionalInfo: new FormControl(''),
        confirmationMail: new FormControl(true),
      }),
      submittedBy: this.fb.group({
        Name: new FormControl(''),
        emailId: new FormControl('', Validators.compose([
          this.conditional(group => this.additionalinfo.controls.confirmationMail.value == true, Validators.required), Validators.pattern(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)
        ])),
        phNo: new FormControl(''),
      })
    });
    this.onChanges();
    this.uploader.onWhenAddingFileFailed = (item, filter) => {
      if (filter.name == 'fileSize') {
        this.uploadSummary = [];
        this.uploadSummary.push({
          status: 'error',
          fileName: '',
          message: 'File size exceeds the maximum of 50 MB per file.You can upload mutiple files if required.',
        });
      }
      if (filter.name == 'mimeType') {
        this.uploadSummary = [];
        this.uploadSummary.push({
          status: 'error',
          fileName: '',
          message: 'The selected file type is not a valid file type. The following file formats only are supported *.pdf, *.doc, *.docx, *.xls, *.xlsx, *.csv, *.jpg, *.jpeg, *.png',
        });
      }
    };
  }
  ngAfterViewInit() {
    this.uploader.onAfterAddingFile = (item => {
      item.withCredentials = false;
    });
  }

  onChanges() {
    this.NewClaims.valueChanges.subscribe(form => {
      if (this.NewClaims.dirty) {
        this.isDirty = true;
      }
    });
  }

  get f() { return this.NewClaims.controls; }

  get appInfo(): any { return this.NewClaims.get('appInfo'); }

  get coversInfo(): any { return this.NewClaims.get('coversInfo'); }

  get documentInfo(): any { return this.NewClaims.get('documentInfo'); }

  get additionalinfo(): any { return this.NewClaims.get('additionalinfo'); }

  get submittedBy(): any { return this.NewClaims.get('submittedBy'); }

  conditional(conditional, validator) {
    return function (control) {
      if (control && control._parent) {
        if (conditional(control._parent)) {
          return validator(control);
        }
      }
    };
  }
  checkMember(event) {
    if (event.target.value == 'Executive') {
      if (!this.appInfo.controls['NameDOI'].value) {
        this.appInfo.controls['NameDOI'].setErrors({ 'required': true });
      }
    } else {
      this.appInfo.controls['NameDOI'].setErrors(null);
    }
  }
  getFundPlan() {
    this.api.get(this.conf.URLS.commonUrl.fundList).subscribe(result => {
      this.fundDetails = result;
    });
  }
  // getCategory()
  // {
  //   this.api.get(this.conf.URLS.commonUrl.categoryList).subscribe(result => {
  //     this.categoryList = result;
  //   });    
  // }
  getDoc() {
    this.api.get(this.conf.URLS.claims.documentList).subscribe(result => {
      this.docList = result;
    });
  }
  delUploaded(docloc) {
    this.api.add(this.conf.URLS.fileUrl.deleteFile + '?filepath=' + docloc, '').subscribe(data => {
      return true;
    });
  }
  claimCondgetData(val) {
    this.api.get(this.conf.URLS.claims.claimCondition).subscribe(result => {
      this.claimCondData[val] = result;
      this.claimCondData['disability'] = result;
      this.claimCondData['illness'] = result;
      this.claimCondData['income'] = result;
      // if(this.claimCondData[val].length ==0){
      //   let claimConditionData = this.claimConditionService.getClaimConditionData();
      //   this.claimCondData['death'] = claimConditionData;
      //   this.claimCondData['disability'] = claimConditionData;
      //   this.claimCondData['illness'] = claimConditionData;
      //   this.claimCondData['income'] = claimConditionData;
      // }
    },err => {
      // let claimConditionData = this.claimConditionService.getClaimConditionData();
      // this.claimCondData['death'] = claimConditionData;
      // this.claimCondData['disability'] = claimConditionData;
      // this.claimCondData['illness'] = claimConditionData;
      // this.claimCondData['income'] = claimConditionData;
    });
  }
  claimCausegetData(event, val) {
    let selectedIndex: number = event.target["selectedIndex"];
    let id = event.target.options[selectedIndex].getAttribute("data-condId")
    if (event.target.value != '' && selectedIndex) {
      this.api.get(this.conf.URLS.claims.claimCause + '/' + id).subscribe(result => {
        this.claimCauseData[val] = result;
        // if(this.claimCauseData[val].length == 0){
        //   let claimCauseData = this.claimConditionService.getClaimCauseData(id);
        //   this.claimCauseData[val] = claimCauseData;
        // }
      },err => {
        //let claimCauseData = this.claimConditionService.getClaimCauseData(id);
        //this.claimCauseData[val] = claimCauseData;
      });
    }
    else this.claimCauseData[val] = [];
  }
  resetForm(val) {    
    if (val == 1) {
      let docloc = this.submitObj.documentInfo.map(value => value.documentLocation).join(',');
      if (docloc) {
        this.delUploaded(docloc);
      }
    }
    this.tableData = [];
    this.tableDataRef = [];
    this.selectedDoc = [];
    this.selectedDocId = [];
    this.uploadSummary = [];
    this.searchVal = '';
    this.NewClaims.reset();
    this.uploader.queue = [];
    this.postdoc = [];
    this.fileNames = [];
    this.uploadBtnShow = [];
    this.browseBtn = [];
    this.NoReason = [];
    // this.progress.fill(0);
    this.submitObj.documentInfo = [];
    this.submitObj.coversInfo = [];
    this.submitted = false;
    this.HostplusSubmitted = false;
    this.DC_Cover = false;
    this.TIC_Cover = false;
    this.IP_Cover = false;
    this.TPD_Cover = false;    
    // this.chekErr = false;
    $('#SnoDiv1,#SnoDiv3,#SnoDiv5,#SnoDiv7').children('button').removeClass('btn btn-lg btn-primary active').addClass('btn btn-lg btn-default');
    $('#filterSearch').val('');
    this.deathCoverChecked = false;
    this.disabilityCoverChecked = false;
    this.IpCoverChecked = false;
    this.IllnessCoverChecked = false;
    this.appInfo.patchValue({ fundPlan: '', Title: '' });
    this.coversInfo.patchValue({ ClaimConditions: '', ClaimCauses: '', ClaimConditions_TIC: '', ClaimCauses_TIC: '', ClaimConditions_IP: '', ClaimCauses_IP: '', ClaimConditions_DIS: '', ClaimCauses_DIS: '' });
    $('#collapseThree :checkbox:enabled').prop('checked', false);
    this.deathCoverInfo = Object.assign({}, this.DTHdup);
    this.disabilityCoverInfo = Object.assign({}, this.TPDdup);
    this.IpCoverInfo = Object.assign({}, this.IPCdup);
    this.IllnessCoverInfo = Object.assign({}, this.ICdup);
    this.submittedBy.patchValue({
      Name: this.userDetails.firstName + ' ' + this.userDetails.lastName,
      emailId: this.userDetails.email,
      phNo: this.userDetails.mobile
    });
    this.submitObj.confirmHrs = false;
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
    $('#genderDiv button').removeClass('btn btn-lg btn-primary active').addClass('btn btn-lg btn-default');
    this.submitObj.gender = '';
    this.submitObj.fundName = '';
    let eventChecked = { target: { checked: true } };
    this.additionalinfo.controls['confirmationMail'].setValue(true);
    this.checkErr(eventChecked)
  }

  removeTableData(data, i) {
    let ind = this.tableDataRef.findIndex(x => x.documentTypeID == data.documentTypeID && x.Id == data.Id);
    // this.selectedDoc.push(data); 
    this.tableData = this.tableData.filter(x => (x.Id != data.Id));
    this.uploader.queue.splice(ind, 1);
    this.tableDataRef = this.tableDataRef.filter(x => (x.Id != data.Id));
  }
  onFileSelected(input) {
    let fName = [];
    if (this.fileInput.nativeElement.value) {
      fName = this.fileInput.nativeElement.value.split("\\")
    }
    let ext = fName[fName.length - 1].split('.');
    let arrExt = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'png', 'jpg', 'jpeg']
    if(arrExt.indexOf(ext[ext.length-1].toLowerCase()) == -1) {
      //this.uploader.queue.splice(this.uploader.queue.length-1,1);
      this.selectedDoc = [];
      this.selectedDocId = [];
      this.uploadSummary = [];
      this.uploadSummary.push({
        status: 'error',
        fileName: '',
        message: 'The selected file type is not a valid file type. The following file formats only are supported *.pdf, *.doc, *.docx, *.xls, *.xlsx, *.csv, *.jpg, *.jpeg, *.png',
      });
    }    
    let validDoc = []; let inValid = [];
    for (let i = 0; i < this.selectedDoc.length; i++) {
      const fileBrowser = this.fileInput.nativeElement;
      if (i > 0) {
        this.uploader.addToQueue(fileBrowser.files);
      }
      if (this.uploader._mimeTypeFilter(input.target.files[0]) && this.uploader._fileSizeFilter(input.target.files[0])) {
        this.uploadSummary = [];
        let uniqId = Math.round((Math.pow(36, 10 + 1) - Math.random() * Math.pow(36, 10))).toString(36).slice(1);
        this.tableData.push({
          Id: uniqId,
          docType: this.selectedDoc[i].docType,
          documentTypeID: this.selectedDoc[i].documentTypeID,
          documentTypeName: this.selectedDoc[i].documentTypeName,
          fileName: fName[fName.length - 1],
          delete: (this.selectedDoc[i].delete == false) ? false : true
        });
        this.tableDataRef.push({
          Id: uniqId,
          docType: this.selectedDoc[i].docType,
          documentTypeID: this.selectedDoc[i].documentTypeID,
          documentTypeName: this.selectedDoc[i].documentTypeName,
          fileName: fName[fName.length - 1],
          delete: (this.selectedDoc[i].delete == false) ? false : true
        });
        validDoc.push(this.selectedDoc[i])
      } else {
        inValid.push(this.selectedDoc[i])
      }
    }
    //  this.selectedDoc = inValid;
    this.selectedDoc = [];
    this.selectedDocId = [];
  }
  upload() {
    if (this.uploader.queue.length > 0) {
      this.spin.show();
      this.totalRequest = 0;
      this.successRequest = 0;
      this.uploadSummary = [];
      this.uploader.queue.forEach((currentItem, index) => {
        this.fileUploadRequest++;
        this.totalRequest++;
        if (this.tableDataRef.length > index) {
          currentItem.url = this.conf.serviceBaseUrl + this.conf.URLS.claims.fileUpload + '?docType=' + this.tableDataRef[index].documentTypeName;
        }
      });
      this.uploader.onBuildItemForm = (item, form) => {
        form.append('Type', item.alias);
        form.append('Key', item._file);
        form.append('multipart', item.file);
      };
      let ss = this.uploader.uploadAll();
      this.uploader.onErrorItem = (item, response, status, headers) => this.onErrorItem(item, response, status, headers);
      this.uploader.onSuccessItem = (item, response, status, headers) => this.onSuccessItem(item, response, status, headers);
      this.uploader.onCompleteAll = () => {
        this.spin.hide();
        if (this.successRequest === this.totalRequest) {
          this.onSubmit();
        }
      };
    }
  }

  onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    let ind = this.uploader.getIndexOfItem(item);
    this.uploader.removeFromQueue(item);
    let suc = JSON.parse(response);
    this.tableData.filter(x => (x.Id == this.tableDataRef[ind].Id) ? x.delete = false : '');
    this.tableDataRef.splice(ind, 1);
    this.uploadSummary.push({
      status: 'success',
      fileName: item.file.name,
      message: 'Document uploaded successfully',
    });
    this.successRequest++;
    this.fileUploadRequest--;
    let obj = {
      documentLocation: suc.filePath,
      docType: suc.fileType
    }
    this.postdoc.push(obj);
    this.submitObj.documentInfo = this.postdoc;
    if (this.fileUploadRequest == 0) {
      this.spin.hide();
    }
  }

  onErrorItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    let ind = this.uploader.getIndexOfItem(item);
    this.uploader.removeFromQueue(item);
    
    // this.selectedDoc.push(this.tableDataRef[ind]); 
    this.tableData = this.tableData.filter(x => x.Id != this.tableDataRef[ind].Id);
    this.tableDataRef.splice(ind, 1);
    
    this.fileUploadRequest--;
    if (this.fileUploadRequest == 0) {
      this.spin.hide();
    }
    if(response){
      let suc = JSON.parse(response);
      this.uploadSummary.push({
        status: 'error',
        fileName: item.file.name,
        message: suc.message,
      });
    }else{
      this.uploadSummary.push({
        status: 'error',
        fileName: item.file.name,
        message: 'An unexpected error has occurred. Please try again.',
      });
    }
    
  }

  changeDateFormat(val) {
    return val ? moment(new Date(val)).format('YYYY-MM-DD') : null;
  }

  removeEmptyKeys(Obj) {
    var clone = Object.assign({}, Obj);
    Object.keys(clone).forEach((key) => {
      if (clone[key] == '' || clone[key] == null || !clone[key]) {
        delete clone[key];
      }
      if (clone[key] !== '' && clone[key] !== null && clone[key] && clone[key].indexOf(',') > -1) {
        clone[key] = clone[key].replace(/(,)/g, '')
      }
    });
    if (Object.keys(clone).length > 1) this.submitObj.coversInfo.push(clone);
  }

  formSubmit() {    console.log(this.deathCoverInfo)
    this.submitted = true;
    if(this.submitObj.fundCode=='HOST') { this.HostplusSubmitted = true; }
    if(this.deathCoverChecked) { this.DC_Cover = true; }
    if(this.IllnessCoverChecked) { this.TIC_Cover = true; }
    if(this.IpCoverChecked) { this.IP_Cover = true; }
    if(this.disabilityCoverChecked) { this.TPD_Cover = true; }    
    this.submitObj.dateOfBirth = this.changeDateFormat(this.appInfo.value.dob);
    this.submitObj.dateJoinedFund = this.changeDateFormat(this.appInfo.value.dojFund);
    this.submitObj.dateJoinedCompany = this.changeDateFormat(this.appInfo.value.dojCompany);

    this.submitObj.lastContributionDate = this.changeDateFormat(this.appInfo.value.dateofContribution);

    this.deathCoverInfo.dateOfEvent = this.changeDateFormat(this.coversInfo.value.DateOfEvent);
    this.deathCoverInfo.datePremiumStarted = this.changeDateFormat(this.coversInfo.value.DateOfPremium);

    this.IllnessCoverInfo.dateOfEvent = this.changeDateFormat(this.coversInfo.value.DateOfEvent_TIC);
    this.IllnessCoverInfo.datePremiumStarted = this.changeDateFormat(this.coversInfo.value.DateOfPremium_TIC);

    this.IpCoverInfo.dateOfEvent = this.changeDateFormat(this.coversInfo.value.DateOfEvent_IP);
    this.IpCoverInfo.datePremiumStarted = this.changeDateFormat(this.coversInfo.value.DateOfPremium_IP);

    this.disabilityCoverInfo.dateOfEvent = this.changeDateFormat(this.coversInfo.value.DateOfEvent_DIS);
    this.disabilityCoverInfo.datePremiumStarted = this.changeDateFormat(this.coversInfo.value.DateOfPremium_DIS);

    this.submitObj.coversInfo = [];
    if (this.deathCoverChecked) {
      this.removeEmptyKeys(this.deathCoverInfo);
    }
    if (this.disabilityCoverChecked) {
      this.removeEmptyKeys(this.disabilityCoverInfo);
    }
    if (this.IpCoverChecked) {
      this.removeEmptyKeys(this.IpCoverInfo);
    }
    if (this.IllnessCoverChecked) {
      this.removeEmptyKeys(this.IllnessCoverInfo);
    }
    if (this.accountbalanceObj) {
      this.submitObj.accountBalance = this.accountbalanceObj.replace(/(,)/g, '');
    }

    let checkedVal = false;
    if (this.disabilityCoverChecked == true && !this.disabilityCoverInfo.insCovercur) checkedVal = true;
    if (this.IpCoverChecked == true && !this.IpCoverInfo.insCovercur) checkedVal = true;
    if (this.IllnessCoverChecked == true && !this.IllnessCoverInfo.insCovercur) checkedVal = true;
    if (this.deathCoverChecked == true && !this.deathCoverInfo.insCovercur) checkedVal = true;

    if (!this.appInfo.valid) $('#collapseOne').addClass('show');
    if (this.deathCoverChecked == false && this.disabilityCoverChecked == false
      && this.IpCoverChecked == false && this.IllnessCoverChecked == false) $('#collapseTwo').addClass('show');
    if (this.tableData.length == 0) $('#collapseThree').addClass('show');

    if (this.NewClaims.valid && (this.deathCoverChecked == true || this.disabilityCoverChecked == true || this.IpCoverChecked == true || this.IllnessCoverChecked == true) && this.submitObj.gender != '' && checkedVal == false) {
      if (this.uploader.queue.length > 0) {
        this.upload();
      } else {
        this.onSubmit();
      }
    } else {
      setTimeout(() => {
        this.enableFocusForError();
      }, 500);
    }
  }

  onSubmit() {
    this.errorMsg.hideErrorMessage();    
    if (this.submitObj.documentInfo.length > 0 && this.submitObj.documentInfo[0].documentLocation != '') {
      let CheckObj = {
        firstName: this.submitObj.firstName,
        surName: this.submitObj.surName,
        dateOfBirth: this.submitObj.dateOfBirth,
        applicationType: "NewCLAIM"
      }

      this.api.checkLodgement(this.conf.URLS.commonUrl.lodgementcheck, CheckObj).subscribe(result => {
        if (result == 'false' || result == false) {
          this.actualSubmit();
        } else {

          let ngbModalOptions: NgbModalOptions = {
            backdrop: 'static',
            keyboard: false
          };
          const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
          m.componentInstance.Title = 'Confirmation!';
          m.componentInstance.confMessage = 'An application with the same First Name, Surname and DOB has been previously submitted within the last 72 hours, are you sure you want to submit?';
          let res = this.BooleanConverter(m.result);
          res.then((userResponse) => {
            if (userResponse == true) {
              this.submitObj.confirmHrs = true;
              this.actualSubmit();
            }
          });
        }
      },err => {
        this.errorMsg.showErrorMessage();
      })

    } else {
      setTimeout(() => {
        this.enableFocusForError();
      }, 500);
    }
  }

  enableFocusForError() {    
    var firstErrorElement = $('.error_div div.text-danger').eq(0);
    var claimTypeError = $('.claimTypeError');
    var fileUploadError = $('.fileUploadError');
    if (firstErrorElement.length) {
      var select = $('.error_div div.text-danger').eq(0).parent('.error_div').find('select');
      var input = $('.error_div div.text-danger').eq(0).parent('.error_div').find('input');
      var button = $('.error_div div.text-danger').eq(0).parent('.error_div').find('button');
      if (select.length > 0) {
        $('.error_div div.text-danger').eq(0).parent('.error_div').find('select').focus();
      }
      if (input.length > 0) {
        $('.error_div div.text-danger').eq(0).parent('.error_div').find('input').focus();
      }
      if (button.length > 0) {
        $('.error_div div.text-danger').eq(0).parent('.error_div').find('button').eq(0).focus();
      }
    } else if (claimTypeError.length == 1) {
      $('.claim-info').eq(0).find('input').focus();
    } else if (fileUploadError.length == 1) {
      $('#filterSearch').focus();
    }
  }

  actualSubmit() {
    this.errorMsg.hideErrorMessage();
    this.api.add(this.conf.URLS.claims.addClaims, this.submitObj).subscribe(result => {
      if (result) {
        this.isDirty = false;
        this.resetForm(2);
        $('#submittedModal').show();
      } else {
        this.errorMsg.showErrorMessage();
      }
    },
      err => {
        this.errorMsg.showErrorMessage();
      })
  }

  changeClass($event, id1, id2, id3) {
    // event.preventDefault();
    if (id2 == 'genderDiv') this.submitObj.gender = id1;
    $('#' + id2 + ' button').attr('class', 'btn btn-lg btn-default');
    document.getElementById(id1).className = 'btn btn-lg btn-primary active';

    if (id3 && id1.indexOf('Nobtn') > -1) { this.NoReason[id3] = true; }
    else if (id3) this.NoReason[id3] = false;

    if (id2 == 'adinfodiv' && id1 == 'adinfobtn1' && this.submitObj.additionalInfo == '') this.additionalinfo.controls['additionalInfo'].setErrors({ 'required': true });
    else if (id2 == 'adinfodiv') this.additionalinfo.controls['additionalInfo'].setErrors(null);
  }
  checkErr(event) {
    if (event.target.checked == false) {
      if (this.submittedBy.controls['emailId'].getError('required')) {
        this.submittedBy.controls['emailId'].setErrors(null);
      }
      this.chekErr = false;
    }
    if (event.target.checked == true) {
      if (this.submittedBy.controls['emailId'].value == null || this.submittedBy.controls['emailId'].value == '') {
        this.submittedBy.controls['emailId'].setErrors({ 'required': true });
      }
      this.chekErr = true;

    }
  }
  CoverChecked(event, val) {
    if (val === 'death') {
    this.deathCoverChecked = event.target.checked;
      if (event.target.checked === false) {
        this.coversInfo.controls['sumInsured'].setErrors(null);
        this.coversInfo.controls['sumInsured'].reset();
        this.coversInfo.controls['DateOfEvent'].setErrors(null);
        this.coversInfo.controls['DateOfEvent'].reset();
        this.coversInfo.patchValue({ ClaimConditions: '', ClaimCauses: '', DateOfPremium: '' });
        this.deathCoverInfo.insCovercur = '';
        this.deathCoverInfo.underWrittenYesorNo = '';
        this.NoReason['DC'] = false;
      }
    }
    if (val === 'disability') {
    this.disabilityCoverChecked = event.target.checked;
      if (event.target.checked === false) {
        this.coversInfo.controls['sumInsured_DIS'].setErrors(null);
        this.coversInfo.controls['sumInsured_DIS'].reset();
        this.coversInfo.controls['DateOfEvent_DIS'].reset();
        this.coversInfo.patchValue({ ClaimConditions_DIS: '', ClaimCauses_DIS: '', DateOfPremium_DIS: '' });
        this.disabilityCoverInfo.insCovercur = '';
        this.disabilityCoverInfo.underWrittenYesorNo = '';
        this.NoReason['DIS'] = false;
      }
    }
    if (val === 'income') {
    this.IpCoverChecked = event.target.checked;
      if (event.target.checked === false) {
        this.coversInfo.controls['sumInsured_IP'].setErrors(null);
        this.coversInfo.controls['sumInsured_IP'].reset();
        this.coversInfo.controls['DateOfEvent_IP'].reset();
        this.coversInfo.patchValue({ ClaimConditions_IP: '', ClaimCauses_IP: '', DateOfPremium_IP: '' });
        this.IpCoverInfo.insCovercur = '';
        this.IpCoverInfo.underWrittenYesorNo = '';
        this.NoReason['IP'] = false;
      }
    }
    if (val === 'illness') {
    this.IllnessCoverChecked = event.target.checked;
      if (event.target.checked === false) {
        this.coversInfo.controls['sumInsured_TIC'].setErrors(null);
        this.coversInfo.controls['sumInsured_TIC'].reset();
        this.coversInfo.controls['DateOfEvent_TIC'].reset();
        this.coversInfo.patchValue({ ClaimConditions_TIC: '', ClaimCauses_TIC: '', DateOfPremium_TIC: '' });
        this.IllnessCoverInfo.insCovercur = '';
        this.IllnessCoverInfo.underWrittenYesorNo = '';
        this.NoReason['TIC'] = false;
      }
    }
  }

  fixPos(event, val) {
    if (event.target.value != '') {
      let value = event.target.value.replace(/(,)/g, '')
      if (value.length > 18) {
        value = value.substr(0, 18);
      }
      value = Number(value).toFixed(2);
      let amount = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
      if ((amount == NaN) || (amount == 'nan') || (amount == 'NaN')) {
        event.target.value = '';
      }
      else {
        event.target.value = amount;
        if (val == 1) { this.deathCoverInfo.sumInsuredClaim = amount; }
        else if (val == 2) { this.IllnessCoverInfo.sumInsuredClaim = amount; }
        else if (val == 3) { this.IpCoverInfo.sumInsuredClaim = amount; }
        else if (val == 4) { this.disabilityCoverInfo.sumInsuredClaim = amount; }
        else if (val == 5) { this.accountbalanceObj = amount; }
      }
    }
  }

  numberOnly(event, type, maxLength): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (type === '2' && charCode === 46 && event.target.value.split('.').length === 2) { return false; }
    if (type === '2' && charCode > 31 && (charCode < 46 || charCode === 47 || charCode > 57)) {
      return false;
    } else if (type === '1' && charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    if (event.target.value.length >= maxLength) {
      return false;
    }
    return true;
  }

  changeFund(event) {
    if (event.target.value == 'HOST') {
      this.submitObj.memberType = '';
      if (!this.appInfo.controls['dateofContribution'].value) {
        this.appInfo.controls['dateofContribution'].setErrors({ 'required': true });
      }
      if (!this.appInfo.controls['accountbalance'].value) {
        this.appInfo.controls['accountbalance'].setErrors({ 'required': true });
      }
      if (!this.appInfo.controls['NameDOI'].value || this.appInfo.controls['NameDOI'].value == '') {
        this.appInfo.controls['NameDOI'].setErrors({ 'required': true });
      }
      if (!this.appInfo.controls['memberType'].value || this.appInfo.controls['memberType'].value == '') {
        this.appInfo.controls['memberType'].setErrors({ 'required': true });
      }
    }
    else {
      this.submitObj.memberType = '';
      this.appInfo.controls['dateofContribution'].setErrors(null);
      this.appInfo.controls['accountbalance'].setErrors(null);
      this.appInfo.controls['NameDOI'].setErrors(null);
      this.appInfo.controls['memberType'].setErrors(null);
      this.submitObj.accountBalance = '';
      this.accountbalanceObj = '';
      this.NewClaims.patchValue({
        appInfo : {
          accountbalance : '',
          NameDOI : '',
          dateofContribution : ''
        }
      });      
    }
  }
  changeValidation(val, name) {
    if (this.appInfo.controls['fundPlan'].value == 'HOST' && (val == '' || val == undefined || val == null)) {
      this.appInfo.controls[name].setErrors({ 'required': true });
    }
    else {
      this.appInfo.controls[name].setErrors(null);
    }
  }
  hideModal() {
    this.isDirty = false;
    $('#submittedModal').hide();
    $('html, body').animate({ scrollTop: $('#selectfundplan').position().top }, 'slow');
  }

  //Design Change functionality
  filterSearch(event) {
    this.searchVal = event.target.value;
  }
  movetoRight(id) {
    this.selectedDocId.push(id.documentTypeID);
    this.selectedDoc.push(id);
  }
  movetoLeft(id) {
    this.selectedDocId.splice(this.selectedDocId.indexOf(id.documentTypeID), 1);
    this.selectedDoc = this.selectedDoc.filter(x => x.documentTypeID != id.documentTypeID);
  }
  dateRangeOnly(event) {
    if (event.keyCode === 47) {
      return;  // let divide allow
    }    
    const regEx = this.conf.appConstants.regEx.dateRangeOnly;
    return event.key.match(regEx) ? true : false;
  }
}