import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { NgxPaginationModule } from 'ngx-pagination';
import { ValidateGuard } from '../../../guards/validate.guard';

import { ReplacePipe } from './replace.pipe';
import { ReportsComponent } from './reports/reports.component';
import { CustomDirectiveModule } from '../../../directives/custom-directive/custom-directive.module';

const routes: Routes = [
  {
    path: '', component: ReportsComponent, canActivate: [ValidateGuard],
    data: {
      reportURL: 'slaReports',
      permissionId: ['eQuery_ClaimsSLARpt', 'Claims_ClaimsSLARpt']
    }
  },
  {
    path: 'reports', component: ReportsComponent, canActivate: [ValidateGuard],
    data: {
      reportURL: 'slaReports',
      permissionId: ['eQuery_ClaimsSLARpt', 'Claims_ClaimsSLARpt']
    }
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(routes),
    DateRangePickerModule,
    DatePickerModule,
    NgxPaginationModule,
    CustomDirectiveModule
  ],
  declarations: [ReportsComponent, ReplacePipe],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class SlaClaimModule { }