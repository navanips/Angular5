import { SlaClaimModule } from './sla-claim.module';

describe('SlaClaimModule', () => {
  let slaClaimModule: SlaClaimModule;

  beforeEach(() => {
    slaClaimModule = new SlaClaimModule();
  });

  it('should create an instance', () => {
    expect(slaClaimModule).toBeTruthy();
  });
});
