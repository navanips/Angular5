import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormBuilder, FormArray } from '@angular/forms';
import { AppConfiguration } from '../../../../app-configuration';
import { RestApiService } from '../../../../service/rest-api.service';
import { FlashMessageService } from '../../../../service/flash-message/flash-message.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-update-app-edit',
  templateUrl: './update-app-edit.component.html',
  styleUrls: ['./update-app-edit.component.css']
})
export class UpdateAppEditComponent implements OnInit {

  public alerts: any[] = [];
  updateApps: FormGroup;
  arrayItems = [];
  submitted = false;
  updateAppList: any;
  editID : any;
  
  constructor(private route: ActivatedRoute, private errorMsg:FlashMessageService, private router: Router, private conf: AppConfiguration, private api: RestApiService, private fb: FormBuilder) { 
    
  }

  ngOnInit() {
    this.editID = this.route.snapshot.paramMap.get('id'); 
    this.updateApps = this.fb.group({
      applicationName: new FormControl('', [Validators.required]),
      modules: this.fb.array([])
    });
    this.getList();
  }

  getList() {
    this.api.get(this.conf.URLS.UpdateApp.List+'/'+this.editID).subscribe(response => {
      this.updateAppList = response;
      this.updateApps.controls['applicationName'].setValue(this.updateAppList.applicationName)
      var ref = this;
      this.updateAppList.modules.forEach(val => {
        if(val.comments !='Inactive'){
          ref.addNewRow(val.moduleId,val.moduleName);
        }        
      })      
    });
  }

  get formArr() {
    return this.updateApps.get('modules') as FormArray;
  }

  initItemRows(id,val) {
    return this.fb.group({
      moduleId: id,
      moduleName: [val]
    });
  }

  addNewRow(id,val) {
    this.formArr.push(this.initItemRows(id,val));
  }

  deleteRow(index: number) {
    if(this.formArr.controls.length > 1) {
      this.formArr.removeAt(index);
    }
  }

  navigateToFreshReport() {
    this.router.navigate(['/users/updateapp/list'])
  }

  resetForm() {
    this.updateApps.reset();
    this.updateApps.controls.modules['controls'] = [];
    this.updateApps.controls['applicationName'].setValue(this.updateAppList.applicationName)
    var ref = this;
    this.updateAppList.modules.forEach(val => {
      if(val.comments !='Inactive'){
        ref.addNewRow(val.moduleId,val.moduleName);
      }        
    });
  }
  
  formSubmit() {
    if(this.updateApps.controls['applicationName'].valid == false) {
      $('#applicationName').focus();
    }    
    this.submitted = true;
    this.errorMsg.hideErrorMessage();
    let ref = this;
    let submitObj = {
      applicantId: this.updateAppList.applicantId,
      applicationName: this.updateApps.value.applicationName,
      modules: []
    };
    Object.keys(this.updateApps.value.modules).forEach((key) => {
      if(ref.updateApps.value.modules[key].moduleName && ref.updateApps.value.modules[key].moduleName != '') {
        if(ref.updateApps.value.modules[key].moduleId != '') {
          submitObj.modules.push({
            moduleId: ref.updateApps.value.modules[key].moduleId,
            moduleName: ref.updateApps.value.modules[key].moduleName
          });
        } else {
          submitObj.modules.push({
            moduleName: ref.updateApps.value.modules[key].moduleName
          });
        }
      }
    });
    if(this.updateApps.valid) {
      this.api.update(this.conf.URLS.UpdateApp.List, submitObj).subscribe(response => {
        this.router.navigate(['./users/updateapp/list'])
      },err => {
        this.errorMsg.showErrorMessage();
      })
    }
  }

}
