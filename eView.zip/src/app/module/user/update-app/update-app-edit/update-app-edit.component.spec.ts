import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { UpdateAppEditComponent } from './update-app-edit.component';
import { AlertModule } from 'ngx-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlashMessagesService } from 'angular2-flash-messages';
import { AppConfiguration } from '../../../../app-configuration';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('UpdateAppEditComponent', () => {
  let component: UpdateAppEditComponent;
  let fixture: ComponentFixture<UpdateAppEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        AlertModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ UpdateAppEditComponent ],
      providers: [
        FlashMessagesService,
        AppConfiguration
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateAppEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
