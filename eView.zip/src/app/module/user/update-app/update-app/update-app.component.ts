import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from '../../../../service/rest-api.service';
import { AppConfiguration } from '../../../../app-configuration';
import { FlashMessageService } from '../../../../service/flash-message/flash-message.service';

@Component({
  selector: 'app-update-app',
  templateUrl: './update-app.component.html',
  styleUrls: ['./update-app.component.css']
})
export class UpdateAppComponent implements OnInit {

  updateAppList: any = [];
  constructor(private errorMsg: FlashMessageService, private router: Router, private api: RestApiService, private appConfig: AppConfiguration) {
    this.getList();
  }

  ngOnInit() {
  }

  updateStatus(status, list){
    let submitObj = list;
    submitObj.appStatus = status;    
    this.api.update(this.appConfig.URLS.UpdateApp.List, submitObj).subscribe(response => {
      this.getList();
    },err => {
      this.errorMsg.showErrorMessage();
    })
  }

  getList() {
    this.errorMsg.hideErrorMessage();
    this.api.get(this.appConfig.URLS.UpdateApp.List).subscribe(response => {
      this.updateAppList = response;
    }, err => {
      this.errorMsg.showErrorMessage();
    });
  }

  editApp(event, Id) {
    this.router.navigate(['./users/updateapp/edit/' + Id])
  }
}
