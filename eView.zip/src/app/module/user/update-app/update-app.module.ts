import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpdateAppComponent } from './update-app/update-app.component';
import { UpdateAppAddComponent } from './update-app-add/update-app-add.component';
import { UpdateAppEditComponent } from './update-app-edit/update-app-edit.component';
import { ValidateGuard } from '../../../guards/validate.guard';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomDirectiveModule } from '../../../directives/custom-directive/custom-directive.module';
import { AlertModule } from 'ngx-bootstrap';

const routes: Routes = [
  { path: 'list', component:UpdateAppComponent, canActivate: [ValidateGuard], data:{permissionId:[''] } },
  { path: 'add', component:UpdateAppAddComponent, canActivate: [ValidateGuard], data:{permissionId:[''] } },
  { path: 'edit/:id', component:UpdateAppEditComponent, canActivate: [ValidateGuard], data:{permissionId:[''] } },
];


@NgModule({
  declarations: [
    UpdateAppComponent, 
    UpdateAppAddComponent, 
    UpdateAppEditComponent, 
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    CustomDirectiveModule,
    AlertModule
  ]
})
export class UpdateAppModule { }
