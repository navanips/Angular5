import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormBuilder, FormArray } from '@angular/forms';
import { AppConfiguration } from '../../../../app-configuration';
import { RestApiService } from '../../../../service/rest-api.service';
import { FlashMessageService } from '../../../../service/flash-message/flash-message.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-update-app-add',
  templateUrl: './update-app-add.component.html',
  styleUrls: ['./update-app-add.component.css']
})
export class UpdateAppAddComponent implements OnInit {

  public alerts: any[] = [];
  updateApps: FormGroup;
  arrayItems = [];
  submitted = false;

  constructor(private errorMsg:FlashMessageService, private router: Router, private conf: AppConfiguration, private api: RestApiService, private fb: FormBuilder) { }

  ngOnInit() {
    this.updateApps = this.fb.group({
      applicationName: new FormControl('', [Validators.required]),
      modules: this.fb.array([this.initItemRows()])
    });
  }

  get formArr() {
    return this.updateApps.get('modules') as FormArray;
  }

  initItemRows() {
    return this.fb.group({
      moduleName: ['']
    });
  }

  addNewRow() {
    this.formArr.push(this.initItemRows());
  }

  deleteRow(index: number) {
    if(this.formArr.controls.length > 1) {
      this.formArr.removeAt(index);
    }
  }

  navigateToFreshReport() {
    this.router.navigate(['/users/updateapp/list'])
  }

  resetForm() {
    this.updateApps.reset();
  }
  formSubmit() {
    if(this.updateApps.controls['applicationName'].valid == false) {
      $('#applicationName').focus();
    }
    this.submitted = true;
    this.errorMsg.hideErrorMessage();
    let ref = this;
    let submitObj = {
      applicationName: this.updateApps.value.applicationName,
      modules: []
    };
    Object.keys(this.updateApps.value.modules).forEach((key) => {
      if(ref.updateApps.value.modules[key].moduleName != '') {
        submitObj.modules.push({
          moduleName: ref.updateApps.value.modules[key].moduleName
        });
      }
    });
    if(this.updateApps.valid) {
      this.api.add(this.conf.URLS.UpdateApp.List, submitObj).subscribe(response => {
        this.router.navigate(['./users/updateapp/list'])
      },err => {
        this.errorMsg.showErrorMessage();
      })
    }
  }
}
