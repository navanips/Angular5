import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { UpdateAppAddComponent } from './update-app-add.component';
import { AlertModule } from 'ngx-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlashMessagesService } from 'angular2-flash-messages';
import { AppConfiguration } from '../../../../app-configuration';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('UpdateAppAddComponent', () => {
  let component: UpdateAppAddComponent;
  let fixture: ComponentFixture<UpdateAppAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        AlertModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule
      ],
      declarations: [ UpdateAppAddComponent ],
      providers: [
        FlashMessagesService,
        AppConfiguration
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateAppAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
