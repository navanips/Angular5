import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppConfiguration } from '../../../../app-configuration';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { FileUploadModule } from 'ng2-file-upload';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DebugElement } from '@angular/core';
import { AlertModule } from 'ngx-bootstrap';
import { XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { UpdateUserModel } from '../../../../service/user/update-user-model';
import { UpdateUserService } from '../../../../service/user/update-user.service';
import { RestApiService } from '../../../../service/rest-api.service';
import { UpdateComponent } from './update.component';
import { SearchModel } from '../../../../service/search-model';
import { FlashMessagesService } from 'angular2-flash-messages';

describe('UpdateComponent', () => {
  let component: UpdateComponent;
  let fixture: ComponentFixture<UpdateComponent>;
  let de: DebugElement;
  let el:HTMLElement;
  let searchmodel: UpdateUserModel;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        DateRangePickerModule,
        DatePickerModule,
        FileUploadModule,
        RouterTestingModule,
        HttpClientTestingModule,
        AlertModule
      ],
      declarations: [ UpdateComponent ],
      providers: [
         UpdateUserModel,
        AppConfiguration,
        UpdateUserService,
        RestApiService,
        SearchModel,
        FlashMessagesService,
        { provide: XHRBackend, useClass: MockBackend }
      ]
    })
    .compileComponents().then(() => {
      fixture = TestBed.createComponent(UpdateComponent);
      component = fixture.debugElement.componentInstance;
      })
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should userid field need to exist', () => {
    const addItemDebugElement = fixture.debugElement.query(By.css('#userId'));
    expect(addItemDebugElement).toBeTruthy();
  });

  it('Should firstname field need to exist', () => {
    const addItemDebugElement = fixture.debugElement.query(By.css('#firstName'));
    expect(addItemDebugElement).toBeTruthy();
  });

  it('Should surname field need to exist', () => {
    const addItemDebugElement = fixture.debugElement.query(By.css('#lastName'));
    expect(addItemDebugElement).toBeTruthy();
  });

  it('Should status field need to exist', () => {
    const addItemDebugElement = fixture.debugElement.query(By.css('#status'));
    expect(addItemDebugElement).toBeTruthy();
  });

  it('Should usertype field need to exist', () => {
    const addItemDebugElement = fixture.debugElement.query(By.css('#userType'));
    expect(addItemDebugElement).toBeTruthy();
  });

   it('Should companyname field need to exist', () => {
    const addItemDebugElement = fixture.debugElement.query(By.css('#companyName'));
    expect(addItemDebugElement).toBeTruthy();
  });

   it('Should status field need to exist', () => {
    const addItemDebugElement = fixture.debugElement.query(By.css('#status'));
    expect(addItemDebugElement).toBeTruthy();
  });


  it('should search form be valid', async(() => {

      const fundname = fixture.debugElement.query(By.css('#userType'));
      fundname.nativeElement.value = 'Trustee';
      expect(fundname.nativeElement.value).toBe('Trustee');

      const documenttype = fixture.debugElement.query(By.css('#firstName'));
      documenttype.nativeElement.value = 'metlife';
      expect(documenttype.nativeElement.value).toBe('metlife');

      const description = fixture.debugElement.query(By.css('#lastName'));
      description.nativeElement.value = 'metlife';
      expect(description.nativeElement.value).toBe('metlife');

      const department = fixture.debugElement.query(By.css('#status'));
      department.nativeElement.value = 'Active';
      expect(department.nativeElement.value).toBe('Active');

      const effectivedate = fixture.debugElement.query(By.css('#companyName'));
      effectivedate.nativeElement.value = 'METL';
      expect(effectivedate.nativeElement.value).toBe('METL');

      const emailId = fixture.debugElement.query(By.css('#emailId'));
      emailId.nativeElement.value = 'test@test.com';
      expect(emailId.nativeElement.value).toBe('test@test.com');

  }));

  it('should search form be invalid', async(() => {
      const fundname = fixture.debugElement.query(By.css('#firstName'));
      expect(fundname.nativeElement.value).toBe('');

      const documenttype = fixture.debugElement.query(By.css('#lastName'));
      expect(documenttype.nativeElement.value).toBe('');


      const department = fixture.debugElement.query(By.css('#companyName'));
      expect(department.nativeElement.value).toBe('');

      const effectivedate = fixture.debugElement.query(By.css('#status'));
      expect(effectivedate.nativeElement.value).toBe('');

      expect(component.updateUser.valid).toBeFalsy();
  }));

  it('should firstname accepts alpha only',async(() => {
     const description = fixture.debugElement.query(By.css('#firstName'));
     description.nativeElement.value = 'australia';
     expect(description.nativeElement.value).toMatch(/^[A-Za-z]+$/);
  }));

  it('should surname accepts alpha only',async(() => {
     const description = fixture.debugElement.query(By.css('#lastName'));
     description.nativeElement.value = 'australia';
     expect(description.nativeElement.value).toMatch(/^[A-Za-z]+$/);
  }));

  it('should firstname contains max 20 only',async(() => {
     const description = fixture.debugElement.query(By.css('#firstName'));
     description.nativeElement.value = 'mamamamamamamamamamamqmqmqmqmq';
     expect(description.nativeElement.value).toBe('mamamamamamamamamamamqmqmqmqmq');
  }));

 it('should userid contains max 20 only',async(() => {
     const description = fixture.debugElement.query(By.css('#userId'));
     description.nativeElement.value = 'mamamamamamamamamamamqmqmqmqmq';
     expect(description.nativeElement.value).toBe('mamamamamamamamamamamqmqmqmqmq');
  }));

   it('should sur mname contains max 30 only',async(() => {
     const description = fixture.debugElement.query(By.css('#lastName'));
     description.nativeElement.value = 'mamamamamamamamamamamqmqmqmqmq1234567898';
     expect(description.nativeElement.value).toBe('mamamamamamamamamamamqmqmqmqmq1234567898');
  }));
  
});
