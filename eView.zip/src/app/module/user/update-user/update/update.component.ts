import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormBuilder, AbstractControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConfiguration } from '../../../../app-configuration';
import { RestApiService } from '../../../../service/rest-api.service';
import { EditUserResolverService } from '../../../../service/user/edit-user-resolver.service';
import { UserService } from '../../../../service/user/user.service';
import { FlashMessageService } from '../../../../service/flash-message/flash-message.service';
import * as $ from 'jquery';
import * as moment from 'moment';
import { UpdateUserModel } from '../../../../service/user/update-user-model';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalComponent } from '../../../../layout/ngb-modal/ngb-modal.component';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  applicationDetails: any;
  updateUser: FormGroup;
  resetpassworderror: boolean;
  show: boolean;
  deletedstatus: any;
  resetpassword: any;
  successMsg: any;
  UpdatenewDetails: any;
  submitted = false;
  fundList: any;
  resultData: any;
  userType: any;
  status: any;
  alteredUserId: any;
  CompanyList: any;
  roles :any;
  appDetails: any;
  selectedMod: any;
  appModule = [{
    modules: []
  }];
  updatedmodule: any;
  arr1Selected = [];
  arr2Selected = [];
  refArrObj = [];
  fundKeys = [];
  business = '';
  moduledet: any;
  statusUser: any;
  // fnameErr = false;
  // lnameErr = false;
  compAccess = false;
  postFund = [];
  FNames = [];
  selectedFNames = [];
  appSelected = [];
  selectedANames = [];
  selectedApp = '';
  public alerts: any[] = [];
  SubmitObj = {
    firstName: '',
    surName: '',
    userId: '',
    alteredUserId: '',
    userType: '',
    emailId: '',
    companyName: '',
    workNumber: '',
    mobileNumber: '',
    funds: [],
    applicationAccess: [],
    status: '',
  };
  fundSelected;
  userAlreadyExists = false;
  selectedMainApp:any;
  selectedMainAppRef:any;
  passwordHistoryError: boolean;
  constructor(private ngbModal: NgbModal, private searchData: UpdateUserModel, private errorMsg:FlashMessageService,private conf: AppConfiguration, private route: ActivatedRoute,
    private router: Router, private ReportDetService: EditUserResolverService, private location: Location, private api: RestApiService, private fb: FormBuilder, private UserService: UserService) {
    this.getFund();
    this.getstatus();
    this.getCompanies();
    this.getAppList();
    if(sessionStorage.getItem('userDetails')) {
      this.roles = JSON.parse(sessionStorage.getItem('userDetails')).roles.join();
    }
  }

  ngOnInit() {
    this.errorMsg.hideErrorMessage();
    this.applicationDetails = (this.route.snapshot.data['data'])?this.route.snapshot.data['data']:{};
    this.statusUser = this.applicationDetails.status;
    this.resetpassworderror = false;
    
    this.refArrObj = (this.applicationDetails.applicationAccess) ? this.applicationDetails.applicationAccess : [];
    this.SubmitObj.applicationAccess = this.applicationDetails.applicationAccess;
    this.SubmitObj.firstName = this.applicationDetails.firstName;
    this.SubmitObj.surName = this.applicationDetails.surName;
    this.SubmitObj.userId = this.applicationDetails.userId;
    this.SubmitObj.userType = this.applicationDetails.userType;
    this.SubmitObj.emailId = this.applicationDetails.emailId;
    this.SubmitObj.companyName = this.applicationDetails.companyName;
    this.SubmitObj.workNumber = this.applicationDetails.workNumber;
    this.SubmitObj.mobileNumber = this.applicationDetails.mobileNumber;
    this.SubmitObj.status = this.applicationDetails.status;
    this.alteredUserId = this.applicationDetails.alteredUserId;

    if (this.applicationDetails.modules != '') {
      this.updatedmodule = this.applicationDetails.modules;
    }
    this.updateUser = this.fb.group({
      userDetails: this.fb.group({
        fName: new FormControl('', [Validators.required]),
        lName: new FormControl('', [Validators.required]),
        userId: new FormControl('', [Validators.required]),
        userType: new FormControl('', [Validators.required]),
        EmailId: new FormControl('', [Validators.required, Validators.pattern(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)]),
        companyName: new FormControl('', []),
        workNo: new FormControl('', []),
        MobNo: new FormControl('', []),
        status: new FormControl('', [])
      }),
      companyAccess: this.fb.group({
        businessName: new FormControl('', [])
      }),
      appDetails: this.fb.group({
        ApplicationName: new FormControl('', [])
      }),
    });
    
  }

  ngAfterViewInit() {
    if (this.applicationDetails.status == 'Deleted') {
      this.status = [{ key: 'Active', value: 'Active' },
      { key: 'Inactive', value: 'Inactive' }, { key: 'Deleted', value: 'Deleted' }];
      $("#deletetestcenter").removeClass("text-center");
    }
  }

  get f() { return this.updateUser.controls; }

  get userDetails(): any { return this.updateUser.get('userDetails'); }

  get companyAccess(): any { return this.updateUser.get('companyAccess'); }

  get appAccess(): any { return this.updateUser.get('appDetails'); }

  getFund() {
    this.api.get(this.conf.URLS.createUser.fundList).subscribe(res => {
      this.fundList = res;
      this.fundKeys = Object.keys(this.fundList);
      this.getSelectedFundPopulate();
    });
  }
  getSelectedFundPopulate() {
    let allFunds = this.fundList['Direct'].concat(this.fundList['Call Centre'], this.fundList['Group']);
    if(this.applicationDetails.userType && this.applicationDetails.userType.toLowerCase() != 'metlife internal' && this.applicationDetails.userType.toLowerCase() != 'internal') {
      this.compAccess = true;
    }
    this.fundSelected = [];
    this.selectedFNames = [];
    if (this.applicationDetails.funds && this.applicationDetails.funds != null) {
      this.applicationDetails.funds.forEach(item => {
        let particularFund = allFunds.filter(x => x.fundCode == item.fundCode)[0];
        if(particularFund){
          this.fundSelected.push({
            fundCode: item.fundCode,
            fundName: particularFund.fundName
          });
          this.selectedFNames.push(item.fundCode);
        }
      });      
    }
  }

  getstatus() {
    this.status = [{ key: 'Active', value: 'Active' },
    { key: 'Inactive', value: 'Inactive' }];
  }

  getCompanies() {
    this.api.get(this.conf.URLS.createUser.CompanyList).subscribe(result => {
      this.CompanyList = result;
    });
  }

  getAppList() {
    this.api.get(this.conf.URLS.createUser.AppList).subscribe(result => {
      this.appDetails = result;
      let i = 0;
      this.appDetails.filter(x => x.modules.filter(function(y,index) {
        if(y.metRoleName == "eQuery_DataExport") {
          if(i == 1) { 
            x.modules.splice(index,1)
          }
          i++;
        }
      }));      
      this.populateSelectedApplication();
    });
    
  }
  populateSelectedApplication(){
    let allApplication = [];
    let allApp = [];
    this.selectedMainApp = [];
    this.selectedMainAppRef = [];
    this.applicationDetails.applicationAccess.forEach((item) => {
      this.selectedMainApp.push(item.applicationName);
      this.selectedMainAppRef.push({
        applicationName: item.applicationName,
        modules:[]
      });
    });

    if (this.appDetails && this.appDetails.length > 0) {
      this.appDetails.filter(x => {
        return x.modules.filter(y => {
          y.refMainApp = x.applicationName;
          allApplication.push(y);          
        })
      });
    }

    if (this.applicationDetails.applicationAccess && this.applicationDetails.applicationAccess.length > 0) {
      this.applicationDetails.applicationAccess.filter(x => {
        return x.modules.filter(y => {
          y.refMainApp = x.applicationName;
          allApp.push(y);          
        })
      });
    }

    this.appSelected = [];
    this.selectedANames = [];
      if(this.applicationDetails.modules) {
        this.applicationDetails.modules.forEach(item => {
        let currentApp = item;
        // let particularApp = allApplication.filter(x => x.metRoleName == currentApp)[0];
        let particularApp = allApp.filter(x => x.metRoleName == currentApp)[0];
        if(particularApp && this.selectedANames.indexOf(particularApp.metRoleName) == -1){
          this.appSelected.push(particularApp);
          this.selectedANames.push(particularApp.metRoleName);
          let mainIndex =  this.selectedMainApp.indexOf(particularApp.refMainApp);
          if(this.selectedMainAppRef[mainIndex]) {
            this.selectedMainAppRef[mainIndex].modules.push(particularApp);
          }
        }
      });
    }
  }

  getFNames(event) {
    if (event.target.value != '') {
      this.FNames = (this.fundList[event.target.value].length > 0) ? this.fundList[event.target.value] : [];
    } else {
      this.FNames = [];
    }
  }

  changeModule(event) {
    if (event.target.value != '') {
      this.appModule = this.appDetails.filter(x => x.applicationName == event.target.value);
    } else {
      this.appModule = [{
        modules: []
      }];
    }
  }

  movetoLeftFund(item) {
    let currentfundCode = item.fundCode;
    let deleteIndex = this.selectedFNames.indexOf(currentfundCode);
    this.selectedFNames.splice(deleteIndex, 1);
    this.fundSelected.splice(deleteIndex, 1);
  }

  movetoRightFund(item) {    
    this.fundSelected.push(item);
    this.selectedFNames.push(item.fundCode);
  }

  movetoLeftModule(item) {
    let currentmetRoleName = item.metRoleName;
    let deleteIndex = this.selectedANames.indexOf(currentmetRoleName);
    this.selectedANames.splice(deleteIndex, 1);
    this.appSelected.splice(deleteIndex, 1);

    let appIndex = this.selectedMainApp.indexOf(item.refMainApp);
    let moduleDeleteIndex;
    if(this.selectedMainAppRef[appIndex]) {
      this.selectedMainAppRef[appIndex].modules.forEach((curerntModule, index) => {
        let modulecurrentmetRoleName = curerntModule.metRoleName;
        if(modulecurrentmetRoleName == currentmetRoleName){
          moduleDeleteIndex = index;
        }
      });
      this.selectedMainAppRef[appIndex].modules.splice(moduleDeleteIndex, 1);
    }
  }

  movetoRightModule(item, mainApp) {
    item.refMainApp = mainApp;
    this.appSelected.push(item);
    this.selectedANames.push(item.metRoleName);
    let appIndex = this.selectedMainApp.indexOf(mainApp);
    if(this.selectedMainAppRef[appIndex]) {
      this.selectedMainAppRef[appIndex].modules.push(item);
    } else {
      this.selectedMainApp.push(this.selectedApp);
      this.selectedMainAppRef.push({
        applicationName : this.selectedApp,
        modules : [item]
      });
    }
  }

  BooleanConverter(value: any) {
    return value;
  }

  DeleteUserModel() {
    let ngbModalOptions: NgbModalOptions = {
      backdrop : 'static',
      keyboard : true
    };
    const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
    m.componentInstance.Title = 'Confirmation';
    m.componentInstance.confMessage = 'Are you sure you want to delete this user?';
    let res = this.BooleanConverter(m.result);
    res.then((userResponse) => {
      if (userResponse == true) {
        this.DeleteUser();
      }
    }); 
  }

  toggleModel() {
    $('#DeleteDocModal').hide();
  }

  navigateToCurrentPage() {
    $('#DeleteDocsuccessModal').hide();
    $('#submittedgeneratepassModal').hide();
    $('#submitGeneratereseterrorModel').hide();
    $('#submittedresetModal').hide();
    $('#submittedModal').hide();
    this.scrollToTop();
  }

  DeleteUser() {
    this.passwordHistoryError = false;
    this.toggleModel();
    this.errorMsg.hideErrorMessage();
    this.resetpassworderror = false;
    this.deletedstatus = { 'status': 'Deleted', 'alteredUserId': this.alteredUserId };
    this.api.update(this.conf.URLS.createUser.addUser + '/' + this.SubmitObj.userId, this.deletedstatus).subscribe(response => {
      if (response) {
        this.successMsg = "This user has been deleted.";
        $('#DeleteDocsuccessModal').show();
        this.status = [{ key: 'Active', value: 'Active' },
        { key: 'Inactive', value: 'Inactive' }, { key: 'Deleted', value: 'Deleted' }];
        this.SubmitObj.status = 'Deleted';
        $("#deletetestcenter").removeClass("text-center");
      } else {
       this.errorMsg.showErrorMessage();
      }
    }, err => {
      this.errorMsg.showErrorMessage();
    });
  }

  Generatepassword() {
    this.passwordHistoryError = false;
    this.errorMsg.hideErrorMessage();
    this.resetpassworderror = false;
    this.SubmitObj.status = this.applicationDetails.status;
    let dataObj = '/' + this.SubmitObj.userId + '/' + this.SubmitObj.emailId + '/regenerate';
    if (this.statusUser == 'Active') {
      this.UserService.resetPassword(dataObj).subscribe(data => {
        this.resultData = data;
        if (this.resultData.response == 'Success') {
          $('#submittedgeneratepassModal').show();
          this.scrollToTop();
        } else {
          this.errorMsg.showErrorMessage();
        }
      },
        err => {
          this.errorMsg.showErrorMessage();
        });
    } else {
      $('#submitGeneratereseterrorModel').show();
    }
  }

  scrollToTop() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  }
  
  Resetpassword() {
    this.passwordHistoryError = false;
    this.errorMsg.hideErrorMessage();
    let resetpass = $('#resetpasstext').val();
    this.SubmitObj.status = this.applicationDetails.status;
    this.resetpassword = resetpass;
    if (this.resetpassword && this.resetpassword != null) {
      this.resetpassworderror = false;
      let SubmitObject = { newPassword: btoa(resetpass) };
      if (this.statusUser == 'Active') {
        this.api.add(this.conf.URLS.createUser.addUser + '/' + this.SubmitObj.userId + '/change', SubmitObject).subscribe(res => {
          this.resultData = res;
          if (this.resultData.response == 'Success') {
            $('#resetpasstext').val('');
            $('#submittedresetModal').show();
            this.scrollToTop();
          } else {
            if (this.resultData.response == 'Failure') {
              this.passwordHistoryError = true;
            }else{
              this.errorMsg.showErrorMessage();
            }
          }
        },
        err => {          
          this.errorMsg.showErrorMessage();
        });
      } else {
        $('#submitGeneratereseterrorModel').show();
      }
    } else {
      if(this.statusUser == 'Active'){
         this.resetpassworderror = true;
      }else{
        this.resetpassworderror = false;
        $('#submitGeneratereseterrorModel').show();
      }
    }
  }

  navigateToFreshReport() {
    this.searchData.resetSearchModel();
    sessionStorage.setItem('Searched', 'false');
    this.router.navigate(['/users/update-user/reports']);
  }

  onSubmit() {
    this.passwordHistoryError = false;
    let focusArr = $('input,textarea,select').filter('[required]:visible');
    let check = false;
    var ref = this;
    focusArr.each(function(index) { 
        let name = focusArr[index].attributes['formControlName'].value;
        if(name != 'ApplicationName' && ref.userDetails.controls[name].valid == false && check == false) {
          focusArr[index].focus();
          check = true;
        }
    });
    if(check == false && this.appSelected.length == 0) {
      $('#applicationaccess').focus();
    }    
    this.submitted = true;
    // this.fnameErr = false;
    // this.lnameErr = false;
    this.resetpassworderror = false;
    this.SubmitObj.funds = this.fundSelected;
    this.SubmitObj.applicationAccess = this.selectedMainAppRef;
    this.errorMsg.hideErrorMessage();
    if (this.statusUser == 'Inactive' && this.SubmitObj.status != 'Active') {
      this.successMsg = "This user is now inactive";
      $('#submittedModal').show();
    }
    else if (this.statusUser == 'Active' || this.SubmitObj.status == 'Active') { //&& this.fnameErr === false && this.lnameErr == false
      if (this.updateUser.valid && this.appSelected.length != 0 && this.userAlreadyExists == false) {
        if(this.SubmitObj.status == 'Active'){
          this.Update_user();
        }else if(this.SubmitObj.status == 'Inactive'){
          let ngbModalOptions: NgbModalOptions = {
              backdrop : 'static',
              keyboard : true
          };
          const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
          m.componentInstance.Title = 'Confirmation';
          m.componentInstance.confMessage = 'Are you sure you want to make this user inactive?';
          let res = this.BooleanConverter(m.result);
          res.then((userResponse) => {
            if (userResponse == true) {
              this.Update_user();
            }
          }); 
        }
      }
    }
  }

  Update_user(){
    this.api.update(this.conf.URLS.createUser.addUser + '/' + this.SubmitObj.userId, this.SubmitObj).subscribe(response => {
          if (response) {
           // this.statusUser = this.SubmitObj.status;
            if (this.SubmitObj.status == 'Inactive') {
              this.successMsg = "This user is now inactive";
              $('#resetpasstext').val('');
              $('#submittedModal').show();
              this.statusUser = 'Inactive';
              this.applicationDetails.status = 'Inactive';
            } else if(this.statusUser == 'Inactive' && this.SubmitObj.status == 'Active'){
              this.successMsg = "This user is now active";
              $('#resetpasstext').val('');
              $('#submittedModal').show();
              this.statusUser = 'Active';
              this.applicationDetails.status = 'Active';
            }
            else if (this.SubmitObj.status == 'Active' && this.statusUser != 'Inactive') {
            this.successMsg = "The user has been successfully updated.";
            $('#resetpasstext').val('');
            $('#submittedModal').show();
            this.statusUser = 'Active';
            this.applicationDetails.status = 'Active';
            }
          } else {
            this.errorMsg.showErrorMessage();
          }
        }, err => {
          this.errorMsg.showErrorMessage();
        });
  }
}