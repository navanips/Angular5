import { Component, OnInit, HostListener } from '@angular/core';
import { Observable } from 'rxjs';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AppConfiguration } from '../../../../app-configuration';
import { RestApiService } from '../../../../service/rest-api.service';
import * as $ from 'jquery';
import * as moment from 'moment';
import { UpdateUserModel } from '../../../../service/user/update-user-model';
import { UpdateUserService } from '../../../../service/user/update-user.service';
import { FlashMessageService } from '../../../../service/flash-message/flash-message.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
 reports: any=[];
 showFilter: boolean=true;
 reportLimit: any;
 reportOffset: any;
 curPageIndex: any;
 filequelength:any;
 metadata: any ={count:''};
 searched:boolean = false;
 showresult:boolean;
 config: any;
 gridColumns: any;
 searchData:any;
 public fundList: any;
 public fundKeys:any;
 public companyList: any;
 public usertypes: any;
 public statusList: any;
 userPermissions:any;
 currentSort: any;
 roles :any;
 public dateRangeExceeded: Boolean;
 public futureDateRange: Boolean;
 public startDateRange: Boolean;
 public today: Date = new Date(new Date().toDateString());

 @HostListener('window:beforeunload') goToPage() {
    sessionStorage.setItem('Searched' , JSON.stringify(this.searched));
    sessionStorage.setItem('reportName' , 'UPDATEUSER');
    sessionStorage.setItem('reportData' , JSON.stringify(this.data.searchModal));
  }

 constructor(private errorMsg:FlashMessageService, private route: ActivatedRoute, private router: Router,
    private data: UpdateUserModel, public upadteuserService: UpdateUserService,private http:RestApiService,private appConfig: AppConfiguration) {
      let perm  = (JSON.parse(sessionStorage.getItem('userDetails')).menus)?JSON.parse(sessionStorage.getItem('userDetails')).menus:[];
      this.userPermissions = perm.join(',');
      this.roles = JSON.parse(sessionStorage.getItem('userDetails')).roles.join();
      
 }

  ngOnInit() {
    this.http.get(this.appConfig.URLS.createUser.fundList).subscribe(response => {
      this.fundList = response;
      // this.fundList.Group = JSON.parse(this.fundList.Group)
      this.fundKeys = this.fundList.Group;
    }); 
    this.http.get(this.appConfig.URLS.createUser.CompanyList).subscribe(response => {
      this.companyList = response;
      if(this.roles.indexOf('metlife internal') == -1) {
        this.searchData.companyname = response[0].companyCode;
      }
    }); 

    this.statusList = [
        { name: 'Active', value: 'Active' },
        { name: 'Inactive', value: 'Inactive' },
        { name: 'Deleted', value: 'Deleted' }
    ];
    //this.reports = this.route.snapshot.data['reports'].items;
    this.showresult = false;
    this.errorMsg.hideErrorMessage();
    if(!sessionStorage.getItem('reportData') && sessionStorage.getItem('reportName') != 'UPDATEUSER') {
        this.data.resetSearchModel();
    }
    //this.metadata = this.route.snapshot.data['reports'].metadata;
    this.searchData = Object.assign({}, this.data.searchModal);
    sessionStorage.setItem('reportName' , 'UPDATEUSER');
    sessionStorage.setItem('reportData' , JSON.stringify(this.data.searchModal));
    this.getuserType();
    this.currentSort = 'companyname';
    this.reportLimit = this.data.searchModal.metaData.reportLimit - this.data.searchModal.metaData.reportOffset;
    this.reportOffset = 0;

    let lim = this.reportLimit;
    let offs = (this.data.searchModal.metaData.reportLimit == 0)?20:this.data.searchModal.metaData.reportLimit;
    let pageindex = (parseInt(offs)/parseInt(lim));
    this.curPageIndex = pageindex;

    let dataSort = this.data.searchModal.metaData;

    this.config = {
      itemsPerPage: this.reportLimit,
      currentPage: this.curPageIndex,
      totalItems: (this.metadata)?this.metadata.count:'',
    };

     this.gridColumns = [
      {
        columnTitle: 'User ID',
        columnKey:'userid',
        currentSort: (dataSort.orderby == 'userid')?true:false,
        colwidth:'col-1',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'userid')?dataSort.order:'asc'
      },
      {
        columnTitle: 'First name',
        columnKey:'firstname',
        currentSort: (dataSort.orderby == 'firstname')?true:false,
        colwidth:'col-2',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'firstname')?dataSort.order:'asc'
      },
      {
        columnTitle: 'Last name',
        columnKey:'surname',
        currentSort: (dataSort.orderby == 'surname')?true:false,
        colwidth:'col-1',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'surname')?dataSort.order:'asc'
      },
      {
        columnTitle: 'Email address',
        columnKey:'emailid',
        currentSort: (dataSort.orderby == 'emailid')?true:false,
        colwidth:'col-2',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'emailid')?dataSort.order:'asc'
      },
      {
        columnTitle: 'User type',
        columnKey:'usertype',
        currentSort: (dataSort.orderby == 'usertype')?true:false,
        colwidth:'col-1',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'usertype')?dataSort.order:'asc'
      },
      {
        columnTitle: 'Company name',
        columnKey:'companyname',
        currentSort: (dataSort.orderby == 'companyname')?true:false,
        colwidth:'col-1',
        cursor:'pointer-cursor',
        order: (dataSort.orderby == 'companyname')?dataSort.order:'asc'
      },
      {
        columnTitle: 'Status',
        columnKey:'status',
        currentSort: (dataSort.orderby == 'status')?true:false,
        cursor:'pointer-cursor',
        colwidth:'col-1',
        order: (dataSort.orderby == 'status')?dataSort.order:'asc'
      }
    ];

     if(sessionStorage.getItem('Searched') == 'true') {
        this.filterResults();
    } 
  }
  getuserType() {
    this.usertypes = [
      { name: 'METLIFE INTERNAL', value: 'Internal' },
      { name: 'FUND ADMINISTRATOR', value: 'Fund Administrator'},
      { name: 'TRUSTEE', value: 'Trustee' },
      { name: 'BROKER', value: 'Broker'}
    ];
    var ref = this;
    if(this.roles.indexOf('metlife internal') == -1) {
      this.usertypes.filter(function(x){
        if(ref.roles.indexOf(x.name.toLowerCase()) > -1) {
          ref.searchData.userType = x.name;
        }
      });
    }
  }

  navigateToParent(){
    this.router.navigate(['.'], { relativeTo: this.route.parent });
  }

  toggleFilters() {
    this.showFilter = !this.showFilter;
  }

  canceltoggleFilters(){
     let reportData = Object.assign({}, this.data.resetModel);
     if(this.roles.indexOf('metlife internal') == -1) {
        reportData.companyname = this.searchData.companyname;
        reportData.userType = this.searchData.userType;
     }
     this.searchData = reportData; 
  }

  sortResults(sortColumn) {
   for (const column of this.gridColumns) {
      if (column === sortColumn) {
        column.currentSort = true;
        // column.order = column.order === 'desc' ? 'asc' : 'desc';
      } else {
        column.currentSort = false;
        // column.order = column.order === 'desc';
      }
    }
    if(this.data.searchModal.metaData.orderby == sortColumn.columnKey) {
      sortColumn.order = (sortColumn.order == 'asc')?'desc':'asc';
    }
    else {
      sortColumn.order = 'asc';
    }     
    this.curPageIndex = 1;
    this.data.searchModal.metaData.reportOffset = '0';
    this.data.searchModal.metaData.reportLimit = this.reportLimit;
    this.data.searchModal.metaData.orderby = sortColumn.columnKey;
    this.data.searchModal.metaData.order = sortColumn.order;
    this.filterResults();
  }

  alphaOnly(event,val)
  {
    let letters;
    if(val=='alpha'){  letters = /^[A-Za-z]+$/; }
    else if (val == 'alphanum'){ letters = /^[A-Za-z0-9]+$/; }
    else if(val == 'num'){ letters = /^[0-9]+$/; } else if(val == 'alphacomma') {
      letters = /^[A-Za-z-'\s+]*$/;
    }
    if(event.key.match(letters)) return true;
    else return false;
  }

  searchfilterResults() {
    let orderKey = this.searchData.metaData.orderby;
    let orderType = this.searchData.metaData.order;
    sessionStorage.setItem('reportName' , 'UPDATEUSER');
    sessionStorage.setItem('reportData' , JSON.stringify(this.searchData));
    this.searchData.metaData = {
      reportLimit: this.reportLimit,
      reportOffset: '0',
      orderby: orderKey,
      order: orderType
    };
    this.curPageIndex = 1;
    this.data.searchModal = Object.assign({}, this.searchData);
    this.filterResults()
  }

  filterResults() {
    this.errorMsg.hideErrorMessage();
    
    this.upadteuserService.searchReports('addUser').subscribe((reportsObj: any) => {
      this.reports = reportsObj.items;
      if(this.reports){
        this.showresult = true;
        this.showFilter = false;
        this.searched = true;
        sessionStorage.setItem('Searched' , JSON.stringify(this.searched)); 
      }
      this.metadata = reportsObj.metadata;
      this.config = {
        itemsPerPage: this.reportLimit,
        currentPage: this.curPageIndex,
        totalItems: this.metadata.count
      };
      if(this.reports.length==0){
        this.showresult = false;
        this.showFilter = true;
      }
    },err => {      
      this.reports = [];
      this.errorMsg.showErrorMessage();
      this.showresult = false;
      this.showFilter = true;
      this.searched = false;        
  });
  }

  onExportReport() {
      this.errorMsg.hideErrorMessage();
      this.upadteuserService.searchUserExport('searchuserExport').subscribe(data => {
        if (navigator.appVersion.toString().indexOf('.NET') >= 0) {
          window.navigator.msSaveBlob(data, 'Search_user_report.xlsx');
        } else {
          const fileStream = new Blob([data], {type: 'application/octet-stream'});
          const anchorTag = document.createElement('a');
              document.body.appendChild(anchorTag);
          const fileURL = URL.createObjectURL(fileStream);
          anchorTag.href = fileURL;
                      anchorTag.download = 'Search_user_report.xlsx';
                      anchorTag.click();
        }
        },err => {
        this.errorMsg.showErrorMessage();      
        });
    }

  pageChanged(event) {
    this.curPageIndex = event;
    this.data.searchModal.metaData.reportOffset =
    ((Number(this.reportLimit) * (this.curPageIndex - 1))).toString();
    this.data.searchModal.metaData.reportLimit = Number(this.reportLimit) * (this.curPageIndex);
    this.filterResults();
  }
  onLimitChange(limit: any) {
    this.reportLimit = limit;
    this.curPageIndex = 1;
    this.data.searchModal.metaData.reportOffset = '0';
    this.data.searchModal.metaData.reportLimit = limit;
    this.filterResults();
  }

  onDateRangeChange(event) {
    this.futureDateRange = event.endDate > this.today ? true : false;
    this.dateRangeExceeded = event.daySpan > this.appConfig.appConstants.maxDateRangeAllowed ? true : false;
    this.startDateRange = event.endDate >= event.startDate ? false : true;
  }

}
