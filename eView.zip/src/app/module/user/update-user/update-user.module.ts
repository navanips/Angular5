import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { NgxPaginationModule} from 'ngx-pagination';
import { TooltipModule } from 'ng2-tooltip-directive';

import { ReportsComponent } from './reports/reports.component';
import { UpdateComponent } from './update/update.component';
import { ValidateGuard } from '../../../guards/validate.guard';
import { AuthGuard } from '../../../guards/auth.guard';
import { EditUserResolverService } from '../../../service/user/edit-user-resolver.service';
import {CustomDirectiveModule} from '../../../directives/custom-directive/custom-directive.module';

const routes: Routes = [
  { path: 'reports', component: ReportsComponent,canActivate : [AuthGuard,ValidateGuard],
    data: {
        reportURL : 'addUser',
        permissionId:['UserManagement_SearchUpdateUser']
    }
  },
  { path: 'update/:id', component: UpdateComponent,canActivate : [AuthGuard,ValidateGuard], 
    resolve:{
        data: EditUserResolverService,
    },
    data: {
        reportType: 'edit',
        permissionId:['UserManagement_SearchUpdateUser']
    }
  }
];

@NgModule({
  declarations: [ReportsComponent, UpdateComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    DateRangePickerModule,
    DatePickerModule,
    NgxPaginationModule,
    TooltipModule,
    CustomDirectiveModule
  ]
})
export class UpdateUserModule { }