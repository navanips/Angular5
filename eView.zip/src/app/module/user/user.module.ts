import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertModule } from 'ngx-bootstrap';
import { AuthGuard } from '../../guards/auth.guard';
import { ValidateGuard } from '../../guards/validate.guard';
import { CanDeactivateGuard } from '../../guards/can-deactivate.guard';
import { FeatureToggleGuard } from '../../guards/feature-toggle-guard.guard';
import {CustomDirectiveModule} from '../../directives/custom-directive/custom-directive.module';

const routes: Routes = [
  { path: 'create', component:CreateUserComponent, canActivate: [AuthGuard, ValidateGuard, FeatureToggleGuard], canDeactivate: [CanDeactivateGuard], data:{permissionId:['UserManagement_CreateNewUser'], featureToggleKey: 'createUser'}},
  { path: 'update-user', loadChildren: './update-user/update-user.module#UpdateUserModule', canActivate: [AuthGuard, ValidateGuard, FeatureToggleGuard], data:{permissionId:['UserManagement_SearchUpdateUser'], featureToggleKey: 'manageUser'}},
  { path: 'edit', component:CreateUserComponent, canActivate: [AuthGuard, ValidateGuard, FeatureToggleGuard], data:{permissionId:['UserManagement_SearchUpdateUser'], featureToggleKey: 'editUser'}},
  { path: 'updateapp', loadChildren: './update-app/update-app.module#UpdateAppModule', canActivate: [AuthGuard, ValidateGuard, FeatureToggleGuard], data:{permissionId:[''], featureToggleKey: 'updateApps'}},
  { path: 'change-password', component: ChangePasswordComponent, canActivate: [AuthGuard, ValidateGuard, FeatureToggleGuard], data:{permissionId:['default'], featureToggleKey: 'changePassword'}},
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    AlertModule.forRoot(),
    CustomDirectiveModule
  ],
  declarations: [ChangePasswordComponent, CreateUserComponent]
})
export class UserModule { }
