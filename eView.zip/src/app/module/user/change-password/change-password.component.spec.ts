import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { ChangePasswordComponent } from './change-password.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfiguration } from '../../../app-configuration';
import { DebugElement } from '@angular/core';
import { AlertModule } from 'ngx-bootstrap';

describe('ChangePasswordComponent', () => {
  let component: ChangePasswordComponent;
  let fixture: ComponentFixture<ChangePasswordComponent>;
  let de: DebugElement;
  let el:HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangePasswordComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        AlertModule
      ], 
      providers: [AppConfiguration]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangePasswordComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('form'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set submitted to true',async(() =>{
    component.onSubmit();
    expect(component.submitted).toBeTruthy();
  }));

  it('should call the onsubmit method',async(() => {
    fixture.detectChanges();
    spyOn(component,'onSubmit');
    el = fixture.debugElement.query(By.css('button')).nativeElement;
    el.click();
    expect(component.onSubmit).toHaveBeenCalledTimes(1);
  }));
  
  it('form should be invalid',(() => {
    component.changePasswordForm.controls['Password'].setValue('');
    component.changePasswordForm.controls['ConfirmPassword'].setValue('');
    component.changePasswordForm.controls['oldPassword'].setValue('');
    expect(component.changePasswordForm.valid).toBeFalsy();
  }));
  
  it('form should be valid',(() => {
    component.changePasswordForm.controls['Password'].setValue('test1234');
    component.changePasswordForm.controls['ConfirmPassword'].setValue('test1234');
    component.changePasswordForm.controls['oldPassword'].setValue('test12345');

    let pwd = component.changePasswordForm.controls['Password'].value;
    let cpwd = component.changePasswordForm.controls['ConfirmPassword'].value;
    let opwd = component.changePasswordForm.controls['oldPassword'].value;

    expect(pwd).toEqual(cpwd);
    expect(pwd).not.toEqual(opwd);
    expect(pwd && cpwd && opwd).toMatch("(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)");
    expect(component.changePasswordForm.valid).toBeTruthy();
  }));

});
