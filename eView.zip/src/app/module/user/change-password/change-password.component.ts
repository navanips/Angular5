import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../../service/user/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import * as $ from 'jquery';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  changePasswordForm: FormGroup;
  submitted = false;
  title:boolean;
  submittedNewPwd = false;
  submittedCNewPwd = false;
  submittedOldPwd = false;
  passwordResetFlag;
  Cpwd : Boolean;
  userId = (sessionStorage.getItem('userDetails'))?JSON.parse(sessionStorage.getItem('userDetails')).userName:'';
  resultData: any;
  public alerts: any[] = [];
  currPwdInvalid = false;
  PWDInvalid = false;
  afterSubmit = false;
  constructor(private router:Router,private UserService:UserService, private route: ActivatedRoute,private titleService: Title) { 
    if(JSON.parse(sessionStorage.getItem('userDetails'))) {
      this.passwordResetFlag = JSON.parse(sessionStorage.getItem('userDetails')).passwordInforce;
      if(this.passwordResetFlag.toLowerCase() == 'true') {
        this.title = true;
        this.titleService.setTitle("Reset password | eView - MetLife");   
      } else {
        this.title = false;
        this.titleService.setTitle("Change password | eView - MetLife"); 
      }    
    }
  }

  ngOnInit() {
    this.changePasswordForm = new FormGroup({
      Password: new FormControl('',[Validators.required,Validators.minLength(8),Validators.pattern("(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)")]),
      ConfirmPassword: new FormControl('',[Validators.required,Validators.minLength(8),Validators.pattern("(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)")]),
      oldPassword: new FormControl('',[Validators.required])
    });
    this.changePasswordForm.valueChanges.subscribe(() => {
      this.alerts = [];
    });
    this.focusByDefault();
  }

  focusByDefault(){
    $(document).ready(function(){
      setTimeout(() => {
        $('#currentpassword').focus();
      },100);
    });
  }

  get f() { return this.changePasswordForm.controls; }

  onSubmit() {
    this.submitted = true;
    this.alerts=[];
    this.checkPwd();
    if (this.changePasswordForm.valid && this.currPwdInvalid == false && this.PWDInvalid == false) {
      let dataObj = '/'+this.userId+'/reset';
      let submitObj = {
        userId : this.userId,
        oldPassword: btoa(this.changePasswordForm.value.oldPassword),
        newPassword: btoa(this.changePasswordForm.value.Password)
      }
      
      this.UserService.changePassword(dataObj,submitObj).subscribe(data => {
        this.resultData = data;
        if(this.resultData.response == 'Success')
        {
          let userDetails = JSON.parse(sessionStorage.getItem('userDetails'));
          userDetails.passwordInforce = 'FALSE';
          sessionStorage.setItem('userDetails',JSON.stringify(userDetails));
          $('#originalLogout').show();
          $('#dummyLogout').hide();
         /* $('#submittedModal').show();*/
          // $(".beforesubmit").hide();
          // $(".aftersubmit").show();
          this.afterSubmit = true;
          this.changePasswordForm.reset();
          this.submitted = false;
          this.currPwdInvalid = false;
          this.PWDInvalid = false;
        }else{
          if(this.resultData.message == 'Current password is not valid.') {
            this.currPwdInvalid = true;
          } else if(this.resultData.message == 'Password must not be the same as the User ID.') {
            this.PWDInvalid = true;
          }  
          else {
            this.alerts=[{
              "type":'danger',
              "msg":this.resultData.message,
              "timeout":30000
            }];
          }
        }
      },
      err => {
        this.alerts=[{
          "type":'danger',
          "msg":'Something went wrong. Please try again later',
          "timeout":30000
        }];
      });
    }
  } 
  makefalse(val) {
    if(val == '1') {
      this.currPwdInvalid=false;
    } else {
      this.PWDInvalid = false;
    }
  }
  checkPwd()
  {
    let pwd = this.changePasswordForm.value.Password;
    let ConfirmPassword = this.changePasswordForm.value.ConfirmPassword;
    let oldpwd = this.changePasswordForm.value.oldPassword;
    if(oldpwd != pwd)
    {
      if(this.changePasswordForm.controls['Password'].getError('pwd')) {
        this.changePasswordForm.controls['Password'].setErrors(null) 
      }    
    }
    if(oldpwd == pwd)
    {
      if(this.changePasswordForm.controls['Password'].errors == null)
      {
        this.changePasswordForm.controls['Password'].setErrors({'pwd':true})
      }      
    }
    else
    {
      if(ConfirmPassword != pwd)
      {
        if(this.f.ConfirmPassword.errors == null)
        {
          this.changePasswordForm.controls['ConfirmPassword'].setErrors({'cfpwd':true})
        }    
      }
      else
      {
        if(this.changePasswordForm.controls['ConfirmPassword'].getError('cfpwd'))
        {
          this.changePasswordForm.controls['ConfirmPassword'].setErrors(null)
        }      
      }
    }
  }
}
