import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { BrowserModule, By } from '@angular/platform-browser';
import { CreateUserComponent } from './create-user.component';
import { RestApiService } from '../../../service/rest-api.service';
import { DebugElement } from '@angular/core';
import { AlertModule } from 'ngx-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppConfiguration } from '../../../app-configuration';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FlashMessagesService } from 'angular2-flash-messages';
import {
  HttpModule,
  Http,
  Response,
  ResponseOptions,
  XHRBackend
} from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { EmailValidator } from '@angular/forms';

describe('CreateUserComponent', () => {
  let component: CreateUserComponent;
  let fixture: ComponentFixture<CreateUserComponent>;
  let de: DebugElement;
  let el:HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateUserComponent ],
      providers : [ 
        RestApiService,
        AppConfiguration,
        { provide: XHRBackend, useClass: MockBackend },
        FlashMessagesService
      ],
      imports: [
        AlertModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        HttpClientTestingModule,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('alphabhets only',(() => {
    const fName = fixture.debugElement.query(By.css('#fName'));
    fName.nativeElement.value = "testtest";
    expect(fName.nativeElement.value.length).not.toBeGreaterThan(20);

    const lName = fixture.debugElement.query(By.css('#lName'));
    lName.nativeElement.value = "testtest";
    expect(lName.nativeElement.value.length).not.toBeGreaterThan(20);

    expect(fName.nativeElement.value).not.toContain(Number);
    expect(lName.nativeElement.value).not.toContain(Number);
  }));

  it('Numbers only',(() => {
    const mobno = fixture.debugElement.query(By.css('#MobNo'));
    mobno.nativeElement.value = "0123456789";
    expect(mobno.nativeElement.value.length).not.toBeGreaterThan(10);
    expect(mobno.nativeElement.value).toMatch(/^[0-9]+$/);

    const workno = fixture.debugElement.query(By.css('#WorkNo'));
    workno.nativeElement.value = "0123456789";
    expect(workno.nativeElement.value.length).not.toBeGreaterThan(10);
    expect(workno.nativeElement.value).toMatch(/^[0-9]+$/);    
  }));

  it('Email Validation',(() => {
    const Email = fixture.debugElement.query(By.css('#emailId'));
    Email.nativeElement.value = "test@test.com";
    expect(Email.nativeElement.value.length).not.toBeGreaterThan(50);
  }));

  it('UserId Validation',(() => {
    const userId = fixture.debugElement.query(By.css('#userId'));
    userId.nativeElement.value = "test1234";
    expect(userId.nativeElement.value.length).not.toBeGreaterThan(40);
    expect(userId.nativeElement.value).toMatch(/^[A-Za-z0-9]+$/);
  }));

  it('should set submitted to true',async(() =>{
    component.onSubmit();
    expect(component.submitted).toBeTruthy();
  }));
  
  it('should call the onsubmit method',async(() => {
    fixture.detectChanges();
    spyOn(component,'onSubmit');
    el = fixture.debugElement.query(By.css('#submitBtn')).nativeElement;
    el.click();
    expect(component.onSubmit).toHaveBeenCalledTimes(1);
  }));

  it('should return an Observable<Array<Usertype List>>', inject([RestApiService, XHRBackend], (api, mockBackend) => {
    const mockResponse = {
      data: [
        "METLIFE INTERNAL",
        "FUND ADMINISTRATOR",
        "TRUSTEE",
        "BROKER"
      ]
    };
    mockBackend.connections.subscribe((connection) => {
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(mockResponse)
      })));
    });

    api.get().subscribe((usertype) => {
      expect(usertype.length).toBe(4);
      expect(usertype[0]).toEqual('METLIFE INTERNAL');
      expect(usertype[1]).toEqual('FUND ADMINISTRATOR');
      expect(usertype[2]).toEqual('TRUSTEE');
      expect(usertype[3]).toEqual('BROKER');
    });

  }));

  // it('should return an Observable<Array<Company List>>', inject([RestApiService, XHRBackend], (api, mockBackend) => {
  //   const mockResponse = {
  //     data: [
  //       {companyCode:'DIRV',companyName: 'Test1'},
  //       {companyCode:'DIRQ',companyName: 'Test2'}
  //     ]
  //   };
  //   mockBackend.connections.subscribe((connection) => {
  //     connection.mockRespond(new Response(new ResponseOptions({
  //       body: JSON.stringify(mockResponse)
  //     })));
  //   });
  //   api.get().subscribe((Company) => {
  //     expect(Company.length).toBe(2);
  //   });
  // }));

  // it('should return an Observable<Array<application List>>', inject([RestApiService, XHRBackend], (api, mockBackend) => {
  //   const mockResponse = {
  //     data: [
  //       {
  //           applicationName: "Claims",
  //           modules: [
  //               {
  //                   moduleName: "Claims Status Report",
  //                   metRoleName: "Claims_Claims Status Report"
  //               }
  //           ]
  //       }
  //   ]
  //   };
  //   mockBackend.connections.subscribe((connection) => {
  //     connection.mockRespond(new Response(new ResponseOptions({
  //       body: JSON.stringify(mockResponse)
  //     })));
  //   });
  //   api.get().subscribe((application) => {
  //     expect(application.length).toBe(1);
  //   });
  // }));

  // it('should return an Observable<Array<fund List>>', inject([RestApiService, XHRBackend], (api, mockBackend) => {
  //   const mockResponse = {
  //     data: {    
  //       Direct_FundList: [{
  //           fundCode: "AXXXXXXXXX",
  //           fundName: "AXXXXXXXXX"
  //       }],
  //       Group_FundList: [{
  //         fundCode: "AXXXXXXXXX",
  //         fundName: "AXXXXXXXXX"
  //       }],
  //       CallCentre_FundList: [{
  //         fundCode: "CITI Life",
  //         fundName: "CITI Life"
  //       }]
  //     }
  //   };
  //   mockBackend.connections.subscribe((connection) => {
  //     connection.mockRespond(new Response(new ResponseOptions({
  //       body: JSON.stringify(mockResponse)
  //     })));
  //   });
  //   api.get().subscribe((fund) => {
  //     expect(fund.length).toBe(1);
  //   });
  // }));

});
