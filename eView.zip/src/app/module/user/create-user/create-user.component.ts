import { Component, OnInit, HostListener } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormBuilder,AbstractControl } from '@angular/forms';
import { AppConfiguration } from '../../../app-configuration';
import { Router } from '@angular/router';
import { RestApiService } from '../../../service/rest-api.service';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalComponent } from '../../../layout/ngb-modal/ngb-modal.component';
import { FlashMessageService } from '../../../service/flash-message/flash-message.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  createUser: FormGroup;
  submitted = false;
  fundList : any;
  userType : any;
  CompanyList : any;
  appDetails : any;
  appModule = [{
    modules : []
  }];
  isCustomIDFlag = false;
  arr1Selected = [];
  arr2Selected = [];
  refArrObj = [];
  selectedFundsArray = [];
  fundKeys = [];
  business = '';
  fnameErr = false;
  lnameErr = false;
  compAccess = false;
  postFund = [];
  FNames = [];
  selectedFNames = [];
  selectedApp='';
  selectedAppID:any;
  public alerts: any[] = [];
  SubmitObj = {
    firstName:'',
    surName:'',
    userId:'',
    alteredUserId:'',
    userType:'',
    emailId:'',
    companyName:'',
    workNumber:'',
    mobileNumber:'',
    funds:[],
    applicationAccess:[]
  };
  userAlreadyExists = false;
  isDirty: boolean = false;
  roles :any;
  selectedMainApp:any;
  selectedMainAppRef:any;
  @HostListener('window:beforeunload', ['$event'])
  doSomething($event) {
    if(this.isDirty) {
     $event.returnValue='Changes you made may not be saved.';
    }
  }
  constructor(private conf: AppConfiguration,private router: Router,private api:RestApiService,private fb: FormBuilder, private ngbModal: NgbModal, private flashErrorMsg: FlashMessageService) { 
    if(sessionStorage.getItem('userDetails')) {
      this.roles = JSON.parse(sessionStorage.getItem('userDetails')).roles.join();
    }
    this.getFund();
    this.getuserType();
    this.getCompanies();
    this.getAppList();
  }

  ngOnInit() {
    this.selectedAppID = [];
    this.flashErrorMsg.hideErrorMessage();
    this.createUser = this.fb.group({
      userDetails : this.fb.group({
        fName : new FormControl('', [Validators.required]),
        lName : new FormControl('', [Validators.required]),
        userId : new FormControl('', [Validators.required]),
        userType : new FormControl('', [Validators.required]),
        EmailId : new FormControl('', [Validators.required,Validators.pattern(/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)]),
        companyName : new FormControl('', [Validators.required]),
        workNo : new FormControl('', []),
        MobNo : new FormControl('', [])
      }),
      companyAccess : this.fb.group({
        businessName : new FormControl('', []),
      }),
      appDetails : this.fb.group({
        ApplicationName : new FormControl('', []),
      }),
    });
    this.onChanges();
  }

  BooleanConverter(value: any) {
    return value;
  }

  canDeactivate(): boolean {
    if (!this.isDirty || (!sessionStorage.getItem('userToken') && !sessionStorage.getItem('userDetails'))) return true;
    else {
      let ngbModalOptions: NgbModalOptions = {
        backdrop : 'static',
        keyboard : false
      };
      const m = this.ngbModal.open(NgbModalComponent, ngbModalOptions);
      m.componentInstance.Title = 'Leave site?';
      m.componentInstance.confMessage = 'Changes you made may not be saved.';
      let res = this.BooleanConverter(m.result);
      return res;
    } 
  }

  onChanges() {
    this.createUser.valueChanges.subscribe(form => {
        if (this.createUser.dirty){
          this.isDirty = true;
        }
      });
  }

  get f() { return this.createUser.controls; }

  get userDetails(): any { return this.createUser.get('userDetails'); }

  get companyAccess(): any { return this.createUser.get('companyAccess'); }

  get appAccess(): any { return this.createUser.get('appDetails'); }

  getFund() {
    this.api.get(this.conf.URLS.createUser.fundList).subscribe(res => {
      this.fundList = res;
      this.fundKeys = Object.keys(this.fundList);
      if(this.roles.indexOf('metlife internal') == -1) { 
        this.fundKeys.filter(x => this.FNames = this.FNames.concat(this.fundList[x]) );
      }
    });
  }

  getuserType() {
    this.userType = [{key:'METLIFE INTERNAL',value:'Internal'},
    {key:'FUND ADMINISTRATOR',value:'Fund Administrator'},
    {key:'TRUSTEE',value:'Trustee'},
    {key:'BROKER',value:'Broker'}];
    let rol = this.roles;
    let selectedUtype;
    if(this.roles.indexOf('metlife internal') == -1) {
      this.userType.filter(function(x){
        if(rol.indexOf(x.key.toLowerCase()) > -1) {
          selectedUtype = x.key;
        }
      });
      this.SubmitObj.userType = selectedUtype;
      
    }
    // this.api.get(this.conf.URLS.createUser.userType).subscribe(data => {
    //   this.userType = data;
    // });
  }

  getCompanies() {
    this.api.get(this.conf.URLS.createUser.CompanyList).subscribe(result => {
      this.CompanyList = result;
      if(this.roles.indexOf('metlife internal') == -1) {
        this.SubmitObj.companyName = this.CompanyList[0].companyCode;
      }
    });
  }

  resetAppDetails() {
    this.selectedMainApp = [];
    this.selectedMainAppRef = [];
    this.appDetails.forEach((item) => {
      this.selectedMainApp.push(item.applicationName);
      this.selectedMainAppRef.push({
        applicationName: item.applicationName,
        modules:[]
      });
    }); 
  }

  getAppList() {
    this.api.get(this.conf.URLS.createUser.AppList).subscribe(result => {
      this.appDetails = result;   
      let i = 0;
      this.appDetails.filter(x => x.modules.filter(function(y,index) {
        if(y.metRoleName == "eQuery_DataExport") {
          if(i == 1) { 
            x.modules.splice(index,1)
          }
          i++;
        }
      }));      
      this.resetAppDetails();  
    });    
  }

  getFNames(event) {
    if(event.target.value != '') {
      this.FNames = (this.fundList[event.target.value].length > 0)?this.fundList[event.target.value]:[];
    } else {
      this.FNames = [];
    }
  }
  
  changeModule(event) {
    if(event.target.value != '') {
      this.appModule = this.appDetails.filter(x => x.applicationName == event.target.value);
    } else {
      // this.appModule = [];
      this.appModule = [{
        modules : []
      }];
    }
  }

  movetoRight(item, mainApp){
    item.refMainApp = mainApp;
    this.refArrObj.push(item);
    this.selectedAppID.push(item.moduleId);
    
    let appIndex = this.selectedMainApp.indexOf(mainApp);
    this.selectedMainAppRef[appIndex].modules.push(item);
  }

  movetoLeft(item){
    let currentModuleID = item.moduleId;
    let deleteIndex = this.selectedAppID.indexOf(currentModuleID);
    this.selectedAppID.splice(deleteIndex , 1);
    this.refArrObj.splice(deleteIndex , 1);
   
    let appIndex = this.selectedMainApp.indexOf(item.refMainApp);
    let moduleDeleteIndex;
    this.selectedMainAppRef[appIndex].modules.forEach((curerntModule, index) => {
      let moduleID = curerntModule.moduleId;
      if(moduleID == currentModuleID){
        moduleDeleteIndex = index;
      }
    });
    this.selectedMainAppRef[appIndex].modules.splice(moduleDeleteIndex, 1);
  }

  movetoLeftFund(item){
    let currentfundCode = item.fundCode;
    let deleteIndex = this.selectedFNames.indexOf(currentfundCode);
    this.selectedFNames.splice(deleteIndex , 1);
    this.selectedFundsArray.splice(deleteIndex , 1);    
  } 

  movetoRightFund(item){
    this.selectedFundsArray.push(item);
    this.selectedFNames.push(item.fundCode);    
  }

  scrollToTop() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  }
  
  onSubmit() {
    let focusArr = $('input,textarea,select').filter('[required]:visible');
    let check = false;
    var ref = this;
    focusArr.each(function(index) { 
        let name = focusArr[index].attributes['formControlName'].value;
        if(name != 'ApplicationName' && ref.userDetails.controls[name].valid == false && check == false) {
          focusArr[index].focus();
          check = true;
        }
    });
    if(check == false && this.selectedAppID.length == 0) {
      $('#ApplicationName').focus();
    }    
    this.submitted = true;
    this.SubmitObj.funds = this.selectedFundsArray;
    this.SubmitObj.applicationAccess = this.selectedMainAppRef;
    if (this.createUser.valid && this.fnameErr === false && this.lnameErr == false && this.selectedAppID.length > 0 && this.userAlreadyExists == false) {
      this.api.add(this.conf.URLS.createUser.addUser,this.SubmitObj).subscribe(response => {
        if (response) {
          $('#submittedModal').show();
          this.resetForm();
         } else {
          this.alerts=[{
            'type':'danger',
            'msg':'Submit Fails!',
            'timeout':30000
          }];
        }
      },err => {
        this.resetForm();
        this.flashErrorMsg.showErrorMessage();
      });
    }
  }
  hideModal() {
    this.isDirty = false;
    $('#submittedModal').hide();
    this.scrollToTop();
  }
  resetForm(){
    let selectedUserType = this.SubmitObj.userType;
    this.createUser.reset();
    this.isCustomIDFlag = false;
    this.compAccess = false;
    this.submitted = false;
    this.userAlreadyExists = false;
    this.selectedFNames = [];
    this.arr1Selected = [];
    this.arr2Selected = [];
    this.FNames = [];
    this.appModule = [{
      modules : []
    }];
    this.SubmitObj.firstName = '';
    this.SubmitObj.surName = '';
    this.SubmitObj.userType = '';
    this.SubmitObj.companyName = '';
    this.SubmitObj.funds = [];
    this.refArrObj = [];
    this.selectedAppID = [];
    this.selectedFundsArray = [];
    this.business = '';
    this.selectedApp = '';
    this.userDetails.patchValue({
      userType : '',
      companyName : ''
    });
    this.companyAccess.patchValue({
      businessName : '',
    });
    this.appAccess.patchValue({
      ApplicationName : ''
    });
    this.fnameErr = false;
    this.lnameErr = false;
    $('#selectedMod option,#selectMod option').remove();
    $('#fundSelectedMod option,#fundSelectMod option').remove();
    this.SubmitObj.applicationAccess = [];
    this.resetAppDetails();
    if (this.roles.indexOf('metlife internal') == -1) {
      this.fundKeys.filter(x => this.FNames = this.FNames.concat(this.fundList[x]));
      this.userDetails.patchValue({
        userType: selectedUserType,
        companyName: this.CompanyList[0].companyCode
      });
    }
  }
  generateAndValidateUID(event) {
    if(this.SubmitObj.firstName != '' && this.SubmitObj.surName != '') {
      let str = this.SubmitObj.firstName.replace(/[-' ]/g, '');
      let lastname = this.SubmitObj.surName.replace(/[-' ]/g, '');
      let val = str.charAt(0) + lastname;
      if(this.isCustomIDFlag == false) {
        this.validateUID(val);
      }
    }
  }
  validateUID(val) {
    if(val) {
      this.api.get(this.conf.URLS.createUser.addUser+'/'+val).subscribe((reportsObj: any) => {
        
        if(reportsObj.response && reportsObj.response == 'Failure') {
          this.isCustomIDFlag = true;
          if(this.SubmitObj.userId){
          }else{
            this.SubmitObj.userId = val.replace(/[-' ]/g, '');
          }
          this.userAlreadyExists = false;
        } else {
          if(this.SubmitObj.userId) {
            this.userAlreadyExists = true;
          }
        }
    });
    }
     
    }
  
  setCustomUserID(value) {
    if(value) {
      this.isCustomIDFlag = true;
    }
  }

  checkAlpha(event,type) {
    if (/[a-zA-Z]/.test(event.target.value) == false) {
      if(type=='fname') {
        this.fnameErr=true;
      } else if(type='lname') {
        this.lnameErr=true;
      }
    } else {
      if(type=='fname') {
        this.fnameErr=false;
      } else if(type='lname') {
        this.lnameErr=false;
      }
    }
  }
}
