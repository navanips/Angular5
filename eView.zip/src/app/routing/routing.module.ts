import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes, Router, NavigationStart, NavigationEnd, PreloadAllModules } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertModule } from 'ngx-bootstrap';

import { AuthGuard } from '../guards/auth.guard';
import { FeatureToggleGuard } from '../guards/feature-toggle-guard.guard';
import { ValidateGuard } from '../guards/validate.guard';
import { CanDeactivateGuard } from '../guards/can-deactivate.guard';

import { LoginComponent } from '../module/login/login.component';
import { DashboardComponent } from '../module/dashboard/dashboard.component';
import { EapplyCorporateComponent } from '../module/eapply-corporate/eapply-corporate.component';
import { SteadfastComponent } from '../module/steadfast/steadfast.component';
import { LayoutComponent } from '../layout/layout.component';
import { HeaderComponent } from '../layout/header/header.component';
import { FooterComponent } from '../layout/footer/footer.component';
import { SidebarComponent } from '../layout/sidebar/sidebar.component';
import { ModalComponent } from '../layout/modal/modal.component';
import { ForgetPasswordComponent } from '../module/forget-password/forget-password.component';
import { NotFoundComponent } from '../module/not-found/not-found.component';
import { LogoutComponent } from '../module/logout/logout.component';
import { SessionExpiredComponent } from '../module/session-expired/session-expired.component';
import { UnderConstructionComponent } from '../module/under-construction/under-construction.component';

import { RestApiService } from '../service/rest-api.service';
import { UserService } from '../service/user/user.service';
import { UwReportsService } from '../service/underwriting/uw-reports.service';
import { UwSearchService } from '../service/underwriting/uw-search.service';
import { ClaimSearchService } from '../service/claim/claim-search.service';
import { SharedDocumentService } from '../service/shared-document/shared-document.service';
import { ClaimReportsService } from '../service/claim/claim-reports.service';
import { ReportDetailsService } from '../service/underwriting/report-details.service';

import { SearchModel } from '../service/search-model';
import { UpdateUserModel } from '../service/user/update-user-model';
import { ClaimSearchModel } from '../service/claim/claim-search-model';
import { StatusSearchModel } from '../service/claim/status/status-search-model';
import { PaymentSearchModel } from '../service/claim/payment/payment-search-model';
import { SharedDocumentModel } from '../service/shared-document/shared-document-model';
import { CustomDirectiveModule } from '../directives/custom-directive/custom-directive.module';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'forgot-password', component: ForgetPasswordComponent },
  { path: 'session-expired', component: SessionExpiredComponent },
  { path: 'under-construction', component: UnderConstructionComponent, canActivate: [AuthGuard] },
  {
    path: '',
    component: LayoutComponent,
    children: [
      { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard, ValidateGuard], data: { permissionId: ['default'] } },
      { path: 'claims', loadChildren: '../module/claims/claims.module#ClaimsModule', canActivate: [AuthGuard, ValidateGuard], data: { permissionId: [''] } },
      { path: 'underwriting', loadChildren: '../module/underwriting/underwriting.module#UnderwritingModule', canActivate: [AuthGuard, ValidateGuard], data: { permissionId: [''] } },
      { path: 'eapply-corporate', component: EapplyCorporateComponent, canActivate: [AuthGuard, ValidateGuard, FeatureToggleGuard], data: { permissionId: ['EApply_Corporate','eApply_eApply'], featureToggleKey: 'eApplyCorporate' } },
      { path: 'users', loadChildren: '../module/user/user.module#UserModule', canActivate: [AuthGuard, ValidateGuard], data: { permissionId: [''] } },
      { path: 'steadfast', component: SteadfastComponent, canActivate: [AuthGuard, ValidateGuard, FeatureToggleGuard], data: { permissionId: ['Steadfast_Steadfast'], featureToggleKey: 'steadfast' } },
      { path: 'shared-documents', loadChildren: '../module/shared-document/shared-document.module#SharedDocumentModule', canActivate: [AuthGuard, ValidateGuard], data: { permissionId: [''] } },
      { path: '**', component: NotFoundComponent, data: { permissionId: [''] } },
    ]
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes,
      {
        preloadingStrategy: PreloadAllModules
      }
    ),
    FormsModule,
    ReactiveFormsModule,
    AlertModule.forRoot(),
    CustomDirectiveModule
  ],
  declarations: [
    LoginComponent,
    DashboardComponent,
    LayoutComponent,
    SteadfastComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    ModalComponent,
    ForgetPasswordComponent,
    NotFoundComponent,
    LogoutComponent,
    UnderConstructionComponent,
    SessionExpiredComponent,
    EapplyCorporateComponent
  ],
  entryComponents: [
    ModalComponent
  ],
  providers: [
    AuthGuard,
    ValidateGuard,
    CanDeactivateGuard,
    FeatureToggleGuard,
    UwReportsService,
    UwSearchService,
    SearchModel,
    ReportDetailsService,
    ClaimSearchService,
    ClaimSearchModel,
    PaymentSearchModel,
    StatusSearchModel,
    SharedDocumentModel,
    UpdateUserModel,
    ClaimReportsService,
    SharedDocumentService,
    RestApiService,
    UserService
  ],
  exports: [RouterModule]
})

export class RoutingModule {
  vpView: any;

  // Subscribe to the Router URL changes.
  constructor(public router: Router) {
    // disabled app dynamics code to investigate ADRUM issue
    // this.router.events.subscribe(event => {
    //   if (event instanceof NavigationEnd) {
    //     this.vpView.markViewChangeEnd();
    //     this.vpView.markViewDOMLoaded();
    //     this.vpView.markXhrRequestsCompleted();
    //     this.vpView.markViewResourcesLoaded();
    //     this.vpView.end();
    //     ADRUM.report(this.vpView);

    //   } else if (event instanceof NavigationStart) {
    //     this.vpView = new ADRUM.events.VPageView();
    //     this.vpView.start();
    //     this.vpView.markViewChangeStart();
    //   }
    // });
  }
}