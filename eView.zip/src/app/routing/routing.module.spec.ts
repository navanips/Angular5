import { RoutingModule } from './routing.module';
import { TestBed } from '@angular/core/testing';

describe('RoutingModule', () => {
  let routingModule: RoutingModule;

  beforeEach(() => {
    // routingModule = new RoutingModule();
    const service: RoutingModule = TestBed.get(RoutingModule);
  });

  // it('should create an instance', () => {
  //   expect(routingModule).toBeTruthy();
  // });
});
