import { Injectable } from '@angular/core';
import { isArray } from 'util';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  menuItems: Array<any>;
  constructor() { 
    this.menuItems = [];
  }

  addMenu(data,permissions)
  {
    let permissionVal = permissions.split(",");
    data.forEach(item => {
        var clone = Object.assign({}, item);
        if(clone.submenu == undefined) {
          if(isArray(clone.permissionId)) {
            if(permissions.indexOf(clone.permissionId[0]) > -1 || permissions.indexOf(clone.permissionId[1]) > -1 || permissions.indexOf(clone.permissionId[2]) > -1) {
              this.menuItems.push(clone);
            }
          } else if(permissions.indexOf(clone.permissionId) > -1) {
            this.menuItems.push(clone);
          }          
        }
        else if(clone.submenu){
          let newarray = [];
          clone.submenu.forEach(element => {
           
            permissionVal.forEach(pid => {
                if(isArray(element.permissionId)) {
                  if(element.permissionId.indexOf(pid) > -1) {
                    newarray.push(element);
                  }
                } else {
                  if (element.permissionId == pid) {
                    newarray.push(element);
                  }
                }
              });
          });
          newarray = Array.from(new Set(newarray));
          clone.submenu = newarray;

          if (clone.submenu && clone.submenu.length > 0) {
              this.menuItems.push(clone);
          }
        }
    });
  }

  getMenu() {
    return this.menuItems;
  }

  resetMenu(){
    this.menuItems = [];
  }
}
