const Dashboard = {
    id : 'home',
    text: 'Home',
    link: '/dashboard',
    permissionId : 'default',
    logo: '',
    type: 'navBar'
};

const Claims = {
    id : 'claims',
    text: 'Claims',
    link: 'claims',
    permissionId : '',
    logo : 'assets/images/Claims_Icon_Menu.png',
    type: 'navBar',
    submenu : [
        {
            text: 'Submit new claim',
            link: '/claims/submit-claims',
            permissionId : ['eLodgement_SubmitClaim', 'Claims_SubmitNewClaim'],
            logo: '',
            type: 'navBar'
        },
        {
            text: 'Status report',
            link: '/claims/status/reports',
            permissionId : ['eQuery_ClaimsStatusRpt', 'Claims_ClaimsStatusRpt'],
            logo: '',
            type: 'navBar'
        },
        {
            text: 'Requirement report',
            link: '/claims/requirement/reports',
            permissionId : ['eQuery_ClaimsReqRpt', 'Claims_ClaimsReqRpt'],
            logo: '',
            type: 'navBar'
        },
        {
            text: 'SLA report',
            link: '/claims/sla/reports',
            permissionId : ['eQuery_ClaimsSLARpt', 'Claims_ClaimsSLARpt'],
            logo: '',
            type: 'navBar'
        },
        {
            text: 'Payment report',
            link: '/claims/payment/reports',
            permissionId : ['eQuery_ClaimsPaymentRpt', 'Claims_ClaimsPaymentRpt'],
            logo: '',
            type: 'navBar'
        },
        {
            text: 'Validate claim',
            link: '/claims/validateClaim/reports',
            permissionId : ['eClaims_ValidateClaim', 'Claims_ValidateClaim'],
            logo: '',
            type: 'navBar'
        }
    ]
};

const UnderWriting = {
    id : 'underwriting',
    text: 'Underwriting',
    link: 'underwriting',
    permissionId : '',
    logo : 'assets/images/UW_Icon_Menu.png',
    type: 'navBar',
    submenu : [
        {
            text: 'Submit new underwriting',
            link: '/underwriting/submit-new-underwriting',
            permissionId : ['eLodgement_SubmitUnderwriting', 'Underwriting_SubmitNewUnderwriting'],
            logo: '',
            type: 'navBar'
        },
        {
            text: 'Status report',
            link: '/underwriting/status/reports',
            permissionId : ['eQuery_UWStatusRpt', 'Underwriting_UWStatusRept'],
            logo: '',
            type: 'navBar'
        },
        {
            text: 'Requirement report',
            link: '/underwriting/requirement/reports',
            permissionId : ['eQuery_UWReqRpt', 'Underwriting_UWReqRept'],
            logo: '',
            type: 'navBar'
        },
        {
            text: 'SLA report',
            link: '/underwriting/sla/reports',
            permissionId : ['eQuery_UWSLARpt', 'Underwriting_UWSLARept'],
            logo: '',
            type: 'navBar'
        }
    ]
};

const eApplyCorporate = {
    id : 'eApplyCorporate',
    text: 'eApply',
    link: '/eapply-corporate',
    permissionId : ['EApply_Corporate', 'eApply_eApply'],
    logo: '',
    type: 'navBar'
};

const SharedDocuments = {
    id : 'shared',
    text: 'Shared documents',
    link: '/shared-documents/reports',
    permissionId : ['SharedDocuments_SearchDocuments', 'SharedDocuments_ManageDocuments', 'SharedDocuments_MemberFileUpload'],
    logo: '',
    type: 'navBar'
};

const SteadFast = {
    id : 'steadfast',
    text: 'Steadfast',
    link: '/steadfast',
    permissionId : 'Steadfast_Steadfast',
    logo: '',
    type: 'navBar'
};

const CreateUser = {
    id : 'createuser',
    text: 'Create a user',
    link: '/users/create',
    permissionId : 'UserManagement_CreateNewUser',
    logo: '',
    type: 'UserMenu'
};

const EditUser = {
    id : 'edituser',
    text: 'Manage users',
    link: '/users/update-user/reports',
    permissionId : 'UserManagement_SearchUpdateUser',
    logo: '',
    type: 'UserMenu'
};

const UpdateApp = {
    id : 'updateapp',
    text: 'Update application & modules',
    link: '/users/updateapp/list',
    permissionId : 'UserManagement_UpdateAppModules',
    logo: '',
    type: 'UserMenu'
};

export const menus = [
    Dashboard,
    Claims,
    UnderWriting,
    eApplyCorporate,
    SharedDocuments,
    SteadFast,
    CreateUser,
    EditUser,
    UpdateApp
];
