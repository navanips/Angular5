import { TestBed, inject } from '@angular/core/testing';

import { RestApiService } from './rest-api.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
describe('RestApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
	imports: [
        HttpClientTestingModule        
      ],
      providers: [RestApiService]
    });
  });

  it('should be created', inject([RestApiService], (service: RestApiService) => {
    expect(service).toBeTruthy();
  }));
});
