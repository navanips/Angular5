import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AppConfiguration } from '../../app-configuration';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private router: Router, private conf: AppConfiguration) { }
    login(loginInfo: any) {
        return this.http.post<any>(this.conf.URLS.loginAppURL, loginInfo)
            .pipe(map(responseData => {
                if (responseData && responseData.access_token) {
                    sessionStorage.setItem('userToken', responseData.access_token);
                }
                return responseData;
            }));
    }

    getUserDetails() {
        return this.http.get<any>(this.conf.URLS.userDetailsAppURL)
            .pipe(map(responseData => {
                if (responseData) {
                    sessionStorage.setItem('userDetails', JSON.stringify(responseData));
                    return responseData;
                }
        }));
    }

    generateTokenForForgotPassword(data: any) {
        return this.http.post<any>(this.conf.URLS.loginAppURL, data).pipe(map(responseData => {
                if (responseData && responseData.access_token) {
                    sessionStorage.setItem('forgotPasswordToken', responseData.access_token);
                }
                return responseData;
            }));
    }

    resetPassword(data: any) {
        return this.http.get<any>(this.conf.URLS.forgetPasswordAppURL + data)
            .pipe(map(responseData => {
                return responseData;
            }));
    }
    changePassword(url, data: any) {
        return this.http.post<any>(this.conf.URLS.forgetPasswordAppURL + url, data)
            .pipe(map(responseData => {
                return responseData;
            }));
    }

    checkExternalUser(){
        let currentUserRole = JSON.parse(sessionStorage.userDetails).roles;
        let internalUser = 'metlife internal';
        if(currentUserRole && currentUserRole.length > 0){
          let checkInternalUser = currentUserRole.indexOf(internalUser);          
          if(checkInternalUser >= 0){
            return false;
          }else{
            return true;
          }
        }else{
          return true;
        }
      }
}
