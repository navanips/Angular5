import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { UpdateUserService } from './update-user.service';
import { AppConfiguration } from '../../app-configuration';
import { UpdateUserModel } from '../user/update-user-model';

describe('UpdateUserService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
    ],
    providers: [
      AppConfiguration,
      UpdateUserModel
    ]
  }));

  it('should be created', () => {
    const service: UpdateUserService = TestBed.get(UpdateUserService);
    expect(service).toBeTruthy();
  });
});
