import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { UpdateUserReportResolverService } from './update-user-report-resolver.service';
import { AppConfiguration } from '../../app-configuration';
import { UpdateUserModel } from '../user/update-user-model';

describe('UpdateUserReportResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
    ],
    providers: [
      AppConfiguration,
      UpdateUserModel
    ]    
  }));

  it('should be created', () => {
    const service: UpdateUserReportResolverService = TestBed.get(UpdateUserReportResolverService);
    expect(service).toBeTruthy();
  });
});
