import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { EditUserResolverService } from './edit-user-resolver.service';
import { AppConfiguration } from '../../app-configuration';

describe('EditUserResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
    ],
    providers: [
      AppConfiguration,
    ]  
  }));

  it('should be created', () => {
    const service: EditUserResolverService = TestBed.get(EditUserResolverService);
    expect(service).toBeTruthy();
  });
});
