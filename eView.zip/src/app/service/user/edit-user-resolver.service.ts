import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AppConfiguration } from '../../app-configuration';

@Injectable({
  providedIn: 'root'
})
export class EditUserResolverService implements Resolve<any> {

  constructor(private http: HttpClient, private appConfig: AppConfiguration) { }

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
     let userid = route.params.id;
     let detailsURL = this.appConfig.URLS.createUser.addUser+'/'+userid;
     //let detailsURL = this.appConfig.URLS.createUser.updateuser;
     return this.http.get(detailsURL).pipe(map(response => {
       return response;
     })
     , catchError((error: any) => Observable.throw(error.json().error || 'Server error')));
  }

}
