import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AppConfiguration } from '../../app-configuration';
import * as moment from 'moment';
import { UpdateUserModel } from '../user/update-user-model';

@Injectable({
  providedIn: 'root'
})
export class UpdateUserService {

  constructor(private http: HttpClient, private appConfig: AppConfiguration,private data: UpdateUserModel) { }

  searchReports(reportPage) {
    const url = this.formQueryStr(this.data.searchModal, reportPage, 'report');
    return this.http.get(url).pipe(map(response => {
      return response;
    })
      , catchError((error: any) => Observable.throw(error.json().error || 'Server error')));
  }

  searchUserExport(reportType) {
    //this.data.searchModal.metaData['reportLimit'] = '1000';
    const url = this.formQueryStr(this.data.searchModal, reportType, 'export');
    return this.http.get(url, {responseType: 'blob'});
  }

  formQueryStr(queryModal: any, urlKey, reportType) {
    const searchArray = [];
    Object.keys(queryModal).forEach(key => {
      if (queryModal[key] && key !== 'metaData') {
        if (key === 'effectiveDate') {
          searchArray.push(`${key}>='${moment(queryModal[key][0]).format('YYYY-MM-DD HH:mm:ss')}'`);
          searchArray.push(`${key}<='${moment(queryModal[key][1]).format('YYYY-MM-DD 29:59:59')}'`);
        }
        else {
          if (queryModal[key] != 'All') searchArray.push(`${key}=="${queryModal[key]}"`);
        }
      }
    });
    const params: any = searchArray.join(';');
    let limit, offset;
    if(reportType == 'report'){
      limit = queryModal.metaData.reportLimit;
      offset = queryModal.metaData.reportOffset;
    }else if(reportType == 'export'){
      limit = 1000;
      offset = 0;
    }
    const qString = '&limit=' + limit + '&offset=' + offset + '&orderby=' + queryModal.metaData.orderby + '&order=' + queryModal.metaData.order;
    const queryUrl = `${this.appConfig.URLS.createUser[urlKey]}?searchkey=${params}` + qString;
    const encodedURL = encodeURI(queryUrl);
    return encodedURL;
  }
}
