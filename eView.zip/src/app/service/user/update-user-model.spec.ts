import { UpdateUserModel } from './update-user-model';

describe('UpdateUserModel', () => {
  it('should create an instance', () => {
    expect(new UpdateUserModel()).toBeTruthy();
  });
});
