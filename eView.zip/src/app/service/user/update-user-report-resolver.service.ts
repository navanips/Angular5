import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { UpdateUserService } from './update-user.service';

@Injectable({
  providedIn: 'root'
})
export class UpdateUserReportResolverService implements Resolve<any>{

  constructor(private updateuserSer: UpdateUserService) { }

   resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    const reportURL = route.data['reportURL'];
    return this.updateuserSer.searchReports(reportURL);
  }
}
