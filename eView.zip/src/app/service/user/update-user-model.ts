export class UpdateUserModel {
    searchModal: any;
    resetModel: any;
    constructor() {
        if(sessionStorage.getItem('reportData') && (sessionStorage.getItem('reportName') == 'UPDATEUSER')) {
            let reportData = JSON.parse(sessionStorage.getItem('reportData'));
            this.searchModal = reportData;
        } else {
            this.searchModal =  {
                firstName: '',
                surName: '',
                userId: '',
                status: '',
                userType:'',
                companyname:'',
                fundcode:'',
                metaData: {
                    reportLimit: '20',
                    reportOffset: '0',
                    orderby: 'companyname',
                    order: 'asc'
                }
            };
        }
        this.resetModel = {
        firstName: '',
        surName: '',
        userId: '',
        status: '',
        userType:'',
        companyname:'',
        fundcode:'',
        metaData: {
            reportLimit: '20',
            reportOffset: '0',
            orderby: 'companyname',
            order: 'asc'
        }
        };
     }
    resetSearchModel() {
        this.searchModal =  Object.assign({}, this.resetModel);
    }
}
