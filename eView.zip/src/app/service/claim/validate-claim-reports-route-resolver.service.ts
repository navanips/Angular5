import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { ClaimReportsService } from './claim-reports.service';

@Injectable({
  providedIn: 'root'
})
export class ValidateClaimReportsRouteResolverService {

  constructor(private claimReportService: ClaimReportsService) { }

   resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    const reportURL = route.data['reportURL'];
    return this.claimReportService.ValiadtesearchReports(reportURL);
  }
}
