import { ClaimSearchModel } from './claim-search-model';

describe('ClaimSearchModel', () => {
  it('should create an instance', () => {
    expect(new ClaimSearchModel()).toBeTruthy();
  });
});
