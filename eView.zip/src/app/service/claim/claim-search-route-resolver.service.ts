import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { ClaimSearchService } from './claim-search.service';

@Injectable({
  providedIn: 'root'
})
export class ClaimSearchRouteResolverService implements Resolve<any> {

 constructor(private claimsearchRe: ClaimSearchService) { }

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    const fundList = this.claimsearchRe.getFunds();
    const validatefundList = this.claimsearchRe.getValidateFunds();
    const claimTypes = this.claimsearchRe.getClaimtypes();
    const claimStatus = this.claimsearchRe.getClaimsatatus();
    const data = {fundList: fundList,claimTypes: claimTypes , claimStatus: claimStatus,validatefundList: validatefundList};
    return of(data);
  }
}
