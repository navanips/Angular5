export class ClaimSearchModel {
    searchModal: any;
    resetModel: any;
    valiadtemodel:any;
    resetvalidemodel:any;
    lastYearDate:any;
    finalDate:any;
    constructor() {

    this.lastYearDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    this.finalDate = new Date(this.lastYearDate.setDate(this.lastYearDate.getDate()+1));
    if(sessionStorage.getItem('reportData') && (sessionStorage.getItem('reportName') == 'CLREQ' || sessionStorage.getItem('reportName') == 'CLSLA' || sessionStorage.getItem('reportName') == 'CLREQ')) {
      let reportData = JSON.parse(sessionStorage.getItem('reportData'));
      this.searchModal = reportData;
    } else {
        this.searchModal =  {
                clientReferenceNo:'',
                claimno:'',
                firstname:'',
                surname:'',
                fundname:'',
                memberdob:'',
                status:'',
                source:'',
                productType:'Group Life',
                claimType:'',
                assessor:'All',
                applicationdate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
                metaData: {
                  reportLimit: '20',
                  reportOffset: '0',
                  orderby: 'claimNo',
                  order: 'asc'
                },
        };
    }
    this.resetModel = {
        clientReferenceNo:'',
        claimno:'',
        firstname:'',
        surname:'',
        fundname:'',
        memberdob:'',
        status:'',
        source:'',
        productType:'Group Life',
        claimType:'',
        assessor:'All',
        applicationdate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
        metaData: {
          reportLimit: '20',
          reportOffset: '0',
          orderby: 'claimNo',
          order: 'asc'
        },
    };
    if(sessionStorage.getItem('reportData') && sessionStorage.getItem('reportName') == 'ValidateClaim') {
      let reportData = JSON.parse(sessionStorage.getItem('reportData'));
      this.valiadtemodel = reportData;
    } else {    
      this.valiadtemodel =  {
              clientReferenceNo:'',
              firstname:'',
              surname:'',
              fundname:'',
              memberdob:'',
              status:'',
              applicationdate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
              metaData: {
                reportLimit: '20',
                reportOffset: '0',
                orderby: 'credte',
                order: 'desc'
              },
      };
    }
    this.resetvalidemodel = {
        clientReferenceNo:'',
        firstname:'',
        surname:'',
        fundname:'',
        memberdob:'',
        status:'',
        applicationdate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
        metaData: {
          reportLimit: '20',
          reportOffset: '0',
          orderby: 'credte',
          order: 'desc'
        },
    };
  }

  resetSearchModel() {
    this.searchModal =  Object.assign({}, this.resetModel);
  }

  ValidteresetSearchModel() {
    this.valiadtemodel =  Object.assign({}, this.resetvalidemodel);
  }
}
