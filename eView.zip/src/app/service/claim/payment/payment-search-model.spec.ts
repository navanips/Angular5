import { PaymentSearchModel } from './payment-search-model';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfiguration } from '../../../app-configuration';

describe('PaymentSearchModel', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
      RouterTestingModule        
    ],    
    providers:[
      // UserService,
      AppConfiguration
    ]
  }));  
  it('should create an instance', () => {
    const service: PaymentSearchModel = TestBed.get(PaymentSearchModel);
    expect(service).toBeTruthy();
  });
});
