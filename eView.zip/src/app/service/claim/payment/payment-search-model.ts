import { Injectable } from '@angular/core';
import { UserService } from '../../../service/user/user.service';

@Injectable({
  providedIn: 'root'
})

export class PaymentSearchModel {
  searchModal: any;
  resetModel: any;
  lastYearDate: any;
  finalDate: any;
  constructor(private userService: UserService) {}

  generateModals() {
    let externalUser = this.userService.checkExternalUser();
    if (externalUser) {
      this.lastYearDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    } else {
      this.lastYearDate = new Date(new Date().setFullYear(new Date().getFullYear() - 2));
    }
    console.log(this.lastYearDate);
    this.finalDate = new Date(this.lastYearDate.setDate(this.lastYearDate.getDate() + 1));
    if (sessionStorage.getItem('reportData') && sessionStorage.getItem('reportName') == 'CLPAYMENT') {
      let reportData = JSON.parse(sessionStorage.getItem('reportData'));
      this.searchModal = reportData;
    } else {
      this.searchModal = {
        clientReferenceNo: '',
        claimno: '',
        firstname: '',
        surname: '',
        fundname: '',
        memberdob: '',
        status: '',
        source: '',
        productType: 'Group Life',
        claimType: '',
        assessor: 'All',
        applicationdate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
        metaData: {
          reportLimit: '20',
          reportOffset: '0',
          orderby: 'claimNo',
          order: 'asc'
        },
      };
    }
    this.resetModel = {
      clientReferenceNo: '',
      claimno: '',
      firstname: '',
      surname: '',
      fundname: '',
      memberdob: '',
      status: '',
      source: '',
      productType: 'Group Life',
      claimType: '',
      assessor: 'All',
      applicationdate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
      metaData: {
        reportLimit: '20',
        reportOffset: '0',
        orderby: 'claimNo',
        order: 'asc'
      },
    };

  }

  resetSearchModel() {
    this.searchModal = Object.assign({}, this.resetModel);
  }

}
