import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AppConfiguration } from '../../app-configuration';

@Injectable({
  providedIn: 'root'
})
export class ClaimSearchService {
  fundList: any;
  validatefund:any;
  claimTypes: any;
  claimStatus: any;
  assRes: any;
  
  constructor(private http: HttpClient, private appConfig: AppConfiguration) { }

  getFunds() {
    return !this.getFundsResult() ? this.http.get(this.appConfig.URLS.commonUrl.fundList).pipe(map(response => {
      this.setFundsResult(response);
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error'))) : this.getFundsResult();
  }

  getValidateFunds() {
    return !this.getValidateFundsResult() ? this.http.get(this.appConfig.URLS.claims.validatefund).pipe(map(response => {
      this.setValidateFundsResult(response);
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error'))) : this.getFundsResult();
  }

   getClaimtypes() {
    return !this.getCliamtypesResult() ? this.http.get(this.appConfig.URLS.claims.claimtypesList).pipe(map(response => {
      this.setclaimTypesList(response);
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error'))) : this.getCliamtypesResult();
  }

   getClaimsatatus() {
    return !this.getClaimstatusResult() ? this.http.get(this.appConfig.URLS.claims.claimstatusList).pipe(map(response => {
      this.setclaimStatusList(response);
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error'))) : this.getClaimstatusResult();
  }

  getFundsResult() {
    return this.fundList || null;
  }

  getValidateFundsResult() {
    return this.validatefund || null;
  }

  getCliamtypesResult() {
    return this.claimTypes || null;
  }

  getClaimstatusResult() {
    return this.claimStatus || null;
  }

  setFundsResult(results) {
    this.fundList = results;
  }

  setValidateFundsResult(results) {
    this.validatefund = results;
  }

  setclaimTypesList(results) {
    this.claimTypes = results;
  }

  setclaimStatusList(results) {
    this.claimStatus = results;
  }

}
