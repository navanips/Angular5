import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ClaimSearchService } from './claim-search.service';
import { AppConfiguration } from '../../app-configuration';

describe('ClaimSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule        
    ],
    providers: [
      AppConfiguration,
    ]    
  }));

  it('should be created', () => {
    const service: ClaimSearchService = TestBed.get(ClaimSearchService);
    expect(service).toBeTruthy();
  });
});
