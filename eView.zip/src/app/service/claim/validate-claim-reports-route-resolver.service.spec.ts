import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ValidateClaimReportsRouteResolverService } from './validate-claim-reports-route-resolver.service';
import { AppConfiguration } from '../../app-configuration';
import { ClaimSearchModel } from './claim-search-model';
import { RouterTestingModule } from '@angular/router/testing';

describe('ValidateClaimReportsRouteResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
      RouterTestingModule        
    ],
    providers: [
      AppConfiguration,
      ClaimSearchModel
    ]    
  }));

  it('should be created', () => {
    const service: ValidateClaimReportsRouteResolverService = TestBed.get(ValidateClaimReportsRouteResolverService);
    expect(service).toBeTruthy();
  });
});
