import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ValidateClaimReportDetailsService } from './validate-claim-report-details.service';
import { AppConfiguration } from '../../app-configuration';

describe('ValidateClaimReportDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule        
    ],
    providers: [
      AppConfiguration,
    ]    
  }));

  it('should be created', () => {
    const service: ValidateClaimReportDetailsService = TestBed.get(ValidateClaimReportDetailsService);
    expect(service).toBeTruthy();
  });
});
