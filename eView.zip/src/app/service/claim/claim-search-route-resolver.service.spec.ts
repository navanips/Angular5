import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ClaimSearchRouteResolverService } from './claim-search-route-resolver.service';
import { AppConfiguration } from '../../app-configuration';

describe('ClaimSearchRouteResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule        
    ],
    providers: [
      AppConfiguration,
    ]        
  }));

  it('should be created', () => {
    const service: ClaimSearchRouteResolverService = TestBed.get(ClaimSearchRouteResolverService);
    expect(service).toBeTruthy();
  });
});
