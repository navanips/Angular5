import { TestBed } from '@angular/core/testing';
import { StatusSearchModel } from './status-search-model';
import { UserService } from '../../../service/user/user.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppConfiguration } from '../../../app-configuration';

describe('StatusSearchModel', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
      RouterTestingModule        
    ],    
    providers:[
      UserService,
      AppConfiguration
    ]
  }));
  it('should create an instance', () => {
    const service: StatusSearchModel = TestBed.get(StatusSearchModel);
    expect(service).toBeTruthy();
  });
});
