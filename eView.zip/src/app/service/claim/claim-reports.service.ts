import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AppConfiguration } from '../../app-configuration';
import { ClaimSearchModel } from './claim-search-model';
import { PaymentSearchModel } from './payment/payment-search-model';
import { StatusSearchModel } from './status/status-search-model';
import { UserService } from '../../service/user/user.service';
import { Switch } from '@syncfusion/ej2-buttons';

@Injectable({
  providedIn: 'root'
})
export class ClaimReportsService {

  constructor(private http: HttpClient, private appConfig: AppConfiguration, private data: ClaimSearchModel, private paymentModel:PaymentSearchModel, private statusModel:StatusSearchModel, private userService :UserService) { }

  searchReports(reportPage) {
    let url;
    switch(reportPage) {
      case 'paymentReports':
          url = this.formQueryStrSkipAppDate(this.paymentModel.searchModal, reportPage, 'report');
        break;
      case 'statusReports':
          url = this.formQueryStrSkipAppDate(this.statusModel.searchModal, reportPage, 'report');   
        break;
      default:
          url = this.formQueryStr(this.data.searchModal, reportPage, 'report');   
    }
    return this.http.get(url).pipe(map(response => {
      return response;
    })
      , catchError((error: any) => Observable.throw(error.json().error || 'Server error')));
  }

  exportClaimReports(reportType) {
    let url;
    switch(reportType) {
      case 'claimPaymentExport':
        url = this.formQueryStrSkipAppDate(this.paymentModel.searchModal, reportType, 'export');
        break;
      case 'claimStatusExport':
          url = this.formQueryStrSkipAppDate(this.statusModel.searchModal, reportType, 'export');   
        break;
      default:
          url = this.formQueryStr(this.data.searchModal, reportType, 'export');   
    }
    // const url = this.formQueryStr(this.data.searchModal, reportType, 'export');
    return this.http.get(url, {responseType: 'blob'});
  }

  ValiadtesearchReports(reportPage) {
    const url = this.formQueryStr(this.data.valiadtemodel, reportPage, 'report');
    return this.http.get(url).pipe(map(response => {
      return response;
    })
      , catchError((error: any) => Observable.throw(error.json().error || 'Server error')));
  }

  ValiadteexportClaimReports(reportType) {
    let urlParam = this.data.valiadtemodel;
    urlParam.metaData.reportOffset = '0';
    const url = this.formQueryStr(this.data.valiadtemodel, reportType, 'export');
    return this.http.get(url, {responseType: 'blob'});
  }

  formQueryStr(queryModal: any, urlKey, type) {
    const searchArray = [];
    Object.keys(queryModal).forEach(key => {
      if (queryModal[key] && key !== 'metaData') {
        if (key === 'applicationdate') {
          searchArray.push(`${key}>='${moment(queryModal[key][0]).format('YYYY-MM-DD HH:mm:ss')}'`);
          searchArray.push(`${key}<='${moment(queryModal[key][1]).format('YYYY-MM-DD 23:59:59')}'`);
        } else if (key === 'memberdob') {
          searchArray.push(`${key}=='${moment(queryModal[key]).format('YYYY-MM-DD HH:mm:ss')}.0'`);
        } else {
          if(queryModal[key] != 'All') searchArray.push(`${key}=="${queryModal[key]}"`);
        }
      }
    });
    const params: any = searchArray.join(';');
    let limit, offset;
    if(type == 'report'){
      limit = queryModal.metaData.reportLimit;
      offset = queryModal.metaData.reportOffset;
    }else if(type == 'export'){
      limit = 100000;
      offset = 0;
    }
    const qString = '&limit=' + limit + '&offset=' + offset + '&orderby=' + queryModal.metaData.orderby + '&order=' + queryModal.metaData.order;
    const queryUrl = `${this.appConfig.URLS.claims[urlKey]}?searchkey=${params}` + qString;
    const encodedURL = encodeURI(queryUrl);
    return encodedURL;
  }

  formQueryStrSkipAppDate(queryModal: any, urlKey, type) {
    const searchArray = [];console.log(queryModal)
    let skipDate = false;
    let claimNo = queryModal.claimno;
    let clientReferenceNo = queryModal.clientReferenceNo;
    let firstname = queryModal.firstname;
    let surname = queryModal.surname;
    let memberdob = queryModal.memberdob;
    if(claimNo || clientReferenceNo || firstname || surname || memberdob) {
      skipDate = true;
    }
    Object.keys(queryModal).forEach(key => {
      if (queryModal[key] && key !== 'metaData') {
        if (key === 'applicationdate' && skipDate == false) {
          searchArray.push(`${key}>='${moment(queryModal[key][0]).format('YYYY-MM-DD HH:mm:ss')}'`);
          searchArray.push(`${key}<='${moment(queryModal[key][1]).format('YYYY-MM-DD 23:59:59')}'`);
        } else if (key === 'memberdob') {
          searchArray.push(`${key}=='${moment(queryModal[key]).format('YYYY-MM-DD HH:mm:ss')}.0'`);
        } else {
          if(queryModal[key] != 'All' && key!='applicationdate' ) searchArray.push(`${key}=="${queryModal[key]}"`);
        }
      }
    });
    const params: any = searchArray.join(';');
    let limit, offset;
    if(type == 'report'){
      limit = queryModal.metaData.reportLimit;
      offset = queryModal.metaData.reportOffset;
    }else if(type == 'export'){
      limit = 100000;
      offset = 0;
    }
    const qString = '&limit=' + limit + '&offset=' + offset + '&orderby=' + queryModal.metaData.orderby + '&order=' + queryModal.metaData.order;
    const queryUrl = `${this.appConfig.URLS.claims[urlKey]}?searchkey=${params}` + qString;
    const encodedURL = encodeURI(queryUrl);
    return encodedURL;
  }

}
