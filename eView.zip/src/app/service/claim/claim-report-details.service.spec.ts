import { TestBed } from '@angular/core/testing';

import { ClaimReportDetailsService } from './claim-report-details.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfiguration } from '../../app-configuration';

describe('ClaimReportDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule        
    ],
    providers: [
      AppConfiguration
    ]    
  }));

  it('should be created', () => {
    const service: ClaimReportDetailsService = TestBed.get(ClaimReportDetailsService);
    expect(service).toBeTruthy();
  });
});
