import { TestBed } from '@angular/core/testing';

import { ClaimConditionService } from './claim-condition.service';

describe('ClaimConditionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ClaimConditionService = TestBed.get(ClaimConditionService);
    expect(service).toBeTruthy();
  });
});
