import { TestBed } from '@angular/core/testing';

import { ClaimReportsRouteResolverService } from './claim-reports-route-resolver.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AppConfiguration } from '../../app-configuration';
import { ClaimSearchModel } from './claim-search-model';
import { RouterTestingModule } from '@angular/router/testing';

describe('ClaimReportsRouteResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
      RouterTestingModule        
    ],
    providers: [
      AppConfiguration,
      ClaimSearchModel
    ]   
  }));

  it('should be created', () => {
    const service: ClaimReportsRouteResolverService = TestBed.get(ClaimReportsRouteResolverService);
    expect(service).toBeTruthy();
  });
});
