import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ClaimReportsService } from './claim-reports.service';
import { AppConfiguration } from '../../app-configuration';
import { ClaimSearchModel } from './claim-search-model';
import { RouterTestingModule } from '@angular/router/testing';

describe('ClaimReportsService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
      RouterTestingModule        
    ],
    providers: [
      AppConfiguration,
      ClaimSearchModel
    ]   
  }));

  it('should be created', () => {
    const service: ClaimReportsService = TestBed.get(ClaimReportsService);
    expect(service).toBeTruthy();
  });
});
