import { TestBed } from '@angular/core/testing';

import { CustomSpinnerService } from './custom-spinner.service';

describe('CustomSpinnerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CustomSpinnerService = TestBed.get(CustomSpinnerService);
    expect(service).toBeTruthy();
  });
});
