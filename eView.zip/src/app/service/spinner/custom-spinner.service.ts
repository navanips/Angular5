import { Injectable,Input,Output,EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomSpinnerService {

  @Output() fire: EventEmitter<any> = new EventEmitter(true);
  constructor() { }

  show() {
    this.fire.emit(true);
  }

  hide() {
    this.fire.emit(false);
  }

   getEmittedValue() {
     return this.fire;
   }
}
