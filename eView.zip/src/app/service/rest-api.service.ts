import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RestApiService {

  constructor(private http: HttpClient) { }

  get<T>(getUrl:string):Observable<T> {
    return this.http.get<T>(getUrl);
  }
  add<T>(postUrl:string,data:any):Observable<T> {
    return this.http.post<T>(postUrl,data);
  }
  update<T>(putUrl:string,data:any):Observable<T> {
    return this.http.put<T>(putUrl,data);
  } 
  delete<T>(deleteUrl: string){
    return this.http.delete<T>(deleteUrl)
  }
  downloadNoteReceipt(url: string):Observable<Blob>{    
    return this.http.get(url, { responseType: "blob" } );
  }
  checkLodgement(postUrl:string,data:any):Observable<any> {
  return this.http.post<any>(postUrl,data);
  } 
}
