import { Injectable } from '@angular/core';
import { HttpEvent, HttpErrorResponse, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { map, tap, retry, catchError } from 'rxjs/operators';
import { AppConfiguration } from '../../app-configuration';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalComponent } from '../../layout/ngb-modal/ngb-modal.component';
import { NgxSpinnerService } from "ngx-spinner";
import { FlashMessagesService } from 'angular2-flash-messages';
import * as $ from 'jquery';
import { CustomSpinnerService } from '../../service/spinner/custom-spinner.service';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService {

  constructor() { }
}

@Injectable({
  providedIn: 'root'
})
export class CustomInterceptor implements HttpInterceptor {
  private totalRequests = 0;
  constructor(private conf:AppConfiguration, private spin:CustomSpinnerService, private flashMsg: FlashMessagesService){
  }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.totalRequests++;
    this.flashMsg.grayOut(false);
    $('#flashMessages .flash-message').hide();  
    this.spin.show();
    const userToken: string = sessionStorage.getItem('userToken');

    if (userToken) {
        request = request.clone({ headers: request.headers.set('Authorization', 'Bearer '+userToken) });
        //request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
    }else{
      
      if(request.url.indexOf(this.conf.URLS.loginAppURL) == 0){
        request = request.clone({ headers: request.headers.set('Authorization', "Basic bWV0YXU6bWV0YXU=") });
        request = request.clone({ headers: request.headers.set('Content-Type', 'application/x-www-form-urlencoded') });
      }else{
        const forgotPasswordToken: string = sessionStorage.getItem('forgotPasswordToken');
        request = request.clone({ headers: request.headers.set('Authorization', 'Bearer '+forgotPasswordToken) });
      }
    }    

    const dupReq = request.clone({ url: this.conf.serviceBaseUrl+request.url });
    return next.handle(dupReq).pipe(
      tap(evt => {
        if(evt instanceof HttpResponse) {
          this.totalRequests--;
           if(this.totalRequests == 0){
            this.spin.hide();
          }
        }
      }),
      catchError(err => {
        if(err instanceof HttpErrorResponse) {
          this.totalRequests--;
          if(this.totalRequests == 0){
             this.spin.hide();
          }
        }
        if(err.status == 0){
          $('#flashMessages .flash-message').hide();      
          this.flashMsg.show('An unexpected error has occurred. Please try again.', {
            cssClass: 'alert alert-danger-generic alert-dismissible',
            timeout: 30000,
            closeOnClick: true,
            showCloseBtn: true
          });          
        }  
        
        return throwError(err);
      })
    );
  }
}
