import { TestBed } from '@angular/core/testing';

import { FlashMessageService } from './flash-message.service';
import { FlashMessagesModule, FlashMessagesService } from 'angular2-flash-messages';

describe('FlashMessageService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers:[
      FlashMessagesService
    ]
  }));

  it('should be created', () => {
    const service: FlashMessageService = TestBed.get(FlashMessageService);
    expect(service).toBeTruthy();
  });
});
