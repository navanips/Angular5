import { Injectable } from '@angular/core';
import { FlashMessagesService } from 'angular2-flash-messages';
import * as $ from 'jquery';

@Injectable({
  providedIn: 'root'
})
export class FlashMessageService {

  constructor(private flashMsg: FlashMessagesService) { }

  showErrorMessage() {
    $('#flashMessages .flash-message').hide();
    this.flashMsg.show('An unexpected error has occurred. Please try again.', {
      cssClass: 'alert alert-danger-generic alert-dismissible',
      timeout: 30000,
      closeOnClick: true,
      showCloseBtn: true
    });
  }

  hideErrorMessage(){
    $('#flashMessages .flash-message').hide();
  }
}
