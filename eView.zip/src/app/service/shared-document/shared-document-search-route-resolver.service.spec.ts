import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SharedDocumentSearchRouteResolverService } from './shared-document-search-route-resolver.service';
import { AppConfiguration } from '../../app-configuration';
import { SharedDocumentModel } from './shared-document-model';

describe('SharedDocumentSearchRouteResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule        
    ],
    providers: [
      AppConfiguration,
      SharedDocumentModel
    ]      
  }));

  it('should be created', () => {
    const service: SharedDocumentSearchRouteResolverService = TestBed.get(SharedDocumentSearchRouteResolverService);
    expect(service).toBeTruthy();
  });
});
