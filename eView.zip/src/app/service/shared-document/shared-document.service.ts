import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AppConfiguration } from '../../app-configuration';
import * as moment from 'moment';
import { SharedDocumentModel } from './shared-document-model';

@Injectable({
  providedIn: 'root'
})
export class SharedDocumentService {
  fundList: any;
  documentTypes:any;
  departmentList: any;
  existingDepartmentList = [{
    departmentID : 'SharedDocuments_Claims',
    departmentName : 'Claims'
  },{
    departmentID : 'SharedDocuments_Underwriting',
    departmentName : 'Underwriting'
  },{
    departmentID : 'SharedDocuments_ProductManagement',
    departmentName : 'Product Management'
  },{
    departmentID : 'SharedDocuments_TechnicalDevelopment',
    departmentName : 'Technical Development'
  },{
    departmentID : 'SharedDocuments_CustomerExperience',
    departmentName : 'Customer Experience'
  },{
    departmentID : 'SharedDocuments_AccountManagement',
    departmentName : 'Account Management'
  },{
    departmentID : 'SharedDocuments_Reinsurance',
    departmentName : 'Reinsurance'
  },{
    departmentID : 'SharedDocuments_Rehabilitation',
    departmentName : 'Rehabilitation'
  },{
    departmentID : 'SharedDocuments_Complaints',
    departmentName : 'Complaints'
  },{
    departmentID : 'SharedDocuments_PMO',
    departmentName : 'PMO'
  },{
    departmentID : 'SharedDocuments_GroupAdministrator',
    departmentName : 'Group Administrator'
  },{
    departmentID : 'SharedDocuments_Compliance',
    departmentName : 'Compliance'
  },{
    departmentID : 'SharedDocuments_Pricing',
    departmentName : 'Pricing'
  },{
    departmentID : 'SharedDocuments_Audit',
    departmentName : 'Audit'
  },{
    departmentID : 'SharedDocuments_CustomerStrategy',
    departmentName : 'Customer Strategy'
  },{
    departmentID : 'SharedDocuments_Technology',
    departmentName : 'Technology'
  }];

 constructor(private http: HttpClient, private appConfig: AppConfiguration,private data: SharedDocumentModel) { }

 getFunds() {
    return !this.getFundsResult() ? this.http.get(this.appConfig.URLS.shareddocument.fundList).pipe(map(response => {
      this.setFundsResult(response);
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error'))) : this.getFundsResult();
  }

  getDocumentTypes() {
    return !this.getDoctypesResult() ? this.http.get(this.appConfig.URLS.shareddocument.documentTypes).pipe(map(response => {
      this.setDoctypesResult(response);
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error'))) : this.getDoctypesResult();
  }

  getDepartmentNames() {
    return !this.getDepartmentResult() ? this.http.get(this.appConfig.URLS.shareddocument.departmentList).pipe(map(response => {
      this.setDepartmentResult(response);
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error'))) : this.getDepartmentResult();
  }

  getFundsResult() {
    return this.fundList || null;
  }

  setFundsResult(results) {
    this.fundList = results;
  }

  getDoctypesResult() {
    return this.documentTypes || null;
  }

  setDoctypesResult(results) {
    this.documentTypes = results;
  }

  getDepartmentResult() {
    let roleBasedMenu  = (JSON.parse(sessionStorage.getItem('userDetails')).menus)?JSON.parse(sessionStorage.getItem('userDetails')).menus:[];
    this.departmentList = [];
    this.existingDepartmentList.forEach((item)=>{
      let currentDepID = item.departmentID;
      if(roleBasedMenu.indexOf(currentDepID) >= 0){
        this.departmentList.push(item);
      }
    });    
    return this.departmentList || null;
  }

  setDepartmentResult(results) {
    this.departmentList = results;
  }
  
  searchReports(reportPage) {
    const url = this.formQueryStr(this.data.searchModal, reportPage);
    return this.http.get(url).pipe(map(response => {
      return response;
    })
      , catchError((error: any) => Observable.throw(error.json().error || 'Server error')));
  }

  downloadSingleFile(dowloadurl){
    return this.http.get(dowloadurl, {responseType: 'blob'});
  }

  downloadMultipleFile(dowloadzipurl){
    return this.http.get(dowloadzipurl, {responseType: 'blob'});
  }

  deletefile(deleteURL){
    return this.http.delete(deleteURL).pipe(map(response => {
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error')));
  }

  formQueryStr(queryModal: any, urlKey) {
    const searchArray = [];
    Object.keys(queryModal).forEach(key => {
      if (queryModal[key] && key !== 'metaData') {
        if (key === 'effectiveDate') {
          searchArray.push(`${key}>='${moment(queryModal[key][0]).format('YYYY-MM-DD HH:mm:ss')}'`);
          searchArray.push(`${key}<='${moment(queryModal[key][1]).format('YYYY-MM-DD 23:59:59')}'`);
        }
        else {
          if (queryModal[key] != 'All') searchArray.push(`${key}=='${queryModal[key]}'`);
        }
      }
    });
    const params: any = searchArray.join(';');
    const qString = '&limit=' + queryModal.metaData.reportLimit + '&offset=' + queryModal.metaData.reportOffset
      + '&orderby=' + queryModal.metaData.orderby + '&order=' + queryModal.metaData.order;
    const queryUrl = `${this.appConfig.URLS.shareddocument[urlKey]}?searchkey=${params}` + qString;
    //return queryUrl;
    const encodedURL = encodeURI(queryUrl);    
    return encodedURL;
  }

}
