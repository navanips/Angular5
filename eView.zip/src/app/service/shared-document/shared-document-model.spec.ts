import { SharedDocumentModel } from './shared-document-model';

describe('SharedDocumentModel', () => {
  it('should create an instance', () => {
    expect(new SharedDocumentModel()).toBeTruthy();
  });
});
