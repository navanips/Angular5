import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SharedDocumentService } from './shared-document.service';
import { AppConfiguration } from '../../app-configuration';
import { SharedDocumentModel } from './shared-document-model';

describe('SharedDocumentService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule        
    ],
    providers: [
      AppConfiguration,
      SharedDocumentModel
    ]    
  }));

  it('should be created', () => {
    const service: SharedDocumentService = TestBed.get(SharedDocumentService);
    expect(service).toBeTruthy();
  });
});
