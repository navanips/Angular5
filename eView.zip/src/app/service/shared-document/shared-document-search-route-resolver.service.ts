import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { SharedDocumentService } from './shared-document.service';

@Injectable({
  providedIn: 'root'
})
export class SharedDocumentSearchRouteResolverService implements Resolve<any> {

  constructor(private shareddocservice:SharedDocumentService) { }

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    const fundList = this.shareddocservice.getFunds();
    const documentTypes = this.shareddocservice.getDocumentTypes();
    const departmentList = this.shareddocservice.getDepartmentNames();
    const data = {fundList: fundList,documentTypes: documentTypes , departmentList: departmentList};
    return of(data);
  }
}
