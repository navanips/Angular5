import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { SharedDocumentService } from './shared-document.service';

@Injectable({
  providedIn: 'root'
})
export class SharedDocumentReportRouteResolverService implements Resolve<any>{

  constructor(private shareddocSer: SharedDocumentService) { }

   resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    const reportURL = route.data['reportURL'];
    return this.shareddocSer.searchReports(reportURL);
  }
}
