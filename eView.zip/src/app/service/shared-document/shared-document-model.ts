export class SharedDocumentModel {
  searchModal: any;
  resetModel: any;
  uploadModel:any;
  uploadresetModel:any;
  lastYearDate:any;
  finalDate:any;
  constructor() {
    this.lastYearDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    this.finalDate = new Date(this.lastYearDate.setDate(this.lastYearDate.getDate()+1));
    if(sessionStorage.getItem('reportData') && sessionStorage.getItem('reportName') == 'sharedDoc') {
      let reportData = JSON.parse(sessionStorage.getItem('reportData'));
      this.searchModal = reportData;
    } else {      
    this.searchModal =  {
      fundCode: '',
      documentType: '',
      description: '',
      department : '',
      effectiveDate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
      metaData: {
        reportLimit: '20',
        reportOffset: '0',
        orderby: 'createdDate',
        order: 'desc'
      }
    };
  }
    this.resetModel = {
      fundCode: '',
      documentType: '',
      description: '',
      department : '',
      effectiveDate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
      metaData: {
        reportLimit: '20',
        reportOffset: '0',
        orderby: 'createdDate',
        order: 'desc'
      }
    };
    this.uploadModel = {
      fundCode:'',
      fundName:'',
      documentType:'',
      effectiveDate:'',
      description:'',
      department :'',
      retention:'10 Days',
      userId:'',
      username:'',
      firstName:'',
      lastName:'',
      comments:''
    }
     this.uploadresetModel = {
      fundCode:'',
      fundName:'',
      documentType:'',
      effectiveDate:'',
      description:'',
      department :'',
      retention:'10 Days',
      userId:'',
      username:'',
      firstName:'',
      lastName:'',
      comments:''
    }
  }

  resetSearchModel() {
    this.searchModal =  Object.assign({}, this.resetModel);
  }

  resetUploadModel() {
    this.searchModal =  Object.assign({}, this.uploadresetModel);
  }
}