import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { UwReportsService } from './uw-reports.service';

@Injectable({
  providedIn: 'root'
})
export class UwReportsRouteResolverService implements Resolve<any> {

  constructor(private uwReportService: UwReportsService) { }

   resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    const reportURL = route.data['reportURL'];
    return this.uwReportService.searchReports(reportURL);
  }
}
