import { TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { ReportDetailsService } from './report-details.service';

describe('ReportDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: ReportDetailsService = TestBed.get(ReportDetailsService);
  //   expect(service).toBeTruthy();
  // });
});
