import { TestBed } from '@angular/core/testing';

import { UwReportsRouteResolverService } from './uw-reports-route-resolver.service';

describe('ReportsRouteResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: UwReportsRouteResolverService = TestBed.get(UwReportsRouteResolverService);
  //   expect(service).toBeTruthy();
  // });
});
