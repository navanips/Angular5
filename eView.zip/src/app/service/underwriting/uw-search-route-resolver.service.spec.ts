import { TestBed } from '@angular/core/testing';

import { UwSearchRouteResolverService } from './uw-search-route-resolver.service';

describe('UwSearchRouteResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: UwSearchRouteResolverService = TestBed.get(UwSearchRouteResolverService);
  //   expect(service).toBeTruthy();
  // });
});
