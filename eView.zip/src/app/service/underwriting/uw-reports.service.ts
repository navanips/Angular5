import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AppConfiguration } from '../../app-configuration';
import { SearchModel } from '../search-model';

@Injectable({
  providedIn: 'root'
})
export class UwReportsService {
  fundList: any;
  constructor(private http: HttpClient, private appConfig: AppConfiguration, private data: SearchModel) { }
  searchReports(reportPage) {
    const url = this.formQueryStr(this.data.searchModal, reportPage, 'report');
    return this.http.get(url).pipe(map(response => {
      return response;
    })
      , catchError((error: any) => Observable.throw(error.json().error || 'Server error')));
  }

  exportUWReports(reportType) {
    const url = this.formQueryStr(this.data.searchModal, reportType, 'export');
    return this.http.get(url, {responseType: 'blob'});
  }

  formQueryStr(queryModal: any, urlKey, type) {
    const searchArray = [];
    Object.keys(queryModal).forEach(key => {
      if (queryModal[key] && key !== 'metaData') {
        if (key === 'applicationDate') {
          searchArray.push(`${key}>='${moment(queryModal[key][0]).format('YYYY-MM-DD HH:mm:ss')}'`);
          searchArray.push(`${key}<='${moment(queryModal[key][1]).format('YYYY-MM-DD 23:59:59')}'`);
        } else if (key === 'memberDob') {
          searchArray.push(`${key}=='${moment(queryModal[key]).format('YYYY-MM-DD HH:mm:ss')}.0'`);
        } else {
          if (queryModal[key] != 'All') searchArray.push(`${key}=="${queryModal[key]}"`);
        }
      }
    });
    const params: any = searchArray.join(';');
    let limit, offset;
    if(type == 'report'){
      limit = queryModal.metaData.reportLimit;
      offset = queryModal.metaData.reportOffset;
    }else if(type == 'export'){
      limit = 100000;
      offset = 0;
    }
    const qString = '&limit=' + limit + '&offset=' + offset
      + '&orderby=' + queryModal.metaData.orderby + '&order=' + queryModal.metaData.order;
    const queryUrl = `${this.appConfig.URLS.underwriting[urlKey]}?searchkey=${params}` + qString;
    const encodedURL = encodeURI(queryUrl);
    return encodedURL;
  }
}

