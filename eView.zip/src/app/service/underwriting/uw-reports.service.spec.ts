import { TestBed } from '@angular/core/testing';

import { UwReportsService } from './uw-reports.service';

describe('UwReportsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  // it('should be created', () => {
  //   const service: UwReportsService = TestBed.get(UwReportsService);
  //   expect(service).toBeTruthy();
  // });
});
