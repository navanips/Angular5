import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { UwSearchService } from './uw-search.service';

@Injectable({
  providedIn: 'root'
})
export class UwSearchRouteResolverService implements Resolve<any> {

  constructor(private uwSearchSvc: UwSearchService) { }

  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    const fundList = this.uwSearchSvc.getFunds();
    const sourceList = this.uwSearchSvc.getSource();
    const data = {fundList: fundList, sourceList: sourceList};
    return of(data);
    // return this.uwSearchSvc.getFunds();
  }
}

