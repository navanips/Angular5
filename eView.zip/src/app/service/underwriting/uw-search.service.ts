import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AppConfiguration } from '../../app-configuration';

@Injectable({
  providedIn: 'root'
})
export class UwSearchService {
  fundList: any;
  sourceList: any;
  constructor(private http: HttpClient, private appConfig: AppConfiguration) { }

  getFunds() {
    return !this.getFundsResult() ? this.http.get(this.appConfig.URLS.commonUrl.fundList).pipe(map(response => {
      this.setFundsResult(response);
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error'))) : this.getFundsResult();
  }

  getSource() {
    return !this.getSourceResult() ? this.http.get(this.appConfig.URLS.commonUrl.sourceList).pipe(map(response => {
      this.setSourceList(response);
      return response;
    })
    , catchError((error: any) => Observable.throw(error.json().error || 'Server error'))) : this.getSourceResult();
  }

  setFundsResult(results) {
    this.fundList = results;
  }

  getFundsResult() {
    return this.fundList || null;
  }

  clearFundsResult() {
    this.fundList = null;
  }

  setSourceList(results) {
    this.sourceList = results;
  }

  getSourceResult() {
    return this.sourceList || null;
  }

}
