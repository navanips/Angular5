import { Injectable } from '@angular/core';

@Injectable()
export class SearchModel {
  searchModal: any;
  resetModel: any;
  lastYearDate:any;
  finalDate:any;
  
  constructor() {
//sessionStorage.getItem('reportName') != 'ValidateClaim' && sessionStorage.getItem('reportName') != 'sharedDoc'
    this.lastYearDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    this.finalDate = new Date(this.lastYearDate.setDate(this.lastYearDate.getDate()+1));
    if(sessionStorage.getItem('reportData') && (sessionStorage.getItem('reportName') == 'UWREQ' || sessionStorage.getItem('reportName') == 'UWSLA' || sessionStorage.getItem('reportName') == 'UWSTATUS')) {
      let reportData = JSON.parse(sessionStorage.getItem('reportData'));
      this.searchModal = reportData;
    } else {
      this.searchModal =  {
        applicationNo: '',
        firstname: '',
        surname: '',
        memberDob: '',
        fundname: '',
        clientReferenceNo: '',
        status: 'All',
        source: 'All',
        applicationDate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
        metaData: {
          reportLimit: '20',
          reportOffset: '0',
          orderby: 'applicationNo',
          order: 'asc'
        }
      };
    }
    this.resetModel = {
      applicationNo: '',
      firstname: '',
      surname: '',
      memberDob: '',
      fundname: '',
      clientReferenceNo: '',
      status: 'All',
      source: 'All',
      applicationDate: [this.finalDate.toDateString(), new Date(new Date().toDateString())],
      metaData: {
        reportLimit: '20',
        reportOffset: '0',
        orderby: 'applicationNo',
        order: 'asc'
      }
    };
  }

  resetSearchModel() {
    this.searchModal =  Object.assign({}, this.resetModel);
  }

}
