import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DateRangePickerModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { NgxPaginationModule } from 'ngx-pagination';
import { DatePipe } from '@angular/common';
import { FlashMessagesModule } from 'angular2-flash-messages';
import { NgxSpinnerModule } from "ngx-spinner";
import { HttpModule } from '@angular/http';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgForm, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { MomentModule } from 'angular2-moment';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { TooltipModule } from 'ng2-tooltip-directive';

import { AppComponent } from './app.component';
import { NgbModalComponent } from './layout/ngb-modal/ngb-modal.component';
import { AppConfiguration } from './app-configuration';
import { RoutingModule } from './routing/routing.module';
import { CustomInterceptor } from './service/interceptor/interceptor.service';

@NgModule({
  declarations: [
    AppComponent,
    NgbModalComponent
  ],
  imports: [
    BrowserModule,
    RoutingModule,
    HttpClientModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    ModalModule.forRoot(),
    MomentModule,
    NgIdleKeepaliveModule.forRoot(),
    DateRangePickerModule,
    DatePickerModule,
    NgxPaginationModule,
    NgbModule.forRoot(),
    //Ng4LoadingSpinnerModule.forRoot(),
    FlashMessagesModule.forRoot(),
    TooltipModule,
    NgxSpinnerModule
  ],
  entryComponents: [
    NgbModalComponent
  ],
  providers: [
    AppConfiguration,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CustomInterceptor,
      multi: true
    },
    {
      provide: LocationStrategy, useClass: HashLocationStrategy
    },

    DatePipe
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }