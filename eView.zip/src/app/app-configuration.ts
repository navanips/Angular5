export class AppConfiguration {
    serviceBaseUrl: any;
    public envName: any;
    constructor() {
        var location = window.location.origin;
        //var location = 'https://www.qa.eapplication.metlife.com.au';
        switch (location) {
            case 'http://localhost:4200':
                this.serviceBaseUrl = 'http://localhost:9080/';
                this.envName = 'dev';
                break;
            case 'http://www.dit.eservice.metlife.com.au':
                this.serviceBaseUrl = 'http://10.173.43.110:9080/';
                break;
            case 'http://www.sit.eservice.metlife.com.au':
                this.serviceBaseUrl = 'http://10.173.43.134:9080/';
                break;                
            default:
                this.serviceBaseUrl = location +'/eViewGateway/';
                this.envName = 'default';
        }
    }

    public appConstants = {
        maxDateRangeAllowed: 366,
        regEx: {
            dateOnly: /^[0-9/-]+$/,
            dateRangeOnly: /^[0-9/-\s]+$/
        }
    };
    public apiUrl = '';
    // public serviceBaseUrl = 'http://10.173.43.110:9080/'; // window.location.origin;
    //public serviceBaseUrl = 'http://localhost:9080/'; // window.location.origin;
    public URLS = {
        loginAppURL: 'oauth/token',
        userDetailsAppURL: 'api/v1/user',
        forgetPasswordAppURL: 'api/v1/application/user',
        underwriting: {
            addUnderwriting: 'api/v1/application/lodgement',
            submitExistingUW: 'api/v1/application/lodgement/existing',
            statusReports: 'api/v1/report/application/status',
            requirementReports: 'api/v1/report/application/requirement',
            slaReports: 'api/v1/report/application/sla',
            uwStatusExport: 'api/v1/report/application/status/export',
            uwReqExport: 'api/v1/report/application/requirement/export',
            uwSlaExport: 'api/v1/report/application/sla/export',
            reportDetails: 'api/v1/report/application',
            slaExport: 'api/v1/report/application/sla/detail/export',
            statusExport: 'api/v1/report/application/status/detail/export',
            requirementExport: 'api/v1/report/application/requirement/detail/export',
            searchUWReports: '',
            existingDocsList: 'api/v1/application/retrievedocuments/'
        },
        claims: {
            addClaims: 'api/v1/claim/lodgement',
            submitExistingClaim: 'api/v1/claim/lodgement/existing',
            statusReports: 'api/v1/report/claim/status',
            claimtypesList: 'api/v1/metadata/claim/type',
            claimstatusList: 'api/v1/metadata/claim/status',
            reportDetails: 'api/v1/report/claim',
            requirementReports: 'api/v1/report/claim/requirement',
            slaReports: 'api/v1/report/claim/sla',
            paymentReports: 'api/v1/report/claim/payment',
            claimStatusExport: 'api/v1/report/claim/status/export',
            claimRequirementExport: 'api/v1/report/claim/requirement/export',
            slaStatusExport: 'api/v1/report/claim/sla/export',
            claimPaymentExport: 'api/v1/report/claim/payment/export',
            claimCause: 'api/v1/metadata/claim/claimcause',
            claimCondition: 'api/v1/metadata/claim/claimcondition',
            assessorURL: 'api/v1/metadata/claim/assessor',
            searchExisting: 'api/v1/report/claims/existing',
            documentList: 'api/v1/metadata/claim/documenttype/CLAIM',
            validatefund: 'api/v1/metadata/claim/fund',
            validateReports: 'api/v1/claim/lodgement',
            claimValiadteExport: 'api/v1/claim/lodgement/export',
            fileUpload: 'api/v1/claim/uploadfile',
            existingDocsList: 'api/v1/claim/uploadfiles/'
        },
        validateClaim: {
            DocList: 'api/v1/metadata/claim/documenttype',
            delDoc: 'api/v1/claim/lodgement/deletedocument/',
            fileUpload: 'api/v1/claim/uploadfile/validateclaim',
            downloadPDF: 'api/v1/claim/lodgement/summarypdf'
        },
        shareddocument: {
            fundList: 'api/v1/application/metadata/fund',
            documentTypes: 'api/v1/metadata/claim/documenttype/Document Types',
            departmentList: 'api/v1/metadata/claim/documenttype/department',
            sharedDocReports: 'api/v1/shareddocument',
            sharedDocUploadReports: 'api/v1/shareddocument/upload'
        },
        commonUrl: {
            fundList: 'api/v1/application/metadata/fund',
            sourceList: 'api/v1/application/metadata/sourcetype',
            categoryList: 'api/v1/application/metadata/category',
            documentList: 'api/v1/application/metadata/documenttype',
            lodgementcheck: 'api/v1/claim/lodgementcheck'
        },
        fileUrl: {
            fileUpload: 'api/v1/application/uploadfile',
            deleteFile: 'api/v1/application/deletefile'
        },
        createUser: {
            fundList: 'api/v1/metadata/user/fund',
            userType: 'api/v1/metadata/user/usertype',
            CompanyList: 'api/v1/metadata/user/company',
            AppList: 'api/v1/metadata/user/application',
            addUser: 'api/v1/application/user',
            searchuserExport: 'api/v1/application/user/export',
            // updateuser: 'items'
        },
        UpdateApp: {
            List: 'api/v1/user/application'
        }
    };
    public externalURLS = {
        legalNoticeURL: 'http://www.metlife.com.au/legal/index.html',
        privacyPolicyURL: 'https://www.metlife.com.au/privacy/',
        metlifeFormsURL: 'https://www.metlife.com.au/get-help/documents-and-forms/?WT.ac=GN_business_forms#products',
        userGuideURL: 'https://www.e2e.eservice.metlife.com.au/wps/PA_MLPAUQuickLinks/files/eView_User_Guide.pdf',
        termsConditionsURL: 'https://www.metlife.com.au/legal-notices/',
        lodgeclaimURL: 'https://www.elodgement.metlife.com.au/eClaims/NotificationLoginServ?SecureString=00000000000000451496_00000001559282429108_00002',
        applicationinsuranceURL: 'assets/Steadfast/Application_for_Insurance.pdf',
        medicalUWurl: 'assets/Steadfast/Medical_Underwriting_Guide.pdf',
        continuationURL: 'assets/Steadfast/Application_for_Salary_Continuance_Cover.pdf',
        disclosurestatementURL: 'assets/Steadfast/Your_Life_Product_Disclosure_Statement.pdf',
        policyDocumentURL: 'assets/Steadfast/Income_Cover.pdf',
        steadfastcorURL: 'mailto:"SteadfastCorporate@metlife.com"?subject=Steadfast Corporate Enquiry',
        corporatePDSURL: 'assets/Steadfast/Steadfast_Group_PDS_17_11_2014.pdf',
        marketingBrochureURL: 'assets/Steadfast/METLI0003_Steadfast_Brochure_V2_3DAP_email_version.pdf',
        productsummaryURL: 'assets/Steadfast/steadfast_GI_PRODUCT_SUMMARY_jan16.pdf',
        userGuideUrl: 'assets/Userguide/eView_User_Guide.pdf',
        eApply: {
            apply: '/eapply/corporate?c=',
            onboard: '/eapply/corporate#/onboard/fundCode=',
            dashboard: '/eapply/corporate#/dashboard/FundCode='
        }
    };

    public pageTitles = [
        { name: '', title: 'Login' },
        { name: 'login', title: 'Login' },
        { name: 'forgot-password', title: 'Forgot password' },
        { name: 'dashboard', title: 'Home' },
        { name: 'claims_validateClaim', title: 'Validate claim' },
        { name: 'users_update-user', title: 'Manage users' },
        { name: 'users_update-user_update', title: 'Update user' },
        { name: 'claims_validateClaim_details', title: 'Validate claim' },
        { name: 'claims_lodgeClaim', title: 'Lodge claim' },
        { name: 'steadfast', title: 'Steadfast' },
        { name: 'shared-documents', title: 'Shared documents' },
        { name: 'claims_status', title: 'Claim status report' },
        { name: 'claims_status_details', title: 'Claim status report' },
        { name: 'claims_sla', title: 'Claim SLA report' },
        { name: 'claims_requirement', title: 'Claim requirement report' },
        { name: 'claims_requirement_details', title: 'Claim requirement report' },
        { name: 'claims_payment', title: 'Claim payment report' },
        { name: 'underwriting_status', title: 'Underwriting status report' },
        { name: 'underwriting_status_details', title: 'Underwriting status report' },
        { name: 'underwriting_sla', title: 'Underwriting SLA report' },
        { name: 'underwriting_requirement', title: 'Underwriting requirement report' },
        { name: 'underwriting_requirement_details', title: 'Underwriting requirement report' },
        { name: 'underwriting_submit-new-underwriting', title: 'Submit new underwriting' },
        { name: 'eapply-corporate', title: 'eApply' },
        { name: 'claims_submit-claims', title: 'Submit new claim' },
        { name: 'users_change-password', title: 'Change password' },
        { name: 'session-expired', title: 'Session timeout' },
        { name: 'users_create', title: 'Create a user' },
        { name: 'users_updateapp_list', title: 'Update application & modules' }
    ];

    public featureToggle = {
        dev: {
            '*': true
        },
        dit: {
            uwStatus: true,
            uwSla: true,
            uwRequirement: true,
            uwSubmitNew: true,
            claimStatus: true,
            claimSla: true,
            claimRequirement: true,
            claimPayment: true,
            claimSubmitNew: true,
            claimValidate: true,
            createUser: true,
            manageUser: true,
            editUser: true,
            changePassword: true,
            eApplyCorporate: true,
            steadfast: true,
            sharedDocsReports: true,
            updateApps: true
        },
        sit: {
            uwStatus: true,
            uwSla: true,
            uwRequirement: true,
            uwSubmitNew: true,
            claimStatus: true,
            claimSla: true,
            claimRequirement: true,
            claimPayment: true,
            claimSubmitNew: true,
            claimValidate: true,
            createUser: true,
            manageUser: true,
            editUser: true,
            changePassword: true,
            eApplyCorporate: true,
            steadfast: true,
            sharedDocsReports: true,
            updateApps: true
        },
        default: {
            '*': true
        }
    };
}