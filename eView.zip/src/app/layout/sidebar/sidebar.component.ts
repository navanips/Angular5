import { Component, OnInit } from '@angular/core';
import { MenuService } from '../../service/menu/menu.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  menuItems: Array<any>;
  loggedInUserdetails: any;

  constructor(public menu: MenuService) {
    this.loggedInUserdetails = JSON.parse(sessionStorage.getItem('userDetails'));
    this.menuItems = menu.getMenu();
  }

  ngOnInit() {
  }

  removeActive(event) {
    event.stopPropagation();
  }
}
