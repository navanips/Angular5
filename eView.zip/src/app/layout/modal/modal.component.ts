import { Component, OnInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {

  public type:any;
  constructor(private modalService: BsModalService,private modalRef:BsModalRef,private router: Router,private idle: Idle) { }

  ngOnInit() {
  }

  confirm() {    
    this.router.navigate(['/users/change-password']);
    this.modalRef.hide();
  }
 
  decline() {
    this.modalRef.hide();
  }
  closeModal() {
    this.modalRef.hide();
    $('modal-container').hide();
    $('bs-modal-backdrop').hide();
    this.modalRef = null;
    let body = document.getElementsByTagName('body');
    body[0].style.overflow ="scroll";
    this.idle.watch()
}

}
