import { Component, OnInit } from '@angular/core';
import { UserService } from '../../service/user/user.service';
import { MenuService } from '../../service/menu/menu.service';
import { Router } from '@angular/router';
import * as $ from 'jquery';
 
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  menuItems: Array<any>;
  loggedInUserdetails: any;
  disableLogout : any;
  constructor(private UserService: UserService, private router: Router, private Menu: MenuService) {
    this.loggedInUserdetails = JSON.parse(sessionStorage.getItem('userDetails'));
    this.menuItems = Menu.getMenu();
    this.disableLogout = this.loggedInUserdetails.passwordInforce.toLowerCase();
    if(this.disableLogout == 'true') {
      setTimeout(() => {
        $('#originalLogout').hide();
        $('#dummyLogout').show();
      }, 1000);
      
    } else {
      setTimeout(() => {
        $('#originalLogout').show()
        $('#dummyLogout').hide()
    }, 1000);
    }
  }

  ngOnInit() {
    $(document).ready(function(){
      $('#nav-claims-tab, #nav-underwriting-tab').hover(function(){
          $(this).find('.dropdown-content').show();
      },function(){
          $(this).find('.dropdown-content').hide();
      });
      $('#nav-claims-tab .dropdown-content a, #nav-underwriting-tab .dropdown-content a').click(function(){
          $(this).parent().parent().parent().parent().hide();
      });
      // setTimeout(function(){
      //   $('#nav-tab a').parent().removeClass('active');
      //   $('.nav-item').removeClass('active');
      //   $('#nav-home-tab').addClass('active');
      // },100);
      // $('#nav-tab a').click(function(){
      //   setTimeout(function(){
      //     $('#nav-tab a').parent().removeClass('active');
      //     $('.nav-item').removeClass('active');
      //     $('#nav-home-tab').addClass('active');
      //   },100);
      // })
  });
  }

  changePassword() {
    this.router.navigate(['/users/change-password']);
    // document.getElementById('userMenu').classList.remove('show');
  }
  dashboard() {
    this.router.navigate(['/dashboard']);
  }
}
