import { Component, OnInit } from '@angular/core';
import { AppConfiguration } from '../../app-configuration';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  appExternalURLS : any;
  constructor(private conf:AppConfiguration) {
    this.appExternalURLS = conf.externalURLS;
  }

  ngOnInit() {
  }

}
