import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalComponent } from '../layout/ngb-modal/ngb-modal.component';
import { AppConfiguration } from '../app-configuration';
import { MenuService } from '../service/menu/menu.service';
import { ClaimSearchModel } from '../service/claim/claim-search-model';
import { StatusSearchModel } from '../service/claim/status/status-search-model';
import { PaymentSearchModel } from '../service/claim/payment/payment-search-model';
import { SearchModel } from '../service/search-model';
import { SharedDocumentModel } from '../service/shared-document/shared-document-model';
import { UpdateUserModel } from '../service/user/update-user-model';
import { menus } from '../service/menu/menu';
import { Title } from '@angular/platform-browser';
import * as $ from 'jquery';
import { Location } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class ValidateGuard implements CanActivate {

  currentPath: String;
  localStorage : any;
  idleState: string;
  timedOut = false;
  countdownTime: number;
  getTitle:any;
  modalReference: NgbModalRef;
  constructor(private router: Router, private idle: Idle, private keepalive: Keepalive, private _config: AppConfiguration, private titleService: Title,private ngbModal: NgbModal,private menuService : MenuService, private claimSearchModel: ClaimSearchModel, private paymentModel: PaymentSearchModel, private statusModel: StatusSearchModel, private UWSearchModel: SearchModel, private sharedModel: SharedDocumentModel, private userModel: UpdateUserModel, location: Location) {

    this.countdownTime = 30;
    idle.setIdle(30*60);
    idle.setTimeout(this.countdownTime);
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES); 

    idle.onIdleEnd.subscribe(() => {
      this.modalReference.close();
    });

    idle.onTimeout.subscribe(() => {
        this.modalReference.close();
        this.ngbModal.dismissAll();
        sessionStorage.clear();
        $('#loggedName').html('');
        $('#nav-tab').remove();
        this.router.navigate(['/session-expired']);
    });

    idle.onTimeoutWarning.subscribe((countdown) => {
      if (countdown == this.countdownTime){
        this.modalReference = this.ngbModal.open(NgbModalComponent);
        this.modalReference.componentInstance.Title = "Auto Logout!"
      }
      this.modalReference.componentInstance.confMessage = "Your Session will expire in "+countdown;
    });

    // Lets check the path everytime the route changes, stop or start the idle check as appropriate.
    router.events.subscribe((val) => {
      this.currentPath = location.path();
      if(this.currentPath.indexOf("/dashboard") > -1 || this.currentPath.indexOf("/claims") > -1 || this.currentPath.indexOf("/underwriting") > -1 || this.currentPath.indexOf("/eapply-corporate") > -1 || this.currentPath.indexOf("/shared-documents") > -1 || this.currentPath.indexOf("/steadfast") > -1 || this.currentPath.indexOf("/users") > -1)
          idle.watch();
      else
          idle.stop();
    });
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      
      let urlArr = '/dashboard,/claims/submit-claims,/underwriting/submit-new-underwriting,/steadfast,/users/create,/users/change-password,/metapply-corporate';
      if(urlArr.indexOf(state.url) > -1) {
        sessionStorage.removeItem('reportData');
        sessionStorage.removeItem('reportName');
        sessionStorage.removeItem('Searched');
      } else {
        let from_url = this.router.routerState.snapshot.url.split('/');
        let to_url = state.url.split('/');
        if(from_url.length > 1 && (from_url[1] != to_url[1] || from_url[2] != to_url[2])) {
          if(from_url[1] == 'claims' && from_url[2] == 'validateClaim') {
            this.claimSearchModel.valiadtemodel = this.claimSearchModel.resetvalidemodel;
          } else if(from_url[1] == 'claims') {
            this.claimSearchModel.searchModal = this.claimSearchModel.resetModel;
            this.statusModel.searchModal = this.statusModel.resetModel;
            this.paymentModel.searchModal = this.paymentModel.resetModel;
          } else if(from_url[1] == 'underwriting') { 
            this.UWSearchModel.searchModal = this.UWSearchModel.resetModel;
          } else if(from_url[1] == 'shared-documents') {
            this.sharedModel.searchModal = this.sharedModel.resetModel;
          } else if(from_url[1] == 'users' && from_url[2] == 'update-user') {
            this.userModel.searchModal = this.userModel.resetModel;
          }
          sessionStorage.setItem('Searched','false');
        }
      }
      let userPermissions  = JSON.parse(sessionStorage.getItem('userDetails')).menus;
      if(userPermissions == null) {
        userPermissions = [];
      }
      if(userPermissions) {
        userPermissions.push('default')
        let overall_permissions = userPermissions.join(',');
        let roles               = next.data["permissionId"];
        let url = state.url.slice(1);
        
        let flag = 0;
        let newArr = [];
        let allZeros;

        if(roles) {
          for (let tt of roles) {
            let pos = overall_permissions.indexOf(tt);
            flag = (pos != -1) ? 1 : 0;
            newArr.push(flag);
          }
          allZeros = newArr.every(zeroTest);
          if(allZeros){
            this.router.navigate(['/dashboard']);
            this.titleService.setTitle("Home | eView - MetLife");
            return false;
          } else {
            this.menuService.resetMenu();
            this.menuService.addMenu(menus,overall_permissions);

            this.getTitle = url.replace(/\//gi, "_");
            let res = this._config.pageTitles.find(x=> x.name == this.getTitle); 
            if (res != undefined) {
              let passwordResetFlag = JSON.parse(sessionStorage.getItem('userDetails')).passwordInforce;
              if (state.url =='/users/change-password' && passwordResetFlag.toLowerCase() == 'true' && res.title=='Change password')
              {
                this.titleService.setTitle("Reset password | eView - MetLife");
              } else {
                this.titleService.setTitle(res.title+" | eView - MetLife");
              }
            }
            else{
              let urls = this.getTitle.split("_");
              urls.splice(urls.length-1, 1);
              this.getTitle = urls.join("_");
              let res = this._config.pageTitles.find(x=> x.name == this.getTitle); 
              if (res != undefined) this.titleService.setTitle(res.title+" | eView - MetLife");
            }
            return true;            
          }
        }
      }
      
      function zeroTest(element) {
        return element === 0;
      } 

      
      // if( url == 'steadfast') { 
      //   document.addEventListener('DOMContentLoaded', function() {
      //       $('#nav-tab div').removeClass('active');
      //       $(screen.width > 575 ? '#nav-'+url+'-tab':'#nav-'+url+'-tabs').addClass('active'); 
      //   }, false);
      // }
  }
}
