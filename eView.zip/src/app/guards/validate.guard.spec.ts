import { TestBed, async, inject } from '@angular/core/testing';

import { ValidateGuard } from './validate.guard';
import { RouterTestingModule } from '@angular/router/testing';
import { Idle, IdleExpiry } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ClaimSearchModel } from '../service/claim/claim-search-model';
import { SearchModel } from '../service/search-model';
import { SharedDocumentModel } from '../service/shared-document/shared-document-model';
import { AppConfiguration } from '../app-configuration';
import { UpdateUserModel } from '../service/user/update-user-model';

describe('ValidateGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule
      ],
      providers: [
        ValidateGuard, 
        Idle, 
        { provide: IdleExpiry, useClass: MockExpiry },
        Keepalive, 
        AppConfiguration,
        ClaimSearchModel,
        SearchModel,
        SharedDocumentModel,
        UpdateUserModel
      ]
    });
    sessionStorage.setItem('userToken','eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOlsicmVzb3VyY2VJZCJdLCJ1c2VyX25hbWUiOiJldmlld2FsbGFjY2VzcyIsInNjb3BlIjpbInJlYWQiXSwiZXhwIjoxNTY5MjI1MzYzLCJhdXRob3JpdGllcyI6WyJST0xFX01FTlVfU2hhcmVkRG9jdW1lbnRzX1NlYXJjaERvY3VtZW50cyIsIlJPTEVfTUVOVV9TaGFyZWREb2N1bWVudHNfTWFuYWdlRG9jdW1lbnRzIiwiUk9MRV9NRU5VX2VRdWVyeV9MaWZlRXZlbnRUcmFuc2ZlciIsIlJPTEVfTUVOVV9Vc2VyTWFuYWdlbWVudF9VcGRhdGVBcHBNb2R1bGVzIiwiUk9MRV9NRU5VX2VRdWVyeV9EYXRhRXhwb3J0IiwiUk9MRV9NRU5VX2VMb2RnZW1lbnRfVXBkYXRlQ2xhaW0iLCJST0xFX1BBU1NXT1JEX0ZBTFNFIiwiUk9MRV9NRU5VX2VDbGFpbXNfVmFsaWRhdGVDbGFpbSIsIlJPTEVfTUVOVV9lTG9kZ2VtZW50X1N1Ym1pdFVuZGVyd3JpdGluZyIsIlJPTEVfTUVOVV9TaGFyZWREb2N1bWVudHNfTWVtYmVyRmlsZVVwbG9hZCIsIlJPTEVfU05fdGVzdCIsIlJPTEVfTUVOVV9Vc2VyTWFuYWdlbWVudF9TZWFyY2hVcGRhdGVVc2VyIiwiUk9MRV9NRU5VX2VMb2RnZW1lbnRfVXBkYXRlVW5kZXJ3cml0aW5nIiwiUk9MRV9NRU5VX2VMb2RnZW1lbnRfTWVtYmVyVmFsaWRhdGlvbiIsIlJPTEVfTUVOVV9Vc2VyTWFuYWdlbWVudF9DcmVhdGVOZXdVc2VyIiwiUk9MRV9NRU5VX2VRdWVyeV9DbGFpbXNQYXltZW50UnB0IiwiUk9MRV9OQU1FX1Rlc3QiLCJST0xFX01FTlVfZVF1ZXJ5X0NsYWltc1NMQVJwdCIsIlJPTEVfTUFJTF9rYWxhaXNlbHZhbi52QGNvZ25pemFudC5jb20iLCJST0xFX01FTlVfZVF1ZXJ5X1VuZGVyd3JpdGluZ1BERnMiLCJST0xFX0NPTVBBTllfRElSRUNUIiwiUk9MRV9NRU5VX0VBcHBseV9Db3Jwb3JhdGUiLCJST0xFX01FTlVfZVF1ZXJ5X1VXU3RhdHVzUnB0IiwiUk9MRV9NRU5VX2VRdWVyeV9DbGFpbXNTdGF0dXNScHQiLCJST0xFX01FTlVfZUNsYWltc19lQ2xhaW1zIiwiUk9MRV9NRU5VX2VRdWVyeV9VV1JlcVJwdCIsIlJPTEVfTUVOVV9lQXBwbHlfQ29ycG9yYXRlT25ib2FyZGluZyIsIlJPTEVfTUVOVV9TdGVhZGZhc3RfU3RlYWRmYXN0IiwiUk9MRV9NRU5VX2VRdWVyeV9DbGFpbXNSZXFScHQiLCJST0xFX01FTlVfZUxvZGdlbWVudF9TdWJtaXRDbGFpbSIsIlJPTEVfbWV0bGlmZSBpbnRlcm5hbCIsIlJPTEVfTUVOVV9Db2dub3NfQ29nbm9zIiwiUk9MRV9NRU5VX2VRdWVyeV9VV1NMQVJwdCJdLCJqdGkiOiJkNjVmMzI4Yi0zNTkwLTRkMWYtYjA1NS0yNzI4NDRmODU1YzkiLCJjbGllbnRfaWQiOiJtZXRhdSJ9.m97Y5PKVYjMaCz1-kOZoMXzw2MxGrl1dffvoDL0czAE');
    sessionStorage.setItem('userDetails','{"userName":"navaneethap","roles":["COMPANY_METL","metlife internal"],"funds":null,"menus":["SharedDocuments_SearchDocuments","SharedDocuments_ManageDocuments","eQuery_LifeEventTransfer","UserManagement_UpdateAppModules","eQuery_DataExport","eLodgement_UpdateClaim","eClaims_ValidateClaim","eLodgement_SubmitUnderwriting","SharedDocuments_MemberFileUpload","UserManagement_SearchUpdateUser","eLodgement_UpdateUnderwriting","eLodgement_MemberValidation","UserManagement_CreateNewUser","eQuery_ClaimsPaymentRpt","eQuery_ClaimsSLARpt","eQuery_UnderwritingPDFs","EApply_Corporate","eQuery_UWStatusRpt","eQuery_ClaimsStatusRpt","eClaims_eClaims","eQuery_UWReqRpt","eApply_CorporateOnboarding","Steadfast_Steadfast","eQuery_ClaimsReqRpt","eLodgement_SubmitClaim","Cognos_Cognos","eQuery_UWSLARpt"],"passwordInforce":"FALSE","status":"Active","pwdChangedTime":"20190926151350.499764Z","pwdAccountLockedTime":null,"email":"navaneetha-krishnan.perumalsamy@metlife.com","firstName":"Navaneetha Krishnan","lastName":"Perumalsamy","mobile":"","prevLoginTime":"1569930644304","hours":0,"tempPwdExpired":false}');    
  });

  it('should ...', inject([ValidateGuard], (guard: ValidateGuard) => {
    expect(guard).toBeTruthy();
  }));
});
export class MockExpiry extends IdleExpiry {
  public lastDate: Date;
  public mockNow: Date;

  last(value?: Date): Date {
    if (value !== void 0) {
      this.lastDate = value;
    }
    return this.lastDate;
  }

  now(): Date {
    return this.mockNow || new Date();
  }
}