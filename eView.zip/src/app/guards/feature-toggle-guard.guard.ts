import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AppConfiguration } from '../app-configuration';

@Injectable({
  providedIn: 'root'
})
export class FeatureToggleGuard implements CanActivate {

  constructor(private router: Router, private appConfig: AppConfiguration) { }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      const featureToggle = this.appConfig.featureToggle[this.appConfig.envName];
      const featureFlag = route.data['featureToggleKey'];
      if (featureToggle['*']) {
        return true;
      } else if (featureToggle[featureFlag]) {
        return true;
      } else if (!featureToggle[featureFlag]) {
        this.router.navigate(['/under-construction']);
        return false;
      }
      return true;
  }
}
