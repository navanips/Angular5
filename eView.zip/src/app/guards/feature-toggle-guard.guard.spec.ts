import { TestBed, async, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FeatureToggleGuard } from './feature-toggle-guard.guard';
import { AppConfiguration } from '../app-configuration';

describe('FeatureToggleGuardGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
      ],
      providers: [
        FeatureToggleGuard,
        AppConfiguration
      ]
    });
  });

  it('should ...', inject([FeatureToggleGuard], (guard: FeatureToggleGuard) => {
    expect(guard).toBeTruthy();
  }));
});
