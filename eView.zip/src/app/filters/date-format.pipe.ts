import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateFormat'
})
export class DateFormatPipe implements PipeTransform {
  
  transform(value: any, args?: any): any {
    
    var actualDate = new Date(value);
    var date = ('0' + actualDate.getDate()).slice(-2);
    var month = ('0' + (actualDate.getMonth()+1)).slice(-2)
    let year = actualDate.getFullYear();
    
    let formattedDate = date+'/'+month+'/'+year;    
    return formattedDate;
  }

}
