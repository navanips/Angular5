import { Component,Input,OnInit } from '@angular/core';
import {CustomSpinnerService} from '../app/service/spinner/custom-spinner.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Eview - MetLife';
  showCustomLoader: Boolean;  
  constructor(private spin:CustomSpinnerService) {
    this.showCustomLoader = false;
  }
  ngOnInit() {
    this.spin.getEmittedValue()
      .subscribe(item => this.showCustomLoader=item);
  }
}
