$(document).ready(function(){
    $('#nav-claims-tab, #nav-underwriting-tab').hover(function(){
        $(this).find('.dropdown-content').show();
    },function(){
        $(this).find('.dropdown-content').hide();
    });
    $('#nav-claims-tab .dropdown-content a, #nav-underwriting-tab .dropdown-content a').click(function(){
        $(this).parent().parent().parent().parent().hide();
    });
});